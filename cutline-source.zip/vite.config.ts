import {defineConfig} from 'vitest/config';
import react from '@vitejs/plugin-react';
import {loadEnv, type Connect, type Plugin} from 'vite';
import {createApiRouter} from './server/api.ts';
import {JobStore} from './server/jobs.ts';
import {createProviderChat} from './server/provider.ts';
import {RenderJobStore} from './server/render-jobs.ts';
import {studioRuntime} from './server/studio-runtime.ts';
function apiPlugin():Plugin {
  let runtime:ReturnType<typeof studioRuntime>|undefined;
  let legacy:ReturnType<typeof createApiRouter>|undefined;
  let legacyStore:JobStore|undefined;
  let renderStore:RenderJobStore|undefined;
  const middleware:Connect.NextHandleFunction=(req,res,next)=>{
    const url=new URL(req.url??'/','http://localhost');
    if(!url.pathname.startsWith('/api/'))return next();
    if(url.pathname.startsWith('/api/studio/')||url.pathname==='/api/health'||url.pathname==='/api/ready'){
      runtime??=studioRuntime();
      runtime.then(r=>r.handle(req,res,url)).catch(()=>{if(!res.headersSent){res.statusCode=503;res.setHeader('content-type','application/json');res.end(JSON.stringify({error:'Studio unavailable. Run database migration and owner setup; check private environment settings.'}));}else res.destroy();});
      return;
    }
    legacyStore??=new JobStore({chat:createProviderChat(process.env.ALLOW_PRIVATE_ENDPOINTS==='true')});
    renderStore??=new RenderJobStore({projectRoot:process.cwd()});
    legacy??=createApiRouter({store:legacyStore,renderStore,enablePromptEditor:true,allowPrivateEndpoints:process.env.ALLOW_PRIVATE_ENDPOINTS==='true',trustProxy:false,rateLimitPerMinute:Number(process.env.API_RATE_LIMIT_PER_MINUTE)||30});
    void legacy(req as never,res as never,url).catch(()=>{if(!res.headersSent){res.statusCode=500;res.setHeader('content-type','application/json');res.end(JSON.stringify({error:{message:'Prompt editor request failed.'}}));}else res.destroy();});
  };
  const cleanup=()=>{void runtime?.then(r=>r.close());legacyStore?.dispose();renderStore?.dispose();};
  return {name:'cutline-api',configureServer(server){server.middlewares.use(middleware);server.httpServer?.on('close',cleanup);},configurePreviewServer(server){server.middlewares.use(middleware);server.httpServer?.on('close',cleanup);}};
}
export default defineConfig(({mode})=>{
  const env=loadEnv(mode,process.cwd(),'');
  for(const key of ['DATABASE_URL','SESSION_SECRET','CREDENTIALS_KEY','PUBLIC_APP_URL','DEV_PREVIEW_ORIGIN','MEDIA_DIR']){
    if(process.env[key]===undefined&&env[key])process.env[key]=env[key];
  }
  return {plugins:[react(),apiPlugin()],server:{host:'0.0.0.0',port:3000,strictPort:true},preview:{host:'0.0.0.0',port:3000,strictPort:true},test:{environment:'node',include:['tests/**/*.test.ts']}};
});
