import {describe, expect, it, vi} from 'vitest';
import {Readable} from 'node:stream';
import {stat, readFile} from 'node:fs/promises';
import {RenderJobStore, type RenderExecutionInput} from '../server/render-jobs';
import {DEFAULT_SPEC, normalizeSpec} from '../src/lib/spec';

const baseSpec = normalizeSpec(DEFAULT_SPEC);
const specWithSeconds = (seconds: number) => normalizeSpec({...baseSpec, scenes: Array.from({length: Math.ceil(seconds / 20)}, (_, index) => ({...baseSpec.scenes[0], id: `duration_${index}`, durationInFrames: Math.min(20, seconds - index * 20) * baseSpec.meta.fps}))});

const imageSpec = () => normalizeSpec({
  ...baseSpec,
  meta: {...baseSpec.meta, width: 1280, height: 720},
  scenes: [{...baseSpec.scenes[0], kind: 'image', mediaAttachmentId: 'img_1'}],
});

const imageMetadata = (blob: Blob) => ({
  id: 'img_1',
  name: 'still.png',
  kind: 'image',
  mimeType: 'image/png',
  frameTimes: [0],
  size: blob.size,
});

const storeOptions = (executor: (input: RenderExecutionInput) => Promise<void>) => ({
  projectRoot: process.cwd(),
  executor,
  ttlMs: 10_000,
});

describe('RenderJobStore', () => {
  it('uploads selected original files, reports rendering progress and keeps completed MP4 downloadable', async () => {
    const blob = new Blob([new Uint8Array([1, 2, 3, 4])], {type: 'image/png'});
    const store = new RenderJobStore(storeOptions(async (input) => {
      expect(input.attachments[0].renderSrc).toBe('media/img_1.png');
      expect([...await readFile(input.attachments[0].renderSrc ? `${input.publicDir}/${input.attachments[0].renderSrc}` : '')]).toEqual([1, 2, 3, 4]);
      input.onProgress(0.5, 'Rendering frames…');
      await import('node:fs/promises').then(({writeFile}) => writeFile(input.outputPath, new Uint8Array([5, 6, 7])));
    }));
    try {
      const created = await store.create({spec: imageSpec(), attachments: [imageMetadata(blob)], ip: 'test-ip'});
      expect(created.ok).toBe(true);
      if (!created.ok) return;
      const progress: number[] = [];
      store.subscribe(created.job.id, (snapshot) => progress.push(snapshot.progress));
      await store.uploadMedia(created.job.id, 'img_1', Readable.from([Buffer.from([1, 2, 3, 4])]), 4);
      expect(store.get(created.job.id)?.uploadedBytes).toBe(4);
      expect(store.start(created.job.id)).toBe(true);
      await vi.waitFor(() => {
        const snapshot = store.get(created.job.id);
        if (snapshot?.status === 'error') throw new Error(snapshot.error);
        expect(snapshot?.status).toBe('done');
      });
      expect(progress).toContain(0.5);
      const outputPath = store.getOutputPath(created.job.id);
      expect(outputPath).toBeTruthy();
      expect([...await readFile(outputPath!)]).toEqual([5, 6, 7]);
      expect((await stat(outputPath!)).size).toBe(3);
    } finally {
      store.dispose();
    }
  });

  it('passes uploaded source audio into the renderer attachment catalog', async () => {
    const audioBlob = new Blob([new Uint8Array([1, 2, 3, 4])], {type: 'audio/mpeg'});
    const spec = normalizeSpec({...baseSpec, scenes: [{...baseSpec.scenes[0], kind: 'image', mediaAttachmentId: 'img_1', audioAttachmentId: 'audio_1', keepSourceAudio: false}]});
    const executor = vi.fn(async (input: RenderExecutionInput) => {
      expect(input.attachments.find((item) => item.id === 'audio_1')).toMatchObject({kind: 'audio', audioSrc: expect.stringMatching(/^media\/audio_1\.mp3$/)});
      await import('node:fs/promises').then(({writeFile}) => writeFile(input.outputPath, new Uint8Array([9])));
    });
    const store = new RenderJobStore(storeOptions(executor));
    try {
      const created = await store.create({
        spec,
        attachments: [imageMetadata(new Blob([new Uint8Array([5])])), {id: 'audio_1', name: 'music.mp3', kind: 'audio', mimeType: 'audio/mpeg', durationSeconds: 8, frameTimes: [0], audioBytes: audioBlob.size, size: audioBlob.size}],
        ip: 'audio-test',
      });
      expect(created.ok).toBe(true);
      if (!created.ok) return;
      await store.uploadMedia(created.job.id, 'img_1', Readable.from([Buffer.from([5])]), 1);
      await store.uploadMedia(created.job.id, 'audio_1', Readable.from([Buffer.from([1, 2, 3, 4])]), audioBlob.size);
      expect(store.start(created.job.id)).toBe(true);
      await vi.waitFor(() => expect(store.get(created.job.id)?.status).toBe('done'));
      expect(executor).toHaveBeenCalledOnce();
    } finally {
      store.dispose();
    }
  });

  it('refuses arbitrary media paths, missing upload files and overlarge inputs', async () => {
    const store = new RenderJobStore(storeOptions(async () => undefined));
    try {
      await expect(store.create({spec: baseSpec, attachments: [imageMetadata(new Blob([new Uint8Array([1])]))], ip: 'a'})).rejects.toThrow(/unused/);

      const missing = await store.create({spec: imageSpec(), attachments: [imageMetadata(new Blob([new Uint8Array([1])]))], ip: 'a'});
      expect(missing.ok).toBe(true);
      if (!missing.ok) return;
      expect(() => store.start(missing.job.id)).toThrow(/upload/i);

      await expect(store.create({
        spec: imageSpec(),
        attachments: [{...imageMetadata(new Blob([new Uint8Array([1])])), mimeType: 'image/svg+xml'}],
        ip: 'b',
      })).rejects.toThrow(/not supported/);
    } finally {
      store.dispose();
    }
  });

  it('limits dimensions and render duration to safe server-render bounds', async () => {
    const store = new RenderJobStore(storeOptions(async () => undefined));
    try {
      await expect(store.create({spec: normalizeSpec({...baseSpec, meta: {...baseSpec.meta, width: 2048}}), attachments: [], ip: 'a'})).rejects.toThrow(/1920/);
      const exactlyTwoMinutes = await store.create({spec: specWithSeconds(120), attachments: [], ip: 'b'});
      expect(exactlyTwoMinutes).toMatchObject({ok: true, job: {status: 'uploading'}});
      if (exactlyTwoMinutes.ok) store.cancel(exactlyTwoMinutes.job.id);
      await expect(store.create({spec: specWithSeconds(121), attachments: [], ip: 'c'})).rejects.toThrow(/120 seconds/);
    } finally {
      store.dispose();
    }
  });

  it('limits VPS render concurrency and queueing while allowing a small shared-IP allowance', async () => {
    const executor = vi.fn((input: RenderExecutionInput) => new Promise<void>((_resolve, reject) => {
      input.signal.addEventListener('abort', () => reject(new Error('Render cancelled.')), {once: true});
    }));
    const store = new RenderJobStore({...storeOptions(executor), maxConcurrent: 1, maxPerIp: 2, maxQueued: 1});
    try {
      const first = await store.create({spec: baseSpec, attachments: [], ip: 'shared-mobile-ip'});
      expect(first.ok).toBe(true);
      if (!first.ok) return;
      expect(store.start(first.job.id)).toBe(true);
      await vi.waitFor(() => expect(executor).toHaveBeenCalledTimes(1));

      const second = await store.create({spec: baseSpec, attachments: [], ip: 'shared-mobile-ip'});
      expect(second.ok).toBe(true);
      if (!second.ok) return;
      expect(store.start(second.job.id)).toBe(true);

      const sameIpLimit = await store.create({spec: baseSpec, attachments: [], ip: 'shared-mobile-ip'});
      expect(sameIpLimit).toMatchObject({ok: false, reason: 'rate-limited'});
      const globalQueueLimit = await store.create({spec: baseSpec, attachments: [], ip: 'another-ip'});
      expect(globalQueueLimit).toMatchObject({ok: false, reason: 'queue-full'});
      expect(executor).toHaveBeenCalledTimes(1);
    } finally {
      store.dispose();
    }
  });

  it('cancels queued work without invoking the renderer', async () => {
    const executor = vi.fn(async () => undefined);
    const store = new RenderJobStore({...storeOptions(executor), maxConcurrent: 0});
    try {
      const created = await store.create({spec: baseSpec, attachments: [], ip: 'a'});
      expect(created.ok).toBe(true);
      if (!created.ok) return;
      store.start(created.job.id);
      expect(store.cancel(created.job.id)).toBe(true);
      expect(store.get(created.job.id)?.status).toBe('cancelled');
      expect(executor).not.toHaveBeenCalled();
    } finally {
      store.dispose();
    }
  });
});
