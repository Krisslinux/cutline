import {afterAll, beforeAll, describe, expect, it} from 'vitest';
import {createServer as createHttpServer, type Server} from 'node:http';
import type {AddressInfo} from 'node:net';
import {mkdir, mkdtemp, writeFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {createApp} from '../server/index.ts';
import {RenderJobStore, type RenderExecutionInput} from '../server/render-jobs.ts';
import type {JobSnapshot} from '../server/jobs.ts';
import {DEFAULT_SPEC, normalizeSpec} from '../src/lib/spec.ts';

const listen = (server: Server): Promise<number> =>
  new Promise((resolve) => {
    server.listen(0, '127.0.0.1', () => resolve((server.address() as AddressInfo).port));
  });

const close = (server: Server): Promise<void> => new Promise((resolve) => server.close(() => resolve()));

const finished = (snapshot: JobSnapshot): boolean =>
  snapshot.status === 'done' || snapshot.status === 'error' || snapshot.status === 'cancelled';

let staticDir = '';
let app: Server;
let base = '';
let mockProvider: Server;
let providerBase = '';
let providerHits = 0;

// Job provider scripts one tool call, then a closing message.
let jobProvider: Server;
let jobProviderBase = '';
let jobCalls = 0;
let jobPayloads: Record<string, unknown>[] = [];
let jobDelayMs = 0;
let renderStore: RenderJobStore;

beforeAll(async () => {
  staticDir = await mkdtemp(path.join(tmpdir(), 'cutline-dist-'));
  await writeFile(path.join(staticDir, 'index.html'), '<!doctype html><title>Cutline</title><div id="root"></div>');
  await mkdir(path.join(staticDir, 'assets'));
  await writeFile(
    path.join(staticDir, 'assets', 'index-abcdef123456.js'),
    `console.log(${JSON.stringify('x'.repeat(2000))});`,
  );

  renderStore = new RenderJobStore({
    projectRoot: process.cwd(),
    maxPerIp: 2,
    executor: async (input: RenderExecutionInput) => {
      input.onProgress(0.5, 'Rendering frames…');
      await writeFile(input.outputPath, Buffer.from('fake-mp4-data'));
    },
  });
  app = createApp({staticDir, allowPrivateEndpoints: true, rateLimitPerMinute: 100, renderStore, enablePromptEditor: true});
  base = `http://127.0.0.1:${await listen(app)}`;

  mockProvider = createHttpServer((req, res) => {
    providerHits += 1;
    req.resume();
    req.on('end', () => {
      res.writeHead(200, {'content-type': 'application/json'});
      res.end(JSON.stringify({choices: [{message: {role: 'assistant', content: 'ready'}}]}));
    });
  });
  providerBase = `http://127.0.0.1:${await listen(mockProvider)}/v1`;

  jobProvider = createHttpServer((req, res) => {
    let raw = '';
    req.on('data', (chunk) => (raw += chunk));
    req.on('end', () => {
      jobCalls += 1;
      try {
        jobPayloads.push(JSON.parse(raw) as Record<string, unknown>);
      } catch {
        jobPayloads.push({});
      }
      const respond = () => {
        res.writeHead(200, {'content-type': 'application/json'});
        if (jobCalls === 1) {
          res.end(
            JSON.stringify({
              choices: [
                {
                  message: {
                    role: 'assistant',
                    content: null,
                    tool_calls: [
                      {
                        id: 'call_1',
                        type: 'function',
                        function: {
                          name: 'add_scene',
                          arguments: JSON.stringify({kind: 'outro', headline: 'Fin', cta: 'Go', durationSeconds: 2}),
                        },
                      },
                    ],
                  },
                },
              ],
            }),
          );
        } else {
          res.end(JSON.stringify({choices: [{message: {role: 'assistant', content: 'Added a closing scene.'}}]}));
        }
      };
      if (jobDelayMs) setTimeout(respond, jobDelayMs);
      else respond();
      void raw;
    });
  });
  jobProviderBase = `http://127.0.0.1:${await listen(jobProvider)}/v1`;
});

afterAll(async () => {
  await close(app);
  renderStore.dispose();
  await close(mockProvider);
  await close(jobProvider);
});

const chat = (body: unknown) =>
  fetch(`${base}/api/chat`, {
    method: 'POST',
    headers: {'content-type': 'application/json'},
    body: JSON.stringify(body),
  });

const validBody = (overrides: Record<string, unknown> = {}) => ({
  baseUrl: providerBase,
  apiKey: 'test-token',
  model: 'test-model',
  messages: [{role: 'user', content: 'hi'}],
  ...overrides,
});

const startJob = (overrides: Record<string, unknown> = {}) =>
  fetch(`${base}/api/jobs`, {
    method: 'POST',
    headers: {'content-type': 'application/json'},
    body: JSON.stringify({
      baseUrl: jobProviderBase,
      apiKey: 'job-token',
      model: 'test-model',
      spec: normalizeSpec(DEFAULT_SPEC),
      prompt: 'add a closing scene',
      history: [],
      ...overrides,
    }),
  });

const pollJob = async (id: string, timeoutMs = 4_000): Promise<JobSnapshot> => {
  const deadline = Date.now() + timeoutMs;
  let snapshot: JobSnapshot | null = null;
  while (Date.now() < deadline) {
    const response = await fetch(`${base}/api/jobs/${id}`);
    snapshot = (await response.json()) as JobSnapshot;
    if (finished(snapshot)) return snapshot;
    await new Promise((resolve) => setTimeout(resolve, 40));
  }
  throw new Error(`job ${id} did not finish: ${JSON.stringify(snapshot)}`);
};

const readSse = async (id: string): Promise<JobSnapshot[]> => {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 5_000);
  const response = await fetch(`${base}/api/jobs/${id}/events`, {signal: controller.signal});
  expect(response.headers.get('content-type')).toContain('text/event-stream');
  const reader = response.body?.getReader();
  if (!reader) throw new Error('no stream body');

  const decoder = new TextDecoder();
  const frames: JobSnapshot[] = [];
  let buffer = '';
  try {
    while (true) {
      const {done, value} = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, {stream: true});
      const parts = buffer.split('\n\n');
      buffer = parts.pop() ?? '';
      for (const part of parts) {
        const data = part
          .split('\n')
          .find((line) => line.startsWith('data: '));
        if (data) frames.push(JSON.parse(data.slice(6)) as JobSnapshot);
      }
      if (frames.some(finished)) break;
    }
  } finally {
    clearTimeout(timer);
    await reader.cancel().catch(() => undefined);
  }
  return frames;
};

describe('production server', () => {
  it('reports health', async () => {
    const response = await fetch(`${base}/api/health`);
    expect(response.status).toBe(200);
    const body = (await response.json()) as {ok: boolean; jobs: {running: number; queued: number}};
    expect(body.ok).toBe(true);
    expect(typeof body.jobs.running).toBe('number');
  });

  it('serves the app shell with security headers and SPA fallback', async () => {
    const index = await fetch(`${base}/`);
    expect(index.status).toBe(200);
    expect(index.headers.get('content-type')).toContain('text/html');
    expect(index.headers.get('content-security-policy')).toContain("default-src 'self'");
    expect(index.headers.get('cache-control')).toBe('no-cache');

    const nested = await fetch(`${base}/projects/example`);
    expect(nested.status).toBe(200);
    expect(await nested.text()).toContain('id="root"');
  });

  it('serves hashed assets with long-lived cache and gzip', async () => {
    const response = await fetch(`${base}/assets/index-abcdef123456.js`, {headers: {'accept-encoding': 'gzip'}});
    expect(response.status).toBe(200);
    expect(response.headers.get('cache-control')).toContain('immutable');
    expect(response.headers.get('content-encoding')).toBe('gzip');
    expect(Number(response.headers.get('content-length'))).toBeLessThan(2000);
  });

  it('404s missing assets instead of returning the shell', async () => {
    const response = await fetch(`${base}/assets/missing-000000001.js`);
    expect(response.status).toBe(404);
  });

  it('keeps prompt editor endpoints disabled unless the server explicitly enables them', async () => {
    const restricted = createApp({staticDir, rateLimitPerMinute: 100});
    const restrictedBase = `http://127.0.0.1:${await listen(restricted)}`;
    try {
      const chatResponse = await fetch(`${restrictedBase}/api/chat`, {method: 'POST', headers: {'content-type': 'application/json'}, body: JSON.stringify(validBody())});
      const jobsResponse = await fetch(`${restrictedBase}/api/jobs`, {method: 'POST'});
      const rendersResponse = await fetch(`${restrictedBase}/api/renders`, {method: 'POST'});
      expect(chatResponse.status).toBe(410);
      expect(jobsResponse.status).toBe(410);
      expect(rendersResponse.status).toBe(410);
    } finally {
      await close(restricted);
    }
  });

  it('forwards selected image previews through the live prompt editor API', async () => {
    const before = providerHits;
    const response = await chat(validBody({
      attachments: [{id: 'vision_image', name: 'frame.jpg', kind: 'image', mimeType: 'image/jpeg', frames: [{timeSeconds: 0, dataUrl: 'data:image/jpeg;base64,AQID'}]}],
      messages: [{role: 'user', content: 'Plan this cut'}],
    }));
    expect(response.status).toBe(200);
    expect(providerHits).toBe(before + 1);
  });

  it('forwards a chat request to the configured provider', async () => {
    const before = providerHits;
    const response = await chat(validBody({tools: [{type: 'function', function: {name: 'get_spec', parameters: {}}}]}));
    expect(response.status).toBe(200);
    expect(await response.json()).toMatchObject({choices: [{message: {content: 'ready'}}]});
    expect(providerHits).toBe(before + 1);
  });

  it('rejects non-POST methods and oversized bodies', async () => {
    const notAllowed = await fetch(`${base}/api/chat`);
    expect(notAllowed.status).toBe(405);

    const oversized = await chat({...validBody(), messages: [{role: 'user', content: 'x'.repeat(600 * 1024)}]});
    expect(oversized.status).toBe(413);
  });

  it('answers CORS preflight without hitting the provider', async () => {
    const response = await fetch(`${base}/api/chat`, {method: 'OPTIONS'});
    expect(response.status).toBe(204);
  });

  it('blocks private endpoints when they are not allowed', async () => {
    const lockedDown = createApp({staticDir, allowPrivateEndpoints: false, enablePromptEditor: true, rateLimitPerMinute: 100});
    const lockedBase = `http://127.0.0.1:${await listen(lockedDown)}`;
    try {
      const before = providerHits;
      const response = await fetch(`${lockedBase}/api/chat`, {
        method: 'POST',
        headers: {'content-type': 'application/json'},
        body: JSON.stringify(validBody()),
      });
      expect(response.status).toBe(400);
      expect(await response.text()).toContain('private or local address');
      expect(providerHits).toBe(before);

      const jobResponse = await fetch(`${lockedBase}/api/jobs`, {
        method: 'POST',
        headers: {'content-type': 'application/json'},
        body: JSON.stringify({
          baseUrl: jobProviderBase,
          model: 'test-model',
          spec: normalizeSpec(DEFAULT_SPEC),
          prompt: 'edit',
        }),
      });
      expect(jobResponse.status).toBe(400);
    } finally {
      await close(lockedDown);
    }
  });

  it('rate limits a chatty client per IP', async () => {
    const limited = createApp({staticDir, allowPrivateEndpoints: true, enablePromptEditor: true, rateLimitPerMinute: 2});
    const limitedBase = `http://127.0.0.1:${await listen(limited)}`;
    try {
      const attempt = () =>
        fetch(`${limitedBase}/api/chat`, {
          method: 'POST',
          headers: {'content-type': 'application/json'},
          body: JSON.stringify(validBody()),
        });
      expect((await attempt()).status).toBe(200);
      expect((await attempt()).status).toBe(200);
      const third = await attempt();
      expect(third.status).toBe(429);
      expect(third.headers.get('retry-after')).toBe('60');
    } finally {
      await close(limited);
    }
  });

  it('runs an edit as a background job and returns the new spec', async () => {
    jobCalls = 0;
    const response = await startJob();
    expect(response.status).toBe(202);
    const created = (await response.json()) as {id: string; status: string};
    expect(created.id).toMatch(/^[0-9a-f-]{36}$/);
    expect(['queued', 'running']).toContain(created.status);

    const final = await pollJob(created.id);
    expect(final.status).toBe('done');
    expect(final.changed).toBe(true);
    expect(final.reply).toContain('closing scene');
    expect(final.steps).toHaveLength(1);
    expect(final.steps[0].name).toBe('add_scene');
    expect(final.spec.scenes.length).toBe(normalizeSpec(DEFAULT_SPEC).scenes.length + 1);
    expect(final.spec.scenes[final.spec.scenes.length - 1].headline).toBe('Fin');
    expect(JSON.stringify(final)).not.toContain('job-token');
  });

  it('carries attached images through a background edit to the vision provider', async () => {
    jobCalls = 0;
    jobPayloads = [];
    const attachment = {
      id: 'image_ref_1',
      name: 'product.jpg',
      kind: 'image',
      mimeType: 'image/jpeg',
      frames: [{timeSeconds: 0, dataUrl: 'data:image/jpeg;base64,AQID'}],
    };
    const response = await startJob({attachments: [attachment]});
    expect(response.status).toBe(202);
    const created = (await response.json()) as {id: string};
    const final = await pollJob(created.id);
    expect(final.status).toBe('done');
    expect(final.attachments).toEqual([
      {id: 'image_ref_1', name: 'product.jpg', kind: 'image', mimeType: 'image/jpeg', frameTimes: [0]},
    ]);
    const sentMessages = jobPayloads[0].messages as {content: {type: string; image_url?: {url: string}}[]}[];
    expect(sentMessages.at(-1)?.content.some((part) => part.type === 'image_url' && part.image_url?.url === attachment.frames[0].dataUrl)).toBe(true);
  });

  it('creates a server render, streams progress and downloads the MP4 with byte ranges', async () => {
    const spec = normalizeSpec(DEFAULT_SPEC);
    const create = await fetch(`${base}/api/renders`, {
      method: 'POST',
      headers: {'content-type': 'application/json'},
      body: JSON.stringify({spec, media: []}),
    });
    expect(create.status).toBe(202);
    const created = (await create.json()) as {id: string; status: string};
    expect(created.status).toBe('uploading');

    const start = await fetch(`${base}/api/renders/${created.id}/start`, {method: 'POST'});
    expect(start.status).toBe(202);
    const deadline = Date.now() + 2_000;
    let final: {status: string; progress: number} | null = null;
    while (Date.now() < deadline) {
      const response = await fetch(`${base}/api/renders/${created.id}`);
      final = (await response.json()) as {status: string; progress: number};
      if (final.status === 'done') break;
      await new Promise((resolve) => setTimeout(resolve, 10));
    }
    expect(final?.status).toBe('done');
    expect(final?.progress).toBe(1);

    const downloaded = await fetch(`${base}/api/renders/${created.id}/download`, {headers: {range: 'bytes=0-3'}});
    expect(downloaded.status).toBe(206);
    expect(downloaded.headers.get('content-type')).toBe('video/mp4');
    expect(downloaded.headers.get('content-range')).toBe('bytes 0-3/13');
    expect(await downloaded.text()).toBe('fake');
    expect(downloaded.headers.get('content-disposition')).toContain('cutline-video.mp4');
  });

  it('streams job progress over SSE', async () => {
    jobCalls = 0;
    const response = await startJob();
    const created = (await response.json()) as {id: string};

    const frames = await readSse(created.id);
    expect(frames.length).toBeGreaterThan(0);
    expect(frames[frames.length - 1].status).toBe('done');
    expect(frames.some((frame) => frame.steps.length > 0)).toBe(true);
  });

  it('cancels a running job', async () => {
    jobCalls = 0;
    jobDelayMs = 400;
    try {
      const response = await startJob();
      const created = (await response.json()) as {id: string};
      await new Promise((resolve) => setTimeout(resolve, 60));

      const cancel = await fetch(`${base}/api/jobs/${created.id}/cancel`, {method: 'POST'});
      expect(cancel.status).toBe(200);

      const final = await pollJob(created.id);
      expect(['cancelled', 'done']).toContain(final.status);
    } finally {
      jobDelayMs = 0;
    }
  });

  it('rejects invalid and unreferenced render media', async () => {
    const orphan = await fetch(`${base}/api/renders`, {
      method: 'POST',
      headers: {'content-type': 'application/json'},
      body: JSON.stringify({spec: normalizeSpec(DEFAULT_SPEC), media: [{id: 'orphan', name: 'x.png', kind: 'image', mimeType: 'image/png', frameTimes: [0], size: 1}]}),
    });
    expect(orphan.status).toBe(400);
    expect((await orphan.json()).error.message).toContain('unused');

    const badId = await fetch(`${base}/api/renders/not-a-uuid`);
    expect(badId.status).toBe(404);
  });

  it('validates job payloads', async () => {
    const noPrompt = await startJob({prompt: ''});
    expect(noPrompt.status).toBe(400);

    const noSpec = await startJob({spec: null});
    expect(noSpec.status).toBe(400);

    const unknownJob = await fetch(`${base}/api/jobs/00000000-0000-0000-0000-000000000000`);
    expect(unknownJob.status).toBe(404);
  });
});
