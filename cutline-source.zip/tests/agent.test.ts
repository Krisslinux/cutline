import {describe, expect, it} from 'vitest';
import {MAX_TOOL_ROUNDS, runAgent, type AgentEvent} from '../server/agent';
import type {ChatCompletion, ChatMessage} from '../shared/chat';
import {DEFAULT_SPEC, normalizeSpec} from '../src/lib/spec';
import type {AiSettings} from '../src/lib/settings';
import type {VideoSpec} from '../src/types';

const settings: AiSettings = {baseUrl: 'https://api.example.com/v1', apiKey: 'test-key', model: 'test-model'};
const spec = (): VideoSpec => normalizeSpec(DEFAULT_SPEC);

const toolCall = (name: string, args: Record<string, unknown>, id: string) => ({
  id,
  type: 'function',
  function: {name, arguments: JSON.stringify(args)},
});

const scripted = (responses: ChatCompletion[]) => {
  const seen: ChatMessage[][] = [];
  let index = 0;
  const chat = (async (_settings: AiSettings, body: {messages: ChatMessage[]}) => {
    seen.push(body.messages.map((message) => ({...message})));
    const next = responses[Math.min(index, responses.length - 1)];
    index += 1;
    return next;
  }) as unknown as typeof import('../src/lib/api').chatCompletion;
  return {chat, seen, calls: () => index};
};

describe('runAgent', () => {
  it('applies tool calls from several rounds and returns the closing message', async () => {
    const events: AgentEvent[] = [];
    const fake = scripted([
      {
        usage: {prompt_tokens: 100, completion_tokens: 10, total_tokens: 110},
        choices: [
          {
            message: {
              role: 'assistant',
              content: null,
              tool_calls: [
                toolCall('add_scene', {kind: 'outro', headline: 'Fin', cta: 'Go'}, 'call_1'),
                toolCall('update_scene', {id: 'sc_1', headline: 'A better hook'}, 'call_2'),
              ],
            },
          },
        ],
      },
      {usage: {prompt_tokens: 120, completion_tokens: 20, total_tokens: 140}, choices: [{message: {role: 'assistant', content: 'Recut the opening and added an outro.'}}]},
    ]);

    const result = await runAgent(
      {settings, spec: spec(), prompt: 'give it a stronger ending', history: [], onEvent: (event) => events.push(event)},
      {chat: fake.chat},
    );

    expect(result.changed).toBe(true);
    expect(result.reply).toBe('Recut the opening and added an outro.');
    expect(result.spec.scenes[0].headline).toBe('A better hook');
    expect(result.spec.scenes[result.spec.scenes.length - 1].headline).toBe('Fin');
    expect(events.filter((event) => event.type === 'tool')).toHaveLength(2);
    expect(events.filter((event) => event.type === 'spec')).toHaveLength(2);
    expect(result.usage).toEqual({inputTokens: 220, outputTokens: 30, totalTokens: 250, reported: true, requests: 2});
    expect(events.filter((event) => event.type === 'usage').at(-1)).toEqual({
      type: 'usage',
      usage: {inputTokens: 220, outputTokens: 30, totalTokens: 250, reported: true, requests: 2},
    });
    expect(fake.calls()).toBe(2);
  });

  it('feeds tool results back to the model', async () => {
    const fake = scripted([
      {
        choices: [
          {
            message: {
              role: 'assistant',
              content: '',
              tool_calls: [toolCall('update_scene', {id: 'sc_1', headline: 'Hello'}, 'call_1')],
            },
          },
        ],
      },
      {choices: [{message: {role: 'assistant', content: 'Done.'}}]},
    ]);

    await runAgent({settings, spec: spec(), prompt: 'edit', history: []}, {chat: fake.chat});

    const secondRound = fake.seen[1];
    const assistant = secondRound.find((message) => message.role === 'assistant');
    const toolMessage = secondRound.find((message) => message.role === 'tool');
    expect(assistant?.tool_calls?.[0].id).toBe('call_1');
    expect(toolMessage?.tool_call_id).toBe('call_1');
    const payload = JSON.parse(String(toolMessage?.content)) as {ok: boolean; spec: VideoSpec};
    expect(payload.ok).toBe(true);
    expect(payload.spec.scenes[0].headline).toBe('Hello');
  });

  it('passes previous conversation turns into the prompt', async () => {
    const fake = scripted([{choices: [{message: {role: 'assistant', content: 'Hello.'}}]}]);
    await runAgent(
      {
        settings,
        spec: spec(),
        prompt: 'make it shorter',
        history: [
          {role: 'user', text: 'make a launch video'},
          {role: 'assistant', text: 'Done — five scenes, 16 seconds.'},
        ],
      },
      {chat: fake.chat},
    );

    const messages = fake.seen[0];
    expect(messages[1]).toMatchObject({role: 'user', content: 'make a launch video'});
    expect(messages[2]).toMatchObject({role: 'assistant', content: 'Done — five scenes, 16 seconds.'});
    expect(messages[3].content).toContain('make it shorter');
    expect(messages[3].content).toContain('<current_video_spec>');
  });

  it('leaves the video alone when the model only answers a question', async () => {
    const fake = scripted([{choices: [{message: {role: 'assistant', content: 'It runs 16.5 seconds.'}}]}]);
    const before = spec();
    const result = await runAgent({settings, spec: before, prompt: 'how long is it?', history: []}, {chat: fake.chat});
    expect(result.changed).toBe(false);
    expect(result.spec).toEqual(before);
    expect(result.reply).toBe('It runs 16.5 seconds.');
  });

  it('reports a bad tool call instead of throwing', async () => {
    const fake = scripted([
      {
        choices: [
          {
            message: {
              role: 'assistant',
              content: null,
              tool_calls: [{id: 'call_bad', type: 'function', function: {name: 'update_scene', arguments: '{not json'}}],
            },
          },
        ],
      },
      {choices: [{message: {role: 'assistant', content: 'That did not work.'}}]},
    ]);
    const events: AgentEvent[] = [];
    const result = await runAgent(
      {settings, spec: spec(), prompt: 'edit', history: [], onEvent: (event) => events.push(event)},
      {chat: fake.chat},
    );
    expect(result.changed).toBe(false);
    expect(events.some((event) => event.type === 'tool' && event.ok === false)).toBe(true);
  });

  it('propagates provider errors without applying any unreceived changes', async () => {
    const before = spec();
    const chat = (async () => {
      throw new Error('provider unavailable');
    }) as unknown as typeof import('../src/lib/api').chatCompletion;
    await expect(runAgent({settings, spec: before, prompt: 'edit this', history: []}, {chat})).rejects.toThrow('provider unavailable');
    expect(before).toEqual(spec());
  });

  it('stops after the maximum number of rounds', async () => {
    const fake = scripted([
      {
        choices: [
          {
            message: {
              role: 'assistant',
              content: null,
              tool_calls: [toolCall('get_spec', {}, 'call_loop')],
            },
          },
        ],
      },
    ]);
    const result = await runAgent({settings, spec: spec(), prompt: 'loop', history: []}, {chat: fake.chat});
    expect(result.rounds).toBe(MAX_TOOL_ROUNDS);
  });
});
