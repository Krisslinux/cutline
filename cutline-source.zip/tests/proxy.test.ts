import {afterEach, describe, expect, it, vi} from 'vitest';
import {handleChatRequest, isPrivateHostname, readTokenUsage, requestChatCompletion, resolveChatEndpoint} from '../shared/chat';
import {explainStatus, verifyToolCallingCompletion} from '../src/lib/api';

const request = (body: unknown): Request =>
  new Request('http://localhost/api/chat', {
    method: 'POST',
    headers: {'content-type': 'application/json'},
    body: JSON.stringify(body),
  });

const validBody = {
  baseUrl: 'https://api.example.com/v1',
  apiKey: 'secret-token',
  model: 'example-model',
  messages: [{role: 'user', content: 'hi'}],
};

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('provider token usage', () => {
  it('reads common provider usage fields and accumulates reported calls', () => {
    const first = readTokenUsage({usage: {prompt_tokens: 9, completion_tokens: 4, total_tokens: 13}});
    const second = readTokenUsage({usage: {input_tokens: 6, output_tokens: 2}});
    expect(first).toEqual({inputTokens: 9, outputTokens: 4, totalTokens: 13, reported: true, requests: 1});
    expect(second).toEqual({inputTokens: 6, outputTokens: 2, totalTokens: 8, reported: true, requests: 1});
  });

  it('retries rate limits and transient provider failures with bounded attempts', async () => {
    const upstream = vi.fn()
      .mockResolvedValueOnce(new Response('busy', {status: 503}))
      .mockResolvedValueOnce(new Response('slow down', {status: 429}))
      .mockResolvedValueOnce(new Response(JSON.stringify({choices: [{message: {content: 'ok'}}]}), {status: 200}));
    vi.stubGlobal('fetch', upstream);
    const result = await requestChatCompletion('https://api.example.com/v1/chat/completions', 'token', {
      model: 'model', messages: [{role: 'user', content: 'hi'}],
    });
    expect(result.ok).toBe(true);
    expect(upstream).toHaveBeenCalledTimes(3);
    expect(upstream.mock.calls[0][1]?.body).toBe(upstream.mock.calls[2][1]?.body);
  });

  it.each([
    [401, 'rejected'],
    [402, 'payment required'],
    [429, JSON.stringify({error: {code: 'insufficient_quota', message: 'Out of credits'}})],
    [429, JSON.stringify({error: {message: 'Monthly quota exceeded'}})],
  ])('does not retry credential, billing, or exhausted-quota failures (%s)', async (status, responseBody) => {
    const upstream = vi.fn(async () => new Response(responseBody, {status}));
    vi.stubGlobal('fetch', upstream);
    const result = await requestChatCompletion('https://api.example.com/v1/chat/completions', 'token', {
      model: 'model', messages: [{role: 'user', content: 'hi'}],
    });
    expect(result).toMatchObject({ok: false, status});
    expect(upstream).toHaveBeenCalledTimes(1);
  });

  it('caps retries for a persistent provider outage', async () => {
    const upstream = vi.fn(async () => new Response('busy', {status: 503}));
    vi.stubGlobal('fetch', upstream);
    const result = await requestChatCompletion('https://api.example.com/v1/chat/completions', 'token', {
      model: 'model', messages: [{role: 'user', content: 'hi'}],
    });
    expect(result).toMatchObject({ok: false, status: 503});
    expect(upstream).toHaveBeenCalledTimes(3);
  });

  it('stops backoff immediately when the caller aborts', async () => {
    const controller = new AbortController();
    const upstream = vi.fn(async () => new Response('busy', {status: 503}));
    vi.stubGlobal('fetch', upstream);
    const request = requestChatCompletion('https://api.example.com/v1/chat/completions', 'token', {
      model: 'model', messages: [{role: 'user', content: 'hi'}],
    }, {signal: controller.signal});
    await vi.waitFor(() => expect(upstream).toHaveBeenCalledTimes(1));
    controller.abort();
    await expect(request).rejects.toBeDefined();
    expect(upstream).toHaveBeenCalledTimes(1);
  });
});

describe('tool-call compatibility checks', () => {
  it('only passes when the configured tool is explicitly called', () => {
    expect(() => verifyToolCallingCompletion({
      choices: [{message: {tool_calls: [{id: 'call_1', function: {name: 'cutline_compatibility_check', arguments: '{}'}}]}}],
    })).not.toThrow();
    expect(() => verifyToolCallingCompletion({choices: [{message: {content: 'ready'}}]})).toThrow(/support.*function\/tool calling/i);
  });
});

describe('provider troubleshooting guidance', () => {
  it.each([
    [401, 'token'],
    [402, 'billing'],
    [404, 'model id'],
    [429, 'quota'],
    [503, 'try again'],
  ])('explains provider status %s with a useful recovery hint', (status, hint) => {
    expect(explainStatus(status, 'provider detail').toLowerCase()).toContain(hint);
  });
});

describe('resolveChatEndpoint', () => {
  it('accepts a base URL with a version path', () => {
    expect(resolveChatEndpoint('https://api.openai.com/v1')).toBe('https://api.openai.com/v1/chat/completions');
    expect(resolveChatEndpoint('https://api.openai.com/v1/')).toBe('https://api.openai.com/v1/chat/completions');
  });

  it('keeps a full chat completions URL as-is', () => {
    expect(resolveChatEndpoint('https://api.example.com/v1/chat/completions')).toBe(
      'https://api.example.com/v1/chat/completions',
    );
  });

  it('rejects non-http protocols and garbage', () => {
    expect(() => resolveChatEndpoint('file:///etc/passwd')).toThrow(/http/);
    expect(() => resolveChatEndpoint('not a url')).toThrow(/URL/);
  });
});

describe('private endpoint protection', () => {
  it.each([
    '127.0.0.1',
    'localhost',
    'app.localhost',
    '10.1.2.3',
    '192.168.0.5',
    '172.20.1.1',
    '169.254.169.254',
    '0.0.0.0',
    '100.64.0.9',
    '[::1]',
    'fd00::1',
    'metadata.google.internal',
    'machine.internal',
    'printer.local',
  ])('blocks %s', (hostname) => {
    expect(isPrivateHostname(hostname)).toBe(true);
  });

  it.each(['api.openai.com', 'openrouter.ai', '8.8.8.8', '203.0.114.5', 'gateway.example.dev'])('allows %s', (hostname) => {
    expect(isPrivateHostname(hostname)).toBe(false);
  });

  it('refuses a local base URL by default', async () => {
    const response = await handleChatRequest(
      request({...validBody, baseUrl: 'http://127.0.0.1:11434/v1', messages: [{role: 'user', content: 'hi'}]}),
    );
    expect(response.status).toBe(400);
    expect(await response.text()).toContain('private or local address');
  });

  it('forwards to a local base URL when the operator allows it', async () => {
    const upstream = vi.fn(async (_url: string, _init?: RequestInit) =>
      new Response(JSON.stringify({choices: [{message: {content: 'local'}}]}), {status: 200}),
    );
    vi.stubGlobal('fetch', upstream);
    const response = await handleChatRequest(
      request({...validBody, baseUrl: 'http://127.0.0.1:11434/v1', messages: [{role: 'user', content: 'hi'}]}),
      {allowPrivateEndpoints: true},
    );
    expect(response.status).toBe(200);
    expect(upstream.mock.calls[0][0]).toBe('http://127.0.0.1:11434/v1/chat/completions');
  });

  it('rejects oversized request bodies', async () => {
    const response = await handleChatRequest(
      request({...validBody, messages: [{role: 'user', content: 'x'.repeat(600 * 1024)}]}),
    );
    expect(response.status).toBe(413);
  });
});

describe('handleChatRequest', () => {
  it('validates the fields the editor needs', async () => {
    const missingUrl = await handleChatRequest(request({...validBody, baseUrl: ''}));
    expect(missingUrl.status).toBe(400);
    expect(await missingUrl.json()).toMatchObject({error: {message: expect.stringContaining('baseUrl')}});

    const missingModel = await handleChatRequest(request({...validBody, model: ''}));
    expect(missingModel.status).toBe(400);

    const noMessages = await handleChatRequest(request({...validBody, messages: []}));
    expect(noMessages.status).toBe(400);
  });

  it('allows keyless endpoints and omits the authorization header', async () => {
    const upstream = vi.fn(async (_url: string, _init?: RequestInit) =>
      new Response(JSON.stringify({choices: [{message: {content: 'local'}}]}), {status: 200}),
    );
    vi.stubGlobal('fetch', upstream);
    const response = await handleChatRequest(request({...validBody, apiKey: ''}));
    expect(response.status).toBe(200);
    const headers = new Headers(upstream.mock.calls[0][1]?.headers);
    expect(headers.get('authorization')).toBeNull();
  });

  it('rejects non-POST methods', async () => {
    const response = await handleChatRequest(new Request('http://localhost/api/chat'));
    expect(response.status).toBe(405);
  });

  it('sends sampled images and video frames as vision input to the provider', async () => {
    const upstream = vi.fn(async (_url: string, _init?: RequestInit) => new Response(JSON.stringify({choices: [{message: {content: 'ok'}}]}), {status: 200}));
    vi.stubGlobal('fetch', upstream);
    const attachments = [
      {id: 'img_1', name: 'photo.jpg', kind: 'image', mimeType: 'image/jpeg', frames: [{timeSeconds: 0, dataUrl: 'data:image/jpeg;base64,AQID'}]},
      {id: 'vid_1', name: 'clip.mp4', kind: 'video', mimeType: 'video/mp4', frames: [{timeSeconds: 1, dataUrl: 'data:image/jpeg;base64,BAUG'}, {timeSeconds: 2, dataUrl: 'data:image/jpeg;base64,BwgJ'}]},
    ];
    const response = await handleChatRequest(request({...validBody, attachments}));
    expect(response.status).toBe(200);
    const payload = JSON.parse(String(upstream.mock.calls[0][1]?.body)) as {messages: {content: {type: string; image_url?: {url: string}}[]}[]};
    expect(payload.messages[0].content.map((part) => part.type)).toEqual(['text', 'image_url', 'image_url', 'image_url']);
    expect(payload.messages[0].content.slice(1).map((part) => part.image_url?.url)).toEqual([
      'data:image/jpeg;base64,AQID',
      'data:image/jpeg;base64,BAUG',
      'data:image/jpeg;base64,BwgJ',
    ]);
  });

  it('rejects malformed preview frames before contacting the provider', async () => {
    const upstream = vi.fn(async () => new Response(JSON.stringify({choices: [{message: {content: 'ok'}}]}), {status: 200}));
    vi.stubGlobal('fetch', upstream);
    const response = await handleChatRequest(request({...validBody, attachments: [{id: 'img_1', name: 'bad.jpg', kind: 'image', mimeType: 'image/jpeg', frames: [{timeSeconds: 0, dataUrl: 'https://invalid.example/image.jpg'}]}]}));
    expect(response.status).toBe(400);
    expect(upstream).not.toHaveBeenCalled();
  });

  it('forwards to the provider with the bearer token and tool choice', async () => {
    const upstream = vi.fn(async () => new Response(JSON.stringify({choices: [{message: {content: 'ok'}}]}), {status: 200}));
    vi.stubGlobal('fetch', upstream);

    const response = await handleChatRequest(
      request({
        ...validBody,
        tools: [{type: 'function', function: {name: 'get_spec', parameters: {type: 'object', properties: {}}}}],
        toolChoice: {type: 'function', function: {name: 'get_spec'}},
      }),
    );

    expect(response.status).toBe(200);
    const [url, init] = upstream.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toBe('https://api.example.com/v1/chat/completions');
    const headers = new Headers(init.headers);
    expect(headers.get('authorization')).toBe('Bearer secret-token');
    const payload = JSON.parse(String(init.body)) as Record<string, unknown>;
    expect(payload.model).toBe('example-model');
    expect(payload.stream).toBe(false);
    expect(payload.tool_choice).toEqual({type: 'function', function: {name: 'get_spec'}});
    expect(Array.isArray(payload.tools)).toBe(true);

    const body = await response.json();
    expect(body).toMatchObject({choices: [{message: {content: 'ok'}}]});
  });

  it('does not send tools when none are provided', async () => {
    const upstream = vi.fn(async (_url: string, _init?: RequestInit) =>
      new Response(JSON.stringify({choices: []}), {status: 200}),
    );
    vi.stubGlobal('fetch', upstream);
    await handleChatRequest(request(validBody));
    const init = upstream.mock.calls[0][1];
    const payload = JSON.parse(String(init?.body)) as Record<string, unknown>;
    expect(payload.tools).toBeUndefined();
    expect(payload.tool_choice).toBeUndefined();
  });

  it('treats a provider error object in a successful HTTP response as a failure', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => new Response(JSON.stringify({error: {message: 'Quota exceeded'}}), {status: 200})),
    );
    const response = await handleChatRequest(request(validBody));
    expect(response.status).toBe(502);
    expect(await response.json()).toMatchObject({error: {message: 'Quota exceeded'}});
  });

  it('passes provider errors through with their status and message', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => new Response(JSON.stringify({error: {message: 'Incorrect API key provided'}}), {status: 401})),
    );
    const response = await handleChatRequest(
      request({...validBody, baseUrl: 'https://api.example.com/chat/completions'}),
    );
    expect(response.status).toBe(401);
    const body = (await response.json()) as {error: {message: string; providerStatus: number}};
    expect(body.error.message).toBe('Incorrect API key provided');
    expect(body.error.providerStatus).toBe(401);
  });

  it('explains an unreachable endpoint without leaking the token', async () => {
    vi.stubGlobal(
      'fetch',
      vi.fn(async () => {
        throw new Error('getaddrinfo ENOTFOUND api.example.com');
      }),
    );
    const response = await handleChatRequest(request(validBody));
    expect(response.status).toBe(502);
    const raw = await response.text();
    expect(raw).toContain('Could not reach api.example.com');
    expect(raw).not.toContain('secret-token');
  });
});
