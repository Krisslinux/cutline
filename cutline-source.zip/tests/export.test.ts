import {describe, expect, it, vi} from 'vitest';
import {strToU8, unzipSync, zipSync} from 'fflate';
import type {MediaAttachment} from '../src/types';
import {buildProjectFiles, downloadProjectZip} from '../src/lib/export-project';
import {DEFAULT_SPEC, normalizeSpec, totalFrames} from '../src/lib/spec';

const spec = normalizeSpec(DEFAULT_SPEC);
const files = buildProjectFiles(spec);

describe('buildProjectFiles', () => {
  it('ships the same renderer the editor previews', () => {
    const renderer = String(files['src/video/Video.tsx']);
    expect(renderer).toContain('export const Video');
    expect(renderer).toContain("from 'remotion'");
    expect(renderer).toContain("from '../types'");
    expect(String(files['src/types.ts'])).toContain('export interface VideoSpec');
  });

  it('writes a spec that survives a round trip', () => {
    const parsed = normalizeSpec(JSON.parse(String(files['src/spec.json'])));
    expect(parsed.meta).toEqual(spec.meta);
    expect(parsed.theme).toEqual(spec.theme);
    expect(parsed.scenes).toEqual(spec.scenes);
  });

  it('derives the composition size and duration from the spec', () => {
    const root = String(files['src/Root.tsx']);
    expect(root).toContain('durationInFrames');
    expect(root).toContain('fps={spec.meta.fps}');
    expect(root).toContain('width={spec.meta.width}');
    expect(root).toContain('height={spec.meta.height}');
    expect(JSON.parse(String(files['src/spec.json'])).scenes.length).toBe(spec.scenes.length);
  });

  it('includes selected image and video attachment files in the portable project', async () => {
    const image: MediaAttachment = {
      id: 'image_1',
      name: 'logo.jpg',
      kind: 'image',
      mimeType: 'image/jpeg',
      frames: [{timeSeconds: 0, dataUrl: 'data:image/jpeg;base64,AQID'}],
    };
    const video: MediaAttachment = {
      id: 'video_1',
      name: 'clip.mp4',
      kind: 'video',
      mimeType: 'video/mp4',
      durationSeconds: 4,
      frames: [{timeSeconds: 1, dataUrl: 'data:image/jpeg;base64,BAUG'}],
      videoBlob: new Blob([new Uint8Array([7, 8, 9])], {type: 'video/mp4'}),
    };
    const withMedia = normalizeSpec({
      ...spec,
      scenes: [
        {...spec.scenes[0], kind: 'image', mediaAttachmentId: image.id},
        {...spec.scenes[1], kind: 'image', mediaAttachmentId: video.id},
      ],
    });
    const files = buildProjectFiles(withMedia, {media: [image, video]});
    const portableSpec = JSON.parse(String(files['src/spec.json']));
    expect(portableSpec.scenes[0].imageUrl).toBe('/media/image_1-0.jpg');
    expect(portableSpec.scenes[1].mediaAttachmentId).toBe(video.id);
    expect(files['public/media/image_1-0.jpg']).toEqual(new Uint8Array([1, 2, 3]));

    const zipFiles = {...files, 'public/media/video_1-clip.mp4': new Uint8Array([7, 8, 9])};
    const zipped = zipSync(
      Object.fromEntries(Object.entries(zipFiles).map(([path, contents]) => [path, typeof contents === 'string' ? strToU8(contents) : contents])),
    );
    const extracted = unzipSync(zipped);
    expect(extracted['public/media/video_1-clip.mp4']).toEqual(new Uint8Array([7, 8, 9]));

    const createObjectURL = vi.fn((_blob: Blob) => 'blob:zip');
    const revokeObjectURL = vi.fn();
    const append = vi.fn();
    const remove = vi.fn();
    vi.stubGlobal('URL', {createObjectURL, revokeObjectURL});
    vi.stubGlobal('document', {
      createElement: () => ({href: '', download: '', click: vi.fn(), remove}),
      body: {appendChild: append},
    });
    try {
      await downloadProjectZip(withMedia, {media: [image, video]});
      expect(createObjectURL).toHaveBeenCalledOnce();
      const downloaded = createObjectURL.mock.calls[0][0] as Blob;
      const downloadedFiles = unzipSync(new Uint8Array(await downloaded.arrayBuffer()));
      expect(downloadedFiles['public/media/video_1-clip.mp4']).toEqual(new Uint8Array([7, 8, 9]));
      expect(downloadedFiles['public/media/image_1-0.jpg']).toEqual(new Uint8Array([1, 2, 3]));
      expect(append).toHaveBeenCalledOnce();
      expect(remove).toHaveBeenCalledOnce();
    } finally {
      vi.unstubAllGlobals();
    }
  });

  it('registers the root and documents studio + render scripts', () => {
    expect(String(files['src/index.ts'])).toContain('registerRoot(RemotionRoot)');
    const pkg = JSON.parse(String(files['package.json'])) as {scripts: Record<string, string>};
    expect(pkg.scripts.studio).toContain('remotion studio');
    expect(pkg.scripts.render).toContain('remotion render');
    expect(String(files['README.md'])).toContain('npm run render');
    expect(String(files['README.md'])).toContain(`${(totalFrames(spec) / spec.meta.fps).toFixed(1)}s`);
  });
});
