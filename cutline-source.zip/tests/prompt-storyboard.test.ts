import {afterEach, describe, expect, it, vi} from 'vitest';
import type {MediaAttachment} from '../src/types';
import {createPromptStoryboard} from '../src/lib/prompt-storyboard';
import {totalSeconds} from '../src/lib/spec';
import type {AiSettings} from '../src/lib/settings';

const settings: AiSettings = {baseUrl: 'https://api.example.com/v1', apiKey: 'test-token', model: 'vision-model'};
const frame = {timeSeconds: 0, dataUrl: 'data:image/jpeg;base64,AQID'};
const image: MediaAttachment = {id: 'image_a', name: 'still.jpg', kind: 'image', mimeType: 'image/jpeg', frames: [frame], imageBlob: new Blob([new Uint8Array([1])])};
const video: MediaAttachment = {id: 'video_a', name: 'clip.mp4', kind: 'video', mimeType: 'video/mp4', durationSeconds: 18, frames: [{...frame,timeSeconds: 3},{...frame,timeSeconds: 9}], videoBlob: new Blob([new Uint8Array([2])])};
const audio: MediaAttachment = {id: 'audio_a', name: 'voice.mp3', kind: 'audio', mimeType: 'audio/mpeg', durationSeconds: 15, frames: [frame], audioBlob: new Blob([new Uint8Array([3])]), audioBytes: 1};
const makeScenePlan = (sourceId: string, durationSeconds = 8, extras: Record<string, unknown> = {}) => ({kind: 'image', sourceId, durationSeconds, headline: 'A story', ...extras});
const mockPlan = (scenes: unknown[], aspect: string = '9:16') => {
  const response = {
    choices: [{message: {role: 'assistant', content: null, tool_calls: [{id: 'call_story', type: 'function', function: {name: 'create_video_storyboard', arguments: JSON.stringify({title: 'Story film', aspect, scenes})}}]}}],
    usage: {prompt_tokens: 42, completion_tokens: 14, total_tokens: 56},
  };
  const fetchMock = vi.fn(async (_url: string, init?: RequestInit) => new Response(JSON.stringify(response), {status: 200}));
  vi.stubGlobal('fetch', fetchMock);
  return fetchMock;
};

afterEach(() => vi.unstubAllGlobals());

describe('createPromptStoryboard', () => {
  it('sends selected image previews and sampled video frames to the configured tool-calling provider', async () => {
    const fetchMock = mockPlan([makeScenePlan('image_a'), makeScenePlan('video_a')]);
    const result = await createPromptStoryboard(settings, 'Make a vertical travel reel', [image, video]);
    expect(fetchMock).toHaveBeenCalledOnce();
    const body = JSON.parse(String(fetchMock.mock.calls[0][1]?.body)) as {baseUrl: string; apiKey: string; model: string; attachments: MediaAttachment[]; tools: unknown[]; toolChoice: unknown};
    expect(body).toMatchObject({baseUrl: settings.baseUrl, apiKey: settings.apiKey, model: settings.model});
    expect(body.attachments.map(({id}) => id)).toEqual(['image_a', 'video_a']);
    expect(body.tools).toHaveLength(1);
    expect(body.toolChoice).toEqual({type: 'function', function: {name: 'create_video_storyboard'}});
    expect(result.spec.meta.aspect).toBe('9:16');
    expect(result.spec.scenes.map(({mediaAttachmentId}) => mediaAttachmentId)).toEqual(['image_a', 'video_a']);
    expect(result.spec.scenes[1].keepSourceAudio).toBe(true);
    expect(result.usage.totalTokens).toBe(56);
  });

  it('attaches external soundtrack once, mutes clip audio, and fits the edit to soundtrack duration', async () => {
    mockPlan([makeScenePlan('video_a', 12), makeScenePlan('image_a', 12)], '16:9');
    const result = await createPromptStoryboard(settings, 'Narrate this video with the supplied audio', [video, image, audio]);
    expect(result.spec.scenes[0].audioAttachmentId).toBe(audio.id);
    expect(result.spec.scenes.every((scene) => scene.keepSourceAudio === false)).toBe(true);
    expect(totalSeconds(result.spec)).toBeLessThanOrEqual(audio.durationSeconds!);
    expect(totalSeconds(result.spec)).toBeGreaterThan(0);
  });

  it('preserves an edit at exactly two minutes and clips overlong generated plans to the cap', async () => {
    mockPlan(Array.from({length: 6}, (_, index) => makeScenePlan('image_a', 20, {headline: `Scene ${index}`})), '16:9');
    const result = await createPromptStoryboard(settings, 'Make a two-minute story', [image]);
    expect(totalSeconds(result.spec)).toBe(120);
    expect(result.spec.scenes).toHaveLength(6);
  });

  it('rejects unknown source ids and trims outside the source clip', async () => {
    mockPlan([makeScenePlan('not-uploaded')]);
    await expect(createPromptStoryboard(settings, 'make a cut', [image])).rejects.toThrow(/not uploaded/);
    mockPlan([makeScenePlan('video_a', 6, {sourceStartSeconds: 17, sourceEndSeconds: 19})]);
    await expect(createPromptStoryboard(settings, 'make a cut', [video])).rejects.toThrow(/outside the uploaded clip/);
  });

  it('rejects storyboard durations exceeding the two-minute limit and trims video scenes to source bounds', async () => {
    const longVideo: MediaAttachment = {...video, durationSeconds: 120};
    mockPlan(Array.from({length: 16}, (_, index) => makeScenePlan('image_a', 20, {headline: `Scene ${index}`})), '16:9');
    const capped = await createPromptStoryboard(settings, 'use the full allowed duration', [image]);
    expect(totalSeconds(capped.spec)).toBe(120);
    mockPlan([makeScenePlan('video_a', 20)], '16:9');
    const trimmed = await createPromptStoryboard(settings, 'use this entire clip', [longVideo]);
    expect(trimmed.spec.scenes[0].durationInFrames).toBe(600);
    expect(totalSeconds(trimmed.spec)).toBe(20);
  });

  it('rejects audio-only edits and requests without credentials before contacting a provider', async () => {
    const fetchMock = vi.fn();
    vi.stubGlobal('fetch', fetchMock);
    await expect(createPromptStoryboard(settings, 'make a film', [audio])).rejects.toThrow(/at least one image or video/);
    await expect(createPromptStoryboard({...settings, apiKey: ''}, 'make a film', [image])).rejects.toThrow(/API token/);
    expect(fetchMock).not.toHaveBeenCalled();
  });
});
