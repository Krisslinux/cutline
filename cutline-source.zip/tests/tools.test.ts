import {describe, expect, it} from 'vitest';
import {applyTool} from '../src/lib/tools';
import {DEFAULT_SPEC, normalizeSpec} from '../src/lib/spec';
import type {VideoSpec} from '../src/types';

const base = (): VideoSpec => normalizeSpec(DEFAULT_SPEC);

describe('applyTool', () => {
  it('adds a scene at the requested index with a unique id', () => {
    const spec = base();
    const outcome = applyTool(spec, 'add_scene', {kind: 'outro', headline: 'Fin', index: 1, durationSeconds: 2.5});
    expect(outcome.ok).toBe(true);
    expect(outcome.spec.scenes).toHaveLength(spec.scenes.length + 1);
    expect(outcome.spec.scenes[1].headline).toBe('Fin');
    expect(outcome.spec.scenes[1].durationInFrames).toBe(75);
    const ids = outcome.spec.scenes.map((scene) => scene.id);
    expect(new Set(ids).size).toBe(ids.length);
  });

  it('updates copy and converts duration seconds to frames', () => {
    const spec = base();
    const id = spec.scenes[0].id;
    const outcome = applyTool(spec, 'update_scene', {id, headline: 'Ship it', durationSeconds: 5});
    expect(outcome.ok).toBe(true);
    expect(outcome.spec.scenes[0].headline).toBe('Ship it');
    expect(outcome.spec.scenes[0].durationInFrames).toBe(150);
    // untouched scenes survive
    expect(outcome.spec.scenes[2]).toEqual(spec.scenes[2]);
  });

  it('clears an optional field when the model sends an empty string', () => {
    const spec = base();
    const id = spec.scenes[0].id;
    const outcome = applyTool(spec, 'update_scene', {id, subhead: ''});
    expect(outcome.ok).toBe(true);
    expect(outcome.spec.scenes[0].subhead).toBeUndefined();
  });

  it('clamps absurd durations into the allowed window', () => {
    const spec = base();
    const outcome = applyTool(spec, 'update_scene', {id: spec.scenes[0].id, durationSeconds: 900});
    expect(outcome.ok).toBe(true);
    expect(outcome.spec.scenes[0].durationInFrames).toBe(20 * spec.meta.fps);
  });

  it('refuses to delete the last scene', () => {
    const spec = base();
    let current = spec;
    for (const scene of spec.scenes.slice(1)) {
      current = applyTool(current, 'remove_scene', {id: scene.id}).spec;
    }
    const outcome = applyTool(current, 'remove_scene', {id: current.scenes[0].id});
    expect(outcome.ok).toBe(false);
    expect(outcome.spec.scenes).toHaveLength(1);
  });

  it('moves a scene using a one-based position', () => {
    const spec = base();
    const last = spec.scenes[spec.scenes.length - 1].id;
    const outcome = applyTool(spec, 'move_scene', {id: last, position: 1});
    expect(outcome.ok).toBe(true);
    expect(outcome.spec.scenes[0].id).toBe(last);
  });

  it('reports unknown scene ids with the available list', () => {
    const outcome = applyTool(base(), 'update_scene', {id: 'sc_nope', headline: 'x'});
    expect(outcome.ok).toBe(false);
    expect(outcome.message).toContain('No scene with that id');
    expect(outcome.message).toContain('sc_1');
  });

  it('switches the canvas to vertical', () => {
    const outcome = applyTool(base(), 'set_format', {aspect: '9:16'});
    expect(outcome.ok).toBe(true);
    expect(outcome.spec.meta.width).toBe(1080);
    expect(outcome.spec.meta.height).toBe(1920);
    expect(outcome.spec.meta.aspect).toBe('9:16');
  });

  it('updates the palette and rejects unsafe colour values', () => {
    const themed = applyTool(base(), 'set_theme', {accent: '#ffcc00', font: 'serif'});
    expect(themed.ok).toBe(true);
    expect(themed.spec.theme.accent).toBe('#ffcc00');
    expect(themed.spec.theme.font).toBe('serif');

    const unsafe = applyTool(base(), 'set_theme', {background: 'url(javascript:alert(1))'});
    expect(unsafe.ok).toBe(false);
  });

  it('rewrites the whole storyboard and keeps ids unique', () => {
    const outcome = applyTool(base(), 'replace_spec', {
      title: 'New cut',
      scenes: [
        {kind: 'title', headline: 'One'},
        {kind: 'quote', quote: 'Two'},
      ],
    });
    expect(outcome.ok).toBe(true);
    expect(outcome.spec.meta.title).toBe('New cut');
    expect(outcome.spec.scenes).toHaveLength(2);
    expect(outcome.spec.scenes[0].id).not.toBe(outcome.spec.scenes[1].id);
  });

  it('fails gracefully on unknown tools', () => {
    const outcome = applyTool(base(), 'rewrite_everything', {});
    expect(outcome.ok).toBe(false);
    expect(outcome.message).toContain('Unknown tool');
  });

  it('leaves the spec untouched when only reading', () => {
    const spec = base();
    const outcome = applyTool(spec, 'get_spec', {});
    expect(outcome.ok).toBe(true);
    expect(outcome.spec).toBe(spec);
  });
});
