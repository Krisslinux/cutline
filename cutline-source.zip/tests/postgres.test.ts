import {it,expect} from 'vitest';
import {randomUUID} from 'node:crypto';
import {openDb,migrate} from '../server/studio-db';
import {StudioStore} from '../server/studio-store';
import {draftTimeline} from '../shared/narration';
it.runIf(Boolean(process.env.TEST_POSTGRES_URL))('uses real Postgres persistence and atomic claims',async()=>{
  const db=await openDb(process.env.TEST_POSTGRES_URL);await migrate(db);const store=new StudioStore(db),owner=randomUUID();
  try{
    await db.query('INSERT INTO owners(id,username,password_hash) VALUES($1,$2,$3)',[owner,owner,'test-hash']);
    const p=await store.create(owner,{title:'Postgres validation'});
    for(const kind of ['audio','image'])await db.query('INSERT INTO assets(id,project_id,owner_id,kind,name,mime,bytes,file_key,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)',[`${kind}_${owner}`,p.id,owner,kind,kind,'test',12,kind,Date.now()]);
    const t=draftTimeline({title:p.title,audioAssetId:`audio_${owner}`,imageAssets:[`image_${owner}`],durationMs:1000,words:[]});
    expect((await store.save(owner,p.id,0,t)).revision).toBe(1);
    const j=await store.enqueue(owner,p.id,'render');
    const claimed=await Promise.all([store.claim('a'),store.claim('b')]);expect(claimed.filter(Boolean)).toHaveLength(1);expect(claimed.find(Boolean)?.id).toBe(j.id);
    await db.query('UPDATE jobs SET lease_until=0 WHERE id=$1',[j.id]);await store.claim('c');expect((await store.job(owner,j.id)).state).toBe('failed');
    const retry=await store.retry(owner,j.id);expect(retry.state).toBe('queued');await expect(store.project('not-owner',p.id)).rejects.toThrow();
  }finally{
    await db.query('DELETE FROM jobs WHERE owner_id=$1',[owner]);await db.query('DELETE FROM assets WHERE owner_id=$1',[owner]);await db.query('DELETE FROM projects WHERE owner_id=$1',[owner]);await db.query('DELETE FROM owners WHERE id=$1',[owner]);await db.close();
  }
});
