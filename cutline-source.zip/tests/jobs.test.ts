import {describe, expect, it} from 'vitest';
import {JobStore, type JobSnapshot} from '../server/jobs';
import {ProviderRequestError} from '../server/provider';
import type {AgentChatFn} from '../server/agent';
import {DEFAULT_SPEC, normalizeSpec} from '../src/lib/spec';

const spec = () => normalizeSpec(DEFAULT_SPEC);

const toolCallResponse = {
  choices: [
    {
      message: {
        role: 'assistant',
        content: null,
        tool_calls: [
          {
            id: 'call_1',
            type: 'function',
            function: {name: 'add_scene', arguments: JSON.stringify({kind: 'outro', headline: 'Fin', cta: 'Go'})},
          },
        ],
      },
    },
  ],
};

const finalResponse = {choices: [{message: {role: 'assistant', content: 'Added a closing scene.'}}]};

const scriptedChat = (): AgentChatFn => {
  let calls = 0;
  return async () => {
    calls += 1;
    const response = structuredClone(calls === 1 ? toolCallResponse : finalResponse) as typeof toolCallResponse;
    return {...response, usage: {prompt_tokens: calls * 10, completion_tokens: calls * 2, total_tokens: calls * 12}} as never;
  };
};

const jobInput = (overrides: Record<string, unknown> = {}) => ({
  baseUrl: 'https://api.example.com/v1',
  apiKey: 'super-secret-key',
  model: 'test-model',
  spec: spec(),
  prompt: 'add a closing scene',
  history: [],
  ip: '203.0.113.9',
  ...overrides,
});

const finished = (snapshot: JobSnapshot): boolean =>
  snapshot.status === 'done' || snapshot.status === 'error' || snapshot.status === 'cancelled';

const settle = async (store: JobStore, id: string, timeoutMs = 3_000): Promise<JobSnapshot> => {
  const existing = store.get(id);
  if (existing && finished(existing)) return existing;

  return new Promise((resolve, reject) => {
    let settled = false;
    let unsubscribe: (() => void) | null = null;
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      unsubscribe?.();
      reject(new Error('job did not settle in time'));
    }, timeoutMs);

    const subscription = store.subscribe(id, (snapshot) => {
      if (!finished(snapshot) || settled) return;
      settled = true;
      clearTimeout(timer);
      unsubscribe?.();
      resolve(snapshot);
    });
    unsubscribe = subscription;
  });
};

describe('JobStore', () => {
  it('runs an edit and exposes progress without leaking credentials', async () => {
    const store = new JobStore({chat: scriptedChat()});
    try {
      const created = store.create(jobInput());
      expect(created.ok).toBe(true);
      if (!created.ok) return;

      const snapshots: JobSnapshot[] = [];
      store.subscribe(created.job.id, (snapshot) => snapshots.push(snapshot));

      const final = await settle(store, created.job.id);
      expect(final.status).toBe('done');
      expect(final.changed).toBe(true);
      expect(final.reply).toBe('Added a closing scene.');
      expect(final.steps.map((step) => step.name)).toEqual(['add_scene']);
      expect(final.spec.scenes).toHaveLength(spec().scenes.length + 1);
      expect(final.spec.scenes[final.spec.scenes.length - 1].headline).toBe('Fin');
      expect(final.usage).toEqual({inputTokens: 30, outputTokens: 6, totalTokens: 36, reported: true, requests: 2});
      expect(snapshots.some((snapshot) => snapshot.usage.requests === 1 && snapshot.usage.totalTokens === 12)).toBe(true);
      expect(snapshots.some((snapshot) => snapshot.status === 'running')).toBe(true);
      expect(JSON.stringify(final)).not.toContain('super-secret-key');
    } finally {
      store.dispose();
    }
  });

  it.each([
    [401, 'Incorrect API key provided', 'rejected your API token'],
    [402, 'Payment required', 'run out of credits'],
    [429, 'Too many requests', 'rate limit or usage limit'],
    [503, 'Service unavailable', 'temporarily unavailable'],
  ])('explains provider failure status %s and preserves the edit', async (status, detail, guidance) => {
    const store = new JobStore({
      chat: async () => {
        throw new ProviderRequestError(status, detail);
      },
    });
    try {
      const created = store.create(jobInput());
      expect(created.ok).toBe(true);
      if (!created.ok) return;
      const final = await settle(store, created.job.id);
      expect(final.status).toBe('error');
      expect(final.changed).toBe(false);
      expect(final.error).toContain(guidance);
      expect(final.error).toContain('current timeline is preserved');
      expect(final.error).not.toContain('super-secret-key');
    } finally {
      store.dispose();
    }
  });

  it('keeps the raw key out of the store snapshot API', async () => {
    const store = new JobStore({chat: scriptedChat()});
    try {
      const created = store.create(jobInput());
      expect(created.ok).toBe(true);
      if (!created.ok) return;
      const serialized = JSON.stringify(store.get(created.job.id));
      expect(serialized).not.toContain('super-secret-key');
      expect(serialized).not.toContain('apiKey');
      await settle(store, created.job.id);
    } finally {
      store.dispose();
    }
  });

  it('limits each visitor to a couple of jobs but lets others edit', async () => {
    const store = new JobStore({chat: scriptedChat(), maxPerIp: 1});
    try {
      const first = store.create(jobInput());
      expect(first.ok).toBe(true);
      const second = store.create(jobInput());
      expect(second.ok).toBe(false);
      if (!second.ok) {
        expect(second.reason).toBe('rate-limited');
        expect(second.message).toContain('in flight');
      }
      const otherVisitor = store.create(jobInput({ip: '198.51.100.4'}));
      expect(otherVisitor.ok).toBe(true);
      if (first.ok) await settle(store, first.job.id);
      if (otherVisitor.ok) await settle(store, otherVisitor.job.id);
    } finally {
      store.dispose();
    }
  });

  it('queues work when all workers are busy', async () => {
    let release: () => void = () => undefined;
    const gate = new Promise<void>((resolve) => {
      release = resolve;
    });
    const chat: AgentChatFn = async () => {
      await gate;
      return finalResponse as never;
    };
    const store = new JobStore({chat, maxConcurrent: 1, maxPerIp: 5});
    try {
      const first = store.create(jobInput());
      const second = store.create(jobInput());
      expect(first.ok && second.ok).toBe(true);
      if (!first.ok || !second.ok) return;

      await new Promise((resolve) => setTimeout(resolve, 50));
      expect(store.stats().running).toBe(1);
      expect(store.get(second.job.id)?.status).toBe('queued');

      release();
      const [a, b] = await Promise.all([settle(store, first.job.id), settle(store, second.job.id)]);
      expect(a.status).toBe('done');
      expect(b.status).toBe('done');
    } finally {
      store.dispose();
    }
  });

  it('cancels a running job and keeps partial work', async () => {
    const chat: AgentChatFn = (_settings, _body, signal) =>
      new Promise((_, reject) => {
        signal?.addEventListener('abort', () => reject(new Error('aborted')));
      });
    const store = new JobStore({chat});
    try {
      const created = store.create(jobInput());
      expect(created.ok).toBe(true);
      if (!created.ok) return;
      await new Promise((resolve) => setTimeout(resolve, 20));
      expect(store.cancel(created.job.id)).toBe(true);
      const final = await settle(store, created.job.id);
      expect(final.status).toBe('cancelled');
      expect(final.error).toContain('Stopped');
    } finally {
      store.dispose();
    }
  });

  it('refuses to start when the queue is full', () => {
    const store = new JobStore({chat: scriptedChat(), maxQueued: 0});
    try {
      const result = store.create(jobInput());
      expect(result.ok).toBe(false);
      if (!result.ok) expect(result.reason).toBe('queue-full');
    } finally {
      store.dispose();
    }
  });
});
