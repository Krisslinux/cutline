import {describe,it,expect} from 'vitest';
import {draftTimeline,timelineSchema,toSrt,captionPages,type CaptionWord} from '../shared/narration';
import {planTimeline} from '../worker/planner';
const words:CaptionWord[]=Array.from({length:24},(_,i)=>({id:`word_${i}`,text:i%6===5?'Neith.':'The',startMs:i*400,endMs:i*400+300}));
const draft=()=>draftTimeline({title:'Mythology',audioAssetId:'audio',imageAssets:['image_a','image_b'],durationMs:10001,words});
describe('narration timeline',()=>{
  it('rounds up duration, assigns repeated images, and explicitly accounts for overlap',()=>{const p=draft();expect(p.durationInFrames).toBe(301);expect(p.shots.length).toBeGreaterThan(1);expect(p.shots[0].startFrame).toBe(0);expect(p.shots.at(-1)!.endFrame).toBe(301);for(let i=1;i<p.shots.length;i++)expect(p.shots[i].startFrame).toBe(p.shots[i-1].endFrame-p.shots[i-1].transitionFrames);});
  it('ends captions before long pauses and preserves every word',()=>{const p=captionPages([{id:'a',text:'Neith',startMs:0,endMs:300},{id:'b',text:'awakens',startMs:2000,endMs:2400}]);expect(p).toHaveLength(2);expect(p[0].endFrame).toBe(9);expect(p[1].startFrame).toBe(60);});
  it('rejects missing assets, gaps, triple overlaps, invalid timings, and malformed plans',()=>{const p=draft();expect(()=>timelineSchema.parse({...p,shots:p.shots.map((s,i)=>i?{...s,startFrame:s.startFrame+1}:s)})).toThrow();expect(()=>timelineSchema.parse({...p,imageAssets:['other']})).toThrow();expect(()=>timelineSchema.parse({...p,captionWords:[{...words[0],endMs:0}]})).toThrow();expect(()=>timelineSchema.parse({...p,durationInFrames:300})).toThrow();expect(()=>timelineSchema.parse({...p,captionPages:[{...p.captionPages[0],text:'rewritten'}]})).toThrow();});
  it('exports actual frame-aligned SRT',()=>{const text=toSrt(draft());expect(text).toContain('00:00:00,000 -->');expect(text).toContain('Neith.');expect(text).not.toContain('undefined');});
  it('offers deterministic drafts without a planning key',async()=>{const p=draft();expect(await planTimeline(p,null,new AbortController().signal)).toEqual(p);expect(await planTimeline(p,{provider:'openai-compatible',baseUrl:'https://example.com/v1',model:'test',apiKey:''},new AbortController().signal)).toEqual(p);});
});
