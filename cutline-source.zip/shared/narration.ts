import {z} from 'zod';
import {createTikTokStyleCaptions} from '@remotion/captions';

export const FPS = 30;
export const WIDTH = 720;
export const HEIGHT = 1280;
export const msToFrame = (ms: number): number => Math.round(ms * FPS / 1000);
export const durationFrames = (ms: number): number => Math.ceil(ms * FPS / 1000);
const identifier = z.string().regex(/^[a-zA-Z0-9_-]{1,100}$/);
export const wordSchema = z.object({
  id: identifier, text: z.string().trim().min(1).max(200),
  startMs: z.number().finite().nonnegative(), endMs: z.number().finite().positive(),
  confidence: z.number().min(0).max(1).optional(), uncertain: z.boolean().optional(),
}).strict();
export const shotSchema = z.object({
  id: identifier, imageAssetId: identifier,
  startFrame: z.number().int().nonnegative(), endFrame: z.number().int().positive(),
  focalPoint: z.object({x: z.number().min(0).max(1), y: z.number().min(0).max(1)}).strict(),
  fit: z.enum(['contain', 'cover']), startScale: z.number().min(1).max(1.2), endScale: z.number().min(1).max(1.2),
  pan: z.object({x: z.number().min(-30).max(30), y: z.number().min(-30).max(30)}).strict(),
  transitionOut: z.enum(['fade', 'diagonal', 'radial', 'none']), transitionFrames: z.number().int().min(0).max(30),
}).strict();
export const pageSchema = z.object({
  id: identifier, wordIds: z.array(identifier).min(1).max(12),
  startFrame: z.number().int().nonnegative(), endFrame: z.number().int().positive(),
  text: z.string().trim().min(1).max(180),
}).strict();
export const timelineSchema = z.object({
  version: z.literal(1), title: z.string().trim().min(1).max(160),
  width: z.literal(720), height: z.literal(1280), fps: z.literal(30),
  durationMs: z.number().finite().positive().max(600_000), durationInFrames: z.number().int().positive(),
  audioAssetId: identifier, imageAssets: z.array(identifier).min(1).max(40),
  captionWords: z.array(wordSchema).max(6000), captionPages: z.array(pageSchema).max(2000),
  shots: z.array(shotSchema).min(1).max(300),
}).strict().superRefine((p, ctx) => {
  const problem = (message: string) => ctx.addIssue({code: 'custom', message});
  if (p.durationInFrames !== durationFrames(p.durationMs)) problem('Duration must round up to cover the complete narration.');
  for (const items of [p.imageAssets, p.captionWords.map(w => w.id), p.captionPages.map(c => c.id), p.shots.map(s => s.id)]) {
    if (new Set(items).size !== items.length) problem('Duplicate identifiers are not allowed.');
  }
  const words = new Map(p.captionWords.map(w => [w.id, w]));
  let lastEnd = 0;
  for (const w of p.captionWords) {
    if (w.endMs <= w.startMs || w.endMs > p.durationMs + 1 || w.startMs < lastEnd - 1) problem('Word timings must be ordered, positive, non-overlapping, and within the narration.');
    lastEnd = w.endMs;
  }
  let pageEnd = 0;
  const usedWords = new Set<string>();
  const orderedWords: string[] = [];
  for (const page of p.captionPages) {
    if (page.endFrame <= page.startFrame || page.endFrame > p.durationInFrames || page.startFrame < pageEnd) problem('Caption pages must be ordered, non-overlapping, and within the video.');
    pageEnd = page.endFrame;
    for (const id of page.wordIds) {
      if (!words.has(id) || usedWords.has(id)) problem('Caption pages must reference known words exactly once.');
      usedWords.add(id); orderedWords.push(id);
    }
    if (page.text !== page.wordIds.map(id => words.get(id)?.text).join(' ')) problem('Caption phrases must preserve the transcript text.');
  }
  if (usedWords.size !== words.size) problem('Every transcript word must belong to a caption page.');
  if (JSON.stringify(orderedWords) !== JSON.stringify(p.captionWords.map(w => w.id))) problem('Caption pages must preserve transcript word order.');
  p.shots.forEach((shot, i) => {
    if (!p.imageAssets.includes(shot.imageAssetId)) problem('Shot references an unknown image asset.');
    if (shot.endFrame <= shot.startFrame || shot.endFrame > p.durationInFrames) problem('Shot timing is out of range.');
    if (shot.transitionOut === 'none' && shot.transitionFrames !== 0) problem('A cut cannot have overlap.');
    if (shot.transitionOut !== 'none' && shot.transitionFrames === 0 && i < p.shots.length - 1) problem('A transition needs a positive overlap.');
    const previous = p.shots[i - 1];
    if (i === 0 && shot.startFrame !== 0) problem('The first shot must start at frame zero.');
    if (previous && shot.startFrame !== previous.endFrame - previous.transitionFrames) problem('Shot boundaries must account for the preceding overlap exactly.');
    if (shot.endFrame - shot.startFrame <= (previous?.transitionFrames ?? 0) + shot.transitionFrames) problem('Overlaps must not consume an entire shot or create triple overlaps.');
    if (i === p.shots.length - 1 && (shot.endFrame !== p.durationInFrames || shot.transitionFrames !== 0)) problem('The final shot must cover the end without a trailing transition.');
  });
});
export type CaptionWord = z.infer<typeof wordSchema>;
export type CaptionPage = z.infer<typeof pageSchema>;
export type Shot = z.infer<typeof shotSchema>;
export type NarrationTimeline = z.infer<typeof timelineSchema>;

export function captionPages(words: CaptionWord[]): CaptionPage[] {
  const {pages: timingPages} = createTikTokStyleCaptions({captions: words.map(w => ({text: ` ${w.text}`, startMs: w.startMs, endMs: w.endMs, timestampMs: w.startMs, confidence: w.confidence ?? null})), combineTokensWithinMilliseconds: 2200, breakOnSilenceAfterMilliseconds: 450});
  const breaks = new Set(timingPages.slice(1).map(p => p.startMs));
  const groups: CaptionWord[][] = [];
  let group: CaptionWord[] = [];
  for (const w of words) {
    const prior = group.at(-1);
    if (group.length && (group.length >= 6 || (breaks.has(w.startMs) && group.length >= 3) || w.startMs - prior!.endMs > 450 || group.map(x => x.text).join(' ').length + w.text.length > 48)) {
      groups.push(group); group = [];
    }
    group.push(w);
    if (/[.!?;:]$/.test(w.text) && group.length >= 3) { groups.push(group); group = []; }
  }
  if (group.length) groups.push(group);
  return groups.map((g, i) => ({id: `caption_${i}`, wordIds: g.map(w => w.id), text: g.map(w => w.text).join(' '),
    startFrame: msToFrame(g[0].startMs), endFrame: Math.max(msToFrame(g[0].startMs) + 1, msToFrame(g.at(-1)!.endMs))}));
}

export function draftTimeline(input: {title: string; audioAssetId: string; imageAssets: string[]; durationMs: number; words: CaptionWord[]}): NarrationTimeline {
  const frames = durationFrames(input.durationMs);
  const boundaries = [0];
  let start = 0;
  for (let i = 0; i < input.words.length - 1; i++) {
    const w = input.words[i]; const next = input.words[i + 1];
    const at = msToFrame(next.startMs);
    if (at - start >= 90 && (/[.!?;:]$/.test(w.text) || next.startMs - w.endMs > 500 || at - start >= 210) && frames - at >= 45) {
      boundaries.push(at); start = at;
    }
  }
  if (boundaries.length === 1 && frames > 240) {
    for (let f = 150; frames - f >= 60; f += 150) boundaries.push(f);
  }
  const shots: Shot[] = boundaries.map((startFrame, i) => {
    const final = i === boundaries.length - 1;
    const overlap = final ? 0 : 18;
    return {id: `shot_${i}`, imageAssetId: input.imageAssets[i % input.imageAssets.length], startFrame,
      endFrame: final ? frames : boundaries[i + 1] + overlap,
      focalPoint: {x: .5, y: .5}, fit: 'contain', startScale: 1.006, endScale: 1.045,
      pan: {x: i % 2 ? -6 : 6, y: -3}, transitionOut: final ? 'none' : (['fade', 'diagonal', 'fade', 'radial'] as const)[i % 4], transitionFrames: overlap};
  });
  return timelineSchema.parse({version: 1, title: input.title, width: WIDTH, height: HEIGHT, fps: FPS,
    durationMs: input.durationMs, durationInFrames: frames, audioAssetId: input.audioAssetId, imageAssets: input.imageAssets,
    captionWords: input.words, captionPages: captionPages(input.words), shots});
}

export function toSrt(p: NarrationTimeline): string {
  const timestamp = (frame: number) => {
    const ms = Math.round(frame * 1000 / FPS);
    return `${String(Math.floor(ms / 3600000)).padStart(2, '0')}:${String(Math.floor(ms / 60000) % 60).padStart(2, '0')}:${String(Math.floor(ms / 1000) % 60).padStart(2, '0')},${String(ms % 1000).padStart(3, '0')}`;
  };
  return p.captionPages.map((c, i) => `${i + 1}\n${timestamp(c.startFrame)} --> ${timestamp(c.endFrame)}\n${c.text}\n`).join('\n');
}
