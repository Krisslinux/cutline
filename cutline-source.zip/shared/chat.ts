/**
 * Provider plumbing shared by the browser-facing proxy and the background job
 * worker. Web standards only, so it runs in Node and in Workers.
 *
 * The token travels per request/job, is never persisted, and is never logged.
 */

import {normalizeAttachments, type MediaAttachment, type TokenUsage} from './media.ts';

const MAX_MESSAGES = 80;
export const MAX_REQUEST_BYTES = 512 * 1024;
export const MAX_JOB_REQUEST_BYTES = 3 * 1024 * 1024;
const UPSTREAM_TIMEOUT_MS = 150_000;
const TRANSIENT_RETRY_DELAYS_MS = [400, 1_000] as const;
const MAX_RETRY_AFTER_MS = 10_000;

const isTransientStatus = (status: number): boolean => status === 429 || (status >= 500 && status < 600);

const getRetryDelayMs = (response: Response, retryIndex: number): number => {
  const retryAfter = response.headers.get('retry-after');
  if (retryAfter) {
    const seconds = Number(retryAfter);
    const retryAt = Number.isFinite(seconds) ? Date.now() + seconds * 1_000 : Date.parse(retryAfter);
    if (Number.isFinite(retryAt)) return Math.min(MAX_RETRY_AFTER_MS, Math.max(0, retryAt - Date.now()));
  }
  return TRANSIENT_RETRY_DELAYS_MS[retryIndex - 1] ?? TRANSIENT_RETRY_DELAYS_MS.at(-1)!;
};

const waitForRetry = (milliseconds: number, signal: AbortSignal): Promise<void> =>
  new Promise((resolve, reject) => {
    if (signal.aborted) {
      reject(signal.reason ?? new DOMException('Aborted', 'AbortError'));
      return;
    }
    const timer = setTimeout(() => {
      signal.removeEventListener('abort', onAbort);
      resolve();
    }, milliseconds);
    const onAbort = () => {
      clearTimeout(timer);
      signal.removeEventListener('abort', onAbort);
      reject(signal.reason ?? new DOMException('Aborted', 'AbortError'));
    };
    signal.addEventListener('abort', onAbort, {once: true});
  });

const JSON_HEADERS = {
  'content-type': 'application/json; charset=utf-8',
  'cache-control': 'no-store',
};

const reply = (data: unknown, status = 200): Response =>
  new Response(JSON.stringify(data), {status, headers: JSON_HEADERS});

const failure = (message: string, status = 400): Response => reply({error: {message}}, status);

export interface ToolCall {
  id: string;
  type?: string;
  function: {name: string; arguments: string};
}

export type ChatContentPart =
  | {type: 'text'; text: string}
  | {type: 'image_url'; image_url: {url: string; detail?: 'low' | 'high' | 'auto'}};

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string | ChatContentPart[] | null;
  tool_calls?: ToolCall[];
  tool_call_id?: string;
}

export interface ChatCompletion {
  usage?: {
    prompt_tokens?: number;
    prompt_tokens_details?: {cached_tokens?: number; audio_tokens?: number};
    completion_tokens_details?: {reasoning_tokens?: number; audio_tokens?: number};
    completion_tokens?: number;
    total_tokens?: number;
    input_tokens?: number;
    output_tokens?: number;
    promptTokens?: number;
    completionTokens?: number;
    totalTokens?: number;
  };
  choices?: {
    message?: {
      role?: string;
      content?: string | null;
      tool_calls?: ToolCall[];
    };
    finish_reason?: string;
  }[];
  error?: {message?: string};
}

export interface ChatRequestPayload {
  model: string;
  messages: ChatMessage[];
  tools?: unknown[];
  toolChoice?: unknown;
  temperature?: number;
  attachments?: MediaAttachment[];
}

export type ProviderResult =
  | {ok: true; data: ChatCompletion}
  | {ok: false; status: number; message: string};

export const readTokenUsage = (completion: ChatCompletion): TokenUsage => {
  const usage = completion.usage;
  const inputTokens = usage?.prompt_tokens ?? usage?.input_tokens ?? usage?.promptTokens ?? 0;
  const outputTokens = usage?.completion_tokens ?? usage?.output_tokens ?? usage?.completionTokens ?? 0;
  const suppliedTotal = usage?.total_tokens ?? usage?.totalTokens;
  const reported = Boolean(usage && (inputTokens || outputTokens || suppliedTotal !== undefined));
  return {
    inputTokens: Math.max(0, inputTokens),
    outputTokens: Math.max(0, outputTokens),
    totalTokens: Math.max(0, suppliedTotal ?? inputTokens + outputTokens),
    reported,
    requests: 1,
  };
};

export const addTokenUsage = (current: TokenUsage, next: TokenUsage): TokenUsage => ({
  inputTokens: current.inputTokens + next.inputTokens,
  outputTokens: current.outputTokens + next.outputTokens,
  totalTokens: current.totalTokens + next.totalTokens,
  reported: current.reported || next.reported,
  requests: current.requests + next.requests,
});

export interface ChatProxyOptions {
  /**
   * Allow endpoints on localhost / private networks. Off by default so a public
   * deployment cannot be used to probe its own internal network (SSRF).
   * Turn it on only when you host the model yourself.
   */
  allowPrivateEndpoints?: boolean;
}

/** Accepts ".../v1", ".../v1/" or a full ".../v1/chat/completions" URL. */
export function resolveChatEndpoint(baseUrl: string): string {
  const trimmed = baseUrl.trim();
  let url: URL;
  try {
    url = new URL(trimmed);
  } catch {
    throw new Error('That does not look like a URL. Example: https://api.openai.com/v1');
  }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') {
    throw new Error('The base URL must start with http:// or https://');
  }
  const path = url.pathname.replace(/\/+$/, '');
  if (path.endsWith('/chat/completions')) return `${url.origin}${path}`;
  return `${url.origin}${path}/chat/completions`;
}

const IPV4 = /^\d{1,3}(?:\.\d{1,3}){3}$/;
const IPV6 = /^[0-9a-f:.]+$/i;

const isIpLiteral = (hostname: string): boolean => IPV4.test(hostname) || (hostname.includes(':') && IPV6.test(hostname));

/** Loopback, link-local, private and reserved address ranges. */
export function isPrivateIp(address: string): boolean {
  const value = address.replace(/^\[|\]$/g, '').toLowerCase();
  if (IPV4.test(value)) {
    const [a, b] = value.split('.').map(Number);
    if ([a, b].some((part) => !Number.isInteger(part) || part < 0 || part > 255)) return true;
    return (
      a === 0 ||
      a === 10 ||
      a === 127 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 198 && (b === 18 || b === 19)) ||
      a >= 224
    );
  }
  if (!value.includes(':')) return false;
  if (value === '::' || value === '::1') return true;
  if (value.startsWith('::ffff:')) return isPrivateIp(value.slice(7));
  if (value.startsWith('fc') || value.startsWith('fd')) return true;
  if (value.startsWith('fe80') || value.startsWith('fe8') || value.startsWith('fe9') || value.startsWith('fea') || value.startsWith('feb')) return true;
  return false;
}

/** Localhost aliases, mDNS, cloud metadata names and private IP literals. */
export function isPrivateHostname(rawHostname: string): boolean {
  const hostname = rawHostname.replace(/^\[|\]$/g, '').toLowerCase().replace(/\.$/, '');
  if (!hostname) return true;
  if (
    hostname === 'localhost' ||
    hostname.endsWith('.localhost') ||
    hostname.endsWith('.local') ||
    hostname.endsWith('.internal') ||
    hostname === 'metadata' ||
    hostname === 'metadata.google.internal' ||
    hostname === 'instance-data'
  ) {
    return true;
  }
  return isIpLiteral(hostname) ? isPrivateIp(hostname) : false;
}

export type EndpointCheck =
  | {ok: true; endpoint: string; hostname: string}
  | {ok: false; message: string};

/** Normalises and screens a user-supplied base URL (literal hosts only). */
export function checkChatEndpoint(baseUrl: string, options: ChatProxyOptions = {}): EndpointCheck {
  let endpoint: string;
  try {
    endpoint = resolveChatEndpoint(baseUrl);
  } catch (error) {
    return {ok: false, message: error instanceof Error ? error.message : 'Invalid base URL.'};
  }
  const hostname = new URL(endpoint).hostname;
  if (!options.allowPrivateEndpoints && isPrivateHostname(hostname)) {
    return {
      ok: false,
      message: `The base URL points at a private or local address (${hostname}). Use a public endpoint, or set ALLOW_PRIVATE_ENDPOINTS=true if you host the model yourself.`,
    };
  }
  return {ok: true, endpoint, hostname};
}

export function parseJsonBody<T>(raw: string): {ok: true; value: T} | {ok: false; message: string} {
  try {
    return {ok: true, value: JSON.parse(raw) as T};
  } catch {
    return {ok: false, message: 'Request body must be JSON.'};
  }
}

/** One non-streaming chat completion against an OpenAI-compatible endpoint. */
export async function requestChatCompletion(
  endpoint: string,
  apiKey: string,
  payload: ChatRequestPayload,
  options: {timeoutMs?: number; signal?: AbortSignal} = {},
): Promise<ProviderResult> {
  const host = new URL(endpoint).host;
  const headers: Record<string, string> = {'content-type': 'application/json', accept: 'application/json'};
  if (apiKey) headers.authorization = `Bearer ${apiKey}`;

  const timeout = AbortSignal.timeout(options.timeoutMs ?? UPSTREAM_TIMEOUT_MS);
  const signal = options.signal ? AbortSignal.any([options.signal, timeout]) : timeout;

  const requestBody = JSON.stringify({
    model: payload.model,
    messages: payload.attachments?.length
      ? payload.messages.map((message, index) =>
          index === payload.messages.length - 1 && message.role === 'user'
            ? {
                ...message,
                content: [
                  {type: 'text' as const, text: typeof message.content === 'string' ? message.content : ''},
                  ...payload.attachments!.filter((attachment) => attachment.kind !== 'audio').flatMap((attachment) =>
                    attachment.frames.map((frame) => ({type: 'image_url' as const, image_url: {url: frame.dataUrl, detail: 'high' as const}})),
                  ),
                ],
              }
            : message,
        )
      : payload.messages,
    temperature: typeof payload.temperature === 'number' ? payload.temperature : 0.4,
    stream: false,
    ...(Array.isArray(payload.tools) && payload.tools.length ? {tools: payload.tools, tool_choice: payload.toolChoice ?? 'auto'} : {}),
  });

  let upstream: Response | null = null;
  let upstreamBody: string | undefined;
  for (let attempt = 0; attempt <= TRANSIENT_RETRY_DELAYS_MS.length; attempt += 1) {
    upstreamBody = undefined;
    try {
      upstream = await fetch(endpoint, {method: 'POST', headers, body: requestBody, signal});
    } catch (error) {
      if (options.signal?.aborted) throw error;
      if (timeout.aborted) {
        const reason = error instanceof Error ? error.message : 'request timed out';
        return {ok: false, status: 504, message: `The request to ${host} timed out. ${reason}.`};
      }
      // Do not retry timeouts: the provider may have completed the request and charged for it.
      if (!(error instanceof TypeError) || attempt >= TRANSIENT_RETRY_DELAYS_MS.length) {
        const reason = error instanceof Error ? error.message : 'network error';
        return {ok: false, status: 502, message: `Could not reach ${host}. ${reason}. Check the base URL, or whether the endpoint is up.`};
      }
      try {
        await waitForRetry(TRANSIENT_RETRY_DELAYS_MS[attempt], signal);
      } catch (retryError) {
        if (options.signal?.aborted) throw retryError;
        return {ok: false, status: 504, message: `The request to ${host} timed out while waiting to retry.`};
      }
      continue;
    }

    if (!isTransientStatus(upstream.status) || attempt >= TRANSIENT_RETRY_DELAYS_MS.length) break;
    const retryDelay = getRetryDelayMs(upstream, attempt + 1);
    if (upstream.status === 429) {
      upstreamBody = await upstream.text();
      let providerDetail = upstreamBody;
      try {
        const errorData = JSON.parse(upstreamBody) as {error?: {code?: string; type?: string; message?: string}};
        providerDetail = `${errorData.error?.code ?? ''} ${errorData.error?.type ?? ''} ${errorData.error?.message ?? upstreamBody}`;
      } catch {
        // Non-JSON provider error bodies are inspected as plain text.
      }
      if (/insufficient[_ -]?quota|quota|out of credits?|credit balance|billing|payment required|usage limit|monthly limit/i.test(providerDetail)) {
        break;
      }
    } else {
      await upstream.body?.cancel().catch(() => undefined);
    }
    try {
      await waitForRetry(retryDelay, signal);
    } catch (retryError) {
      if (options.signal?.aborted) throw retryError;
      return {ok: false, status: 504, message: `The request to ${host} timed out while waiting to retry.`};
    }
  }

  if (!upstream) return {ok: false, status: 502, message: `Could not reach ${host}. Check the base URL, or whether the endpoint is up.`};

  const raw = upstreamBody ?? await upstream.text();
  let parsed: ChatCompletion | null = null;
  try {
    parsed = raw ? (JSON.parse(raw) as ChatCompletion) : null;
  } catch {
    parsed = null;
  }

  if (!upstream.ok) {
    const message =
      parsed?.error?.message ??
      (parsed as {message?: string} | null)?.message ??
      raw.slice(0, 400) ??
      upstream.statusText;
    return {ok: false, status: upstream.status, message};
  }
  if (!parsed || typeof parsed !== 'object') {
    return {ok: false, status: 502, message: `${host} returned an empty or non-JSON response.`};
  }
  if (parsed.error) {
    return {
      ok: false,
      status: upstream.ok ? 502 : upstream.status,
      message: parsed.error.message || `${host} returned an error.`,
    };
  }
  return {ok: true, data: parsed};
}

export async function handleChatRequest(request: Request, options: ChatProxyOptions = {}): Promise<Response> {
  if (request.method === 'OPTIONS') {
    return new Response(null, {status: 204, headers: {allow: 'POST, OPTIONS'}});
  }
  if (request.method !== 'POST') {
    return failure('Use POST with a JSON body to reach your model.', 405);
  }

  const declaredLength = Number(request.headers.get('content-length') ?? '');
  if (Number.isFinite(declaredLength) && declaredLength > MAX_REQUEST_BYTES) {
    return failure('Request body too large.', 413);
  }

  let raw: string;
  try {
    raw = await request.text();
  } catch {
    return failure('Could not read the request body.');
  }
  if (raw.length > MAX_REQUEST_BYTES) return failure('Request body too large.', 413);

  const parsedBody = parseJsonBody<Record<string, unknown>>(raw);
  if (!parsedBody.ok) return failure(parsedBody.message);
  const body = parsedBody.value;

  const baseUrl = typeof body.baseUrl === 'string' ? body.baseUrl.trim() : '';
  const apiKey = typeof body.apiKey === 'string' ? body.apiKey.trim() : '';
  const model = typeof body.model === 'string' ? body.model.trim() : '';
  const messages = body.messages;
  let attachments: MediaAttachment[] | undefined;
  if (body.attachments !== undefined) {
    try {
      attachments = normalizeAttachments(body.attachments);
    } catch (error) {
      return failure(error instanceof Error ? error.message : 'Invalid media previews.');
    }
  }

  if (!baseUrl) return failure('Missing baseUrl. Add your API base URL in Settings.');
  if (!model) return failure('Missing model. Add your model id in Settings.');
  if (!Array.isArray(messages) || messages.length === 0) return failure('messages must be a non-empty array.');
  if (messages.length > MAX_MESSAGES) return failure(`Too many messages (limit ${MAX_MESSAGES}).`);

  const check = checkChatEndpoint(baseUrl, options);
  if (!check.ok) return failure(check.message, 400);

  const result = await requestChatCompletion(check.endpoint, apiKey, {
    model,
    messages: messages as ChatMessage[],
    tools: Array.isArray(body.tools) ? body.tools : undefined,
    toolChoice: body.toolChoice,
    temperature: typeof body.temperature === 'number' ? body.temperature : undefined,
    attachments,
  });

  if (!result.ok) {
    return reply(
      {error: {message: result.message, ...(result.status !== 502 ? {providerStatus: result.status} : {})}},
      result.status,
    );
  }
  return reply(result.data);
}
