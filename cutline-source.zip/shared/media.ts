import type {MediaAttachment} from '../src/types.ts';
export type {MediaAttachment} from '../src/types.ts';

export interface AttachmentFrame {
  /** Seconds into the source video; 0 for a still image. */
  timeSeconds: number;
  /** Compressed, browser-generated image data URL. Original video bytes never leave the browser. */
  dataUrl: string;
}

export interface TokenUsage {
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
  /** True only if the provider returned token usage. */
  reported: boolean;
  requests: number;
}

export const emptyTokenUsage = (): TokenUsage => ({
  inputTokens: 0,
  outputTokens: 0,
  totalTokens: 0,
  reported: false,
  requests: 0,
});

export const MAX_MEDIA_ATTACHMENTS = 6;
export const MAX_FRAMES_PER_ATTACHMENT = 4;
export const MAX_ATTACHMENT_BYTES = 7_500_000;
export const MAX_FRAME_DATA_URL_LENGTH = 320_000;
const MAX_AUDIO_ATTACHMENT_BYTES = 200 * 1024 * 1024;

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

/** Validate compact visual context. Raw video bytes are never accepted here. */
export function normalizeAttachments(value: unknown): MediaAttachment[] {
  if (!Array.isArray(value) || !value.length) return [];
  if (value.length > MAX_MEDIA_ATTACHMENTS) throw new Error(`Attach up to ${MAX_MEDIA_ATTACHMENTS} files per edit.`);

  let totalBytes = 0;
  const result: MediaAttachment[] = [];

  for (const item of value) {
    if (!isRecord(item)) throw new Error('An attachment was not valid. Remove it and try again.');
    const {id, name, kind, mimeType, frames} = item;
    if (typeof id !== 'string' || !/^[a-zA-Z0-9_-]{1,80}$/.test(id)) {
      throw new Error('An attachment id was not valid. Remove it and try again.');
    }
    if (kind !== 'image' && kind !== 'video' && kind !== 'audio') throw new Error('Only images, videos, and audio can be attached.');
    if (typeof name !== 'string' || !name.trim() || name.length > 180) {
      throw new Error('An attachment filename was not valid.');
    }
    if (typeof mimeType !== 'string' || mimeType.length > 100) throw new Error('An attachment type was not valid.');
    if (!Array.isArray(frames) || !frames.length || frames.length > MAX_FRAMES_PER_ATTACHMENT) {
      throw new Error(`Each attachment must have 1–${MAX_FRAMES_PER_ATTACHMENT} preview frames.`);
    }
    if ((kind === 'image' || kind === 'audio') && frames.length !== 1) throw new Error('An image or audio attachment must have exactly one preview frame.');
    if (kind === 'audio' && (typeof item.durationSeconds !== 'number' || !Number.isFinite(item.durationSeconds) || item.durationSeconds <= 0 || item.durationSeconds > 120)) throw new Error('Audio must have a valid duration no longer than two minutes.');
    if (kind === 'video' && typeof item.durationSeconds === 'number' && (!Number.isFinite(item.durationSeconds) || item.durationSeconds < 0 || item.durationSeconds > 86_400)) {
      throw new Error('A video duration was not valid.');
    }

    const cleanFrames = frames.map((frame) => {
      if (!isRecord(frame) || typeof frame.dataUrl !== 'string' || frame.dataUrl.length > MAX_FRAME_DATA_URL_LENGTH) {
        throw new Error('An attachment frame was too large. Try a smaller image or shorter video.');
      }
      if (!/^data:image\/(?:jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(frame.dataUrl)) {
        throw new Error('Attachment previews must be compressed images.');
      }
      const timeSeconds = typeof frame.timeSeconds === 'number' ? frame.timeSeconds : 0;
      if (!Number.isFinite(timeSeconds) || timeSeconds < 0 || timeSeconds > 86_400) {
        throw new Error('An attachment frame time was not valid.');
      }
      totalBytes += frame.dataUrl.length;
      return {timeSeconds, dataUrl: frame.dataUrl};
    });

    if (kind === 'audio' && (typeof item.audioBytes !== 'number' || !Number.isSafeInteger(item.audioBytes) || item.audioBytes < 1 || item.audioBytes > MAX_AUDIO_ATTACHMENT_BYTES)) throw new Error('Audio attachments must be under 200 MB.');
    result.push({
      id,
      name: name.trim(),
      kind,
      mimeType,
      ...(typeof item.durationSeconds === 'number' ? {durationSeconds: item.durationSeconds} : {}),
      frames: cleanFrames,
      ...(kind === 'audio' && typeof item.audioBytes === 'number' ? {audioBytes: item.audioBytes} : {}),
    } as MediaAttachment);
  }

  if (totalBytes > MAX_ATTACHMENT_BYTES) {
    throw new Error('Attachments are too large to send together. Remove a file or try smaller images.');
  }
  return result;
}
