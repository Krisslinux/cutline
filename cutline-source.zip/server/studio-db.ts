import {DatabaseSync} from 'node:sqlite';
import {mkdir} from 'node:fs/promises';
import path from 'node:path';
import pg from 'pg';

export interface Db {
  query<T extends Record<string, unknown> = Record<string, unknown>>(sql: string, values?: unknown[]): Promise<T[]>;
  close(): Promise<void>;
}
export async function openDb(url = process.env.DATABASE_URL ?? ''): Promise<Db> {
  if (url.startsWith('postgres')) {
    const pool = new pg.Pool({connectionString: url, max: 8});
    return {async query<T extends Record<string, unknown>>(sql: string, values: unknown[] = []) {return (await pool.query(sql, values)).rows as T[];}, async close() {await pool.end();}};
  }
  if (process.env.NODE_ENV === 'production') throw new Error('Production requires DATABASE_URL pointing to Postgres.');
  const file = url === ':memory:' ? url : url.replace(/^sqlite:/, '') || path.resolve('.cutline/development.sqlite');
  if (file !== ':memory:') await mkdir(path.dirname(file), {recursive: true, mode: 0o700});
  const sqlite = new DatabaseSync(file);
  sqlite.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; PRAGMA foreign_keys=ON;');
  return {async query<T extends Record<string, unknown>>(sql: string, values: unknown[] = []) {
    const ordered: unknown[] = [];
    const source = sql.replace(/\$(\d+)/g, (_, n: string) => {ordered.push(values[Number(n) - 1]); return '?';});
    return sqlite.prepare(source).all(...ordered as (string | number | null)[]) as T[];
  }, async close() {sqlite.close();}};
}
const migrations = [
  `CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at BIGINT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS owners (id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES owners(id), expires_at BIGINT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS projects (id TEXT PRIMARY KEY, owner_id TEXT NOT NULL REFERENCES owners(id), title TEXT NOT NULL, revision INTEGER NOT NULL DEFAULT 0, timeline TEXT, hints TEXT NOT NULL DEFAULT '', language TEXT NOT NULL DEFAULT 'en', updated_at BIGINT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS assets (id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id), owner_id TEXT NOT NULL REFERENCES owners(id), kind TEXT NOT NULL, name TEXT NOT NULL, mime TEXT NOT NULL, bytes BIGINT NOT NULL, duration_ms REAL, file_key TEXT NOT NULL, created_at BIGINT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS providers (owner_id TEXT PRIMARY KEY REFERENCES owners(id), settings TEXT NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS jobs (id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id), owner_id TEXT NOT NULL REFERENCES owners(id), kind TEXT NOT NULL, state TEXT NOT NULL, stage TEXT NOT NULL, progress REAL, payload TEXT NOT NULL, revision INTEGER NOT NULL, attempt INTEGER NOT NULL DEFAULT 0, lease_owner TEXT, lease_until BIGINT NOT NULL DEFAULT 0, cancel_requested INTEGER NOT NULL DEFAULT 0, error TEXT, output_key TEXT, created_at BIGINT NOT NULL, updated_at BIGINT NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS jobs_claim ON jobs(state, lease_until, created_at)`,
  `CREATE INDEX IF NOT EXISTS jobs_project ON jobs(project_id, created_at)`,
  `CREATE UNIQUE INDEX IF NOT EXISTS jobs_one_active_project ON jobs(project_id) WHERE state NOT IN ('ready','completed','failed','cancelled')`,
  `CREATE UNIQUE INDEX IF NOT EXISTS assets_one_narration ON assets(project_id) WHERE kind='audio'`,
  `CREATE TABLE IF NOT EXISTS workers (id TEXT PRIMARY KEY, heartbeat BIGINT NOT NULL)`,
];
export async function migrate(db: Db): Promise<void> {
  for (const sql of migrations) await db.query(sql);
  await db.query('INSERT INTO schema_migrations(version, applied_at) VALUES(1,$1) ON CONFLICT(version) DO NOTHING', [Date.now()]);
}
