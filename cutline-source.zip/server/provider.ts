import {checkChatEndpoint, requestChatCompletion} from '../shared/chat.ts';
import type {AgentChatFn} from './agent.ts';

export class ProviderRequestError extends Error {
  constructor(readonly status: number, message: string) {
    super(message);
    this.name = 'ProviderRequestError';
  }
}

/** Turn upstream failures into actionable messages without exposing API tokens. */
export function formatProviderFailure(error: unknown, apiKey: string): string {
  const raw = error instanceof Error ? error.message : 'The provider request failed.';
  const detail = (apiKey ? raw.split(apiKey).join('[redacted]') : raw).slice(0, 500);
  if (!(error instanceof ProviderRequestError)) return `${detail || 'The edit failed.'} Your current timeline is preserved.`;

  const status = error.status;
  const guidance = status === 401 || status === 403
    ? 'The provider rejected your API token. Check or replace it in Settings, and confirm the token belongs to this endpoint.'
    : status === 402
      ? 'The provider account may have run out of credits or needs billing attention. Add credits or choose another provider in Settings.'
      : status === 429
        ? 'The provider rate limit or usage limit was reached. Wait and try again, check your provider quota, or use another provider.'
        : status === 404
          ? 'The provider endpoint or model was not found. Check the base URL and model id in Settings.'
          : status === 502 || status === 503 || status === 504
            ? 'The provider is temporarily unavailable. Wait a moment and submit the request again.'
            : `The provider request failed (${status}). Check your model settings and provider status.`;
  return `${guidance}${detail ? ` Details: ${detail}` : ''} Your current timeline is preserved.`;
}

/** Calls the visitor's endpoint directly from the worker (no browser involved). */
export function createProviderChat(allowPrivateEndpoints: boolean): AgentChatFn {
  return async (settings, body, signal) => {
    const check = checkChatEndpoint(settings.baseUrl, {allowPrivateEndpoints});
    if (!check.ok) throw new Error(check.message);
    const result = await requestChatCompletion(
      check.endpoint,
      settings.apiKey,
      {
        model: settings.model,
        messages: body.messages,
        tools: body.tools,
        temperature: body.temperature,
        attachments: body.attachments,
      },
      {signal},
    );
    if (!result.ok) throw new ProviderRequestError(result.status, result.message);
    return result.data;
  };
}
