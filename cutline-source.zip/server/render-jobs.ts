import {randomUUID} from 'node:crypto';
import {createWriteStream} from 'node:fs';
import {mkdtemp, mkdir, rename, rm, stat, unlink} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {Transform, type Readable} from 'node:stream';
import {pipeline} from 'node:stream/promises';
import {normalizeSpec, totalFrames} from '../src/lib/spec.ts';
import type {MediaAttachment, VideoSpec} from '../src/types.ts';

export type RenderStatus = 'uploading' | 'queued' | 'rendering' | 'done' | 'error' | 'cancelled';

export interface RenderSnapshot {
  id: string;
  status: RenderStatus;
  createdAt: number;
  updatedAt: number;
  progress: number;
  stage: string;
  uploadedBytes: number;
  totalBytes: number;
  error?: string;
}

interface RenderMediaInput {
  id: string;
  name: string;
  kind: 'image' | 'video' | 'audio';
  mimeType: string;
  durationSeconds?: number;
  frameTimes: number[];
}

interface RenderInput {
  spec: unknown;
  attachments: unknown;
  ip: string;
}

interface PreparedMedia extends RenderMediaInput {
  extension: string;
  size: number;
  filePath: string;
}

export interface RenderExecutionInput {
  spec: VideoSpec;
  attachments: MediaAttachment[];
  entryPoint: string;
  rootDir: string;
  publicDir: string;
  bundleDir: string;
  outputPath: string;
  signal: AbortSignal;
  onProgress: (progress: number, stage: string) => void;
}

export type RenderExecutor = (input: RenderExecutionInput) => Promise<void>;

interface RenderRecord {
  snapshot: RenderSnapshot;
  spec: VideoSpec;
  media: PreparedMedia[];
  ip: string;
  reserved: boolean;
  directory: string;
  controller: AbortController;
  subscribers: Set<(snapshot: RenderSnapshot) => void>;
  uploaded: Set<string>;
  completedAt?: number;
}

const MAX_MEDIA_FILES = 6;
const MAX_FILE_BYTES = 200 * 1024 * 1024;
const MAX_TOTAL_MEDIA_BYTES = 500 * 1024 * 1024;
const MAX_DURATION_SECONDS = 120;
const MAX_DIMENSION = 1920;
const DEFAULT_TTL_MS = 45 * 60_000;
const ACCEPTED_MIME: Record<string, {kind: 'image' | 'video' | 'audio'; extension: string}> = {
  'image/jpeg': {kind: 'image', extension: 'jpg'},
  'image/png': {kind: 'image', extension: 'png'},
  'image/webp': {kind: 'image', extension: 'webp'},
  'image/avif': {kind: 'image', extension: 'avif'},
  'image/jpg': {kind: 'image', extension: 'jpg'},
  'video/mp4': {kind: 'video', extension: 'mp4'},
  'video/webm': {kind: 'video', extension: 'webm'},
  'video/quicktime': {kind: 'video', extension: 'mov'},
  'audio/mpeg': {kind: 'audio', extension: 'mp3'},
  'audio/wav': {kind: 'audio', extension: 'wav'},
  'audio/mp4': {kind: 'audio', extension: 'm4a'},
  'audio/aac': {kind: 'audio', extension: 'aac'},
  'audio/ogg': {kind: 'audio', extension: 'ogg'},
  'audio/opus': {kind: 'audio', extension: 'opus'},
  'audio/flac': {kind: 'audio', extension: 'flac'},
  'audio/x-wav': {kind: 'audio', extension: 'wav'},
  'audio/x-m4a': {kind: 'audio', extension: 'm4a'},
};

const terminal = (status: RenderStatus): boolean => status === 'done' || status === 'error' || status === 'cancelled';
const clone = (snapshot: RenderSnapshot): RenderSnapshot => ({...snapshot});

const defaultExecutor: RenderExecutor = async (input) => {
  const [{bundle}, {ensureBrowser, renderMedia, selectComposition}] = await Promise.all([
    import('@remotion/bundler'),
    import('@remotion/renderer'),
  ]);
  await ensureBrowser({logLevel: 'error'});
  if (input.signal.aborted) throw new Error('Render cancelled.');

  const serveUrl = await bundle({
    entryPoint: input.entryPoint,
    rootDir: input.rootDir,
    publicDir: input.publicDir,
    outDir: input.bundleDir,
  });
  if (input.signal.aborted) throw new Error('Render cancelled.');
  const inputProps = {spec: input.spec, attachments: input.attachments};
  const composition = await selectComposition({serveUrl, id: 'CutlineVideo', inputProps});
  await renderMedia({
    serveUrl,
    composition,
    inputProps,
    codec: 'h264',
    outputLocation: input.outputPath,
    concurrency: 1,
    crf: 23,
    cancelSignal: (callback) => input.signal.addEventListener('abort', callback, {once: true}),
    onProgress: ({progress, stitchStage}) => {
      input.onProgress(progress, stitchStage === 'muxing' ? 'Finishing MP4…' : 'Rendering frames…');
    },
  });
};

export interface RenderJobStoreOptions {
  projectRoot: string;
  maxConcurrent?: number;
  maxPerIp?: number;
  maxQueued?: number;
  ttlMs?: number;
  executor?: RenderExecutor;
}

export type CreateRenderResult =
  | {ok: true; job: RenderSnapshot}
  | {ok: false; reason: 'rate-limited' | 'queue-full'; message: string};

export class RenderJobStore {
  private readonly jobs = new Map<string, RenderRecord>();
  private readonly queue: string[] = [];
  private readonly projectRoot: string;
  private readonly maxConcurrent: number;
  private readonly maxPerIp: number;
  private readonly maxQueued: number;
  private readonly ttlMs: number;
  private readonly executor: RenderExecutor;
  private running = 0;
  private readonly sweeper: NodeJS.Timeout;
  private readonly reservedPerIp = new Map<string, number>();

  constructor(options: RenderJobStoreOptions) {
    this.projectRoot = path.resolve(options.projectRoot);
    this.maxConcurrent = options.maxConcurrent ?? 1;
    this.maxPerIp = options.maxPerIp ?? 1;
    this.maxQueued = options.maxQueued ?? 3;
    this.ttlMs = options.ttlMs ?? DEFAULT_TTL_MS;
    this.executor = options.executor ?? defaultExecutor;
    this.sweeper = setInterval(() => void this.sweep(), 60_000);
    this.sweeper.unref?.();
  }

  async create(input: RenderInput): Promise<CreateRenderResult> {
    this.evictOldest();
    const activeForIp = [...this.jobs.values()].filter(
      (job) => job.ip === input.ip && !terminal(job.snapshot.status) && job.snapshot.status !== 'uploading',
    ).length;
    if (activeForIp + (this.reservedPerIp.get(input.ip) ?? 0) >= this.maxPerIp) {
      return {ok: false, reason: 'rate-limited', message: 'You already have a render in progress. Wait for it to finish.'};
    }
    const activeCount = [...this.jobs.values()].filter((job) => !terminal(job.snapshot.status)).length;
    if (this.queue.length >= this.maxQueued || activeCount >= this.maxConcurrent + this.maxQueued) {
      return {ok: false, reason: 'queue-full', message: 'The video render queue is full. Try again in a moment.'};
    }

    const spec = normalizeSpec(input.spec);
    if (spec.meta.width > MAX_DIMENSION || spec.meta.height > MAX_DIMENSION) {
      throw new Error(`Server rendering supports up to ${MAX_DIMENSION}px per side. Reduce the video size and try again.`);
    }
    if (totalFrames(spec) / spec.meta.fps > MAX_DURATION_SECONDS) {
      throw new Error(`Server renders are limited to ${MAX_DURATION_SECONDS} seconds per video.`);
    }

    const referencedIds = new Set(spec.scenes.flatMap((scene) => [scene.mediaAttachmentId, scene.audioAttachmentId]).filter((id): id is string => Boolean(id)));
    if (!Array.isArray(input.attachments)) throw new Error('Render media list is invalid.');
    if (input.attachments.length > MAX_MEDIA_FILES) throw new Error(`Upload no more than ${MAX_MEDIA_FILES} media files for one render.`);
    if (referencedIds.size > 0 && input.attachments.length === 0) throw new Error('Attach every image, video, and audio file used in the cut before rendering.');
    const media: PreparedMedia[] = [];
    let totalBytes = 0;
    let audioCount = 0;
    for (const raw of input.attachments) {
      if (!raw || typeof raw !== 'object') throw new Error('A render media item is invalid.');
      const item = raw as Record<string, unknown>;
      const id = typeof item.id === 'string' ? item.id : '';
      const name = typeof item.name === 'string' ? item.name : '';
      const kind = item.kind;
      const mimeType = typeof item.mimeType === 'string' ? item.mimeType.toLowerCase() : '';
      const size = item.size;
      const frameTimes = item.frameTimes;
      const supported = ACCEPTED_MIME[mimeType];
      const declaredAudioBytes = item.audioBytes;
      if (!/^[a-zA-Z0-9_-]{1,80}$/.test(id) || !referencedIds.has(id)) throw new Error('A render media id is invalid or unused.');
      if (media.some((entry) => entry.id === id)) throw new Error('A render media id was supplied more than once.');
      if (!name.trim() || name.length > 180) throw new Error('A render media filename is invalid.');
      if (!supported || supported.kind !== kind) throw new Error(`The ${name} file type is not supported for server rendering.`);
      if (kind === 'audio' && ++audioCount > 1) throw new Error('Use one soundtrack or narration file per video.');
      if (kind === 'audio' && (typeof declaredAudioBytes !== 'number' || declaredAudioBytes !== size)) throw new Error(`${name} is missing a valid audio file size.`);
      if (typeof size !== 'number' || !Number.isSafeInteger(size) || size < 1 || size > MAX_FILE_BYTES) {
        throw new Error(`${name} must be under ${Math.round(MAX_FILE_BYTES / 1024 / 1024)} MB to render on the server.`);
      }
      if (!Array.isArray(frameTimes) || frameTimes.length > 4 || frameTimes.some((time) => typeof time !== 'number' || !Number.isFinite(time) || time < 0 || time > 86_400)) {
        throw new Error(`${name} has invalid preview frame metadata.`);
      }
      if ((kind === 'video' || kind === 'audio') && (typeof item.durationSeconds !== 'number' || !Number.isFinite(item.durationSeconds) || item.durationSeconds <= 0 || item.durationSeconds > MAX_DURATION_SECONDS)) {
        throw new Error(`${name} does not have a valid media duration under two minutes.`);
      }
      totalBytes += size;
      if (totalBytes > MAX_TOTAL_MEDIA_BYTES) throw new Error('The media for this render exceeds the 500 MB upload limit.');
      media.push({
        id,
        name: name.trim(),
        kind: supported.kind,
        mimeType,
        ...(typeof item.durationSeconds === 'number' ? {durationSeconds: item.durationSeconds} : {}),
        frameTimes: frameTimes as number[],
        extension: supported.extension,
        size,
        filePath: '',
      });
    }
    if ([...referencedIds].some((id) => !media.some((item) => item.id === id))) {
      throw new Error('Attach every image, video, and audio file used in the cut before rendering.');
    }

    const reservation: Pick<RenderRecord, 'ip' | 'reserved'> = {ip: input.ip, reserved: true};
    this.reservedPerIp.set(input.ip, (this.reservedPerIp.get(input.ip) ?? 0) + 1);
    let directory: string;
    try {
      directory = await mkdtemp(path.join(os.tmpdir(), 'cutline-render-'));
    } catch (error) {
      this.releaseIpReservation(reservation);
      throw error;
    }
    const publicDir = path.join(directory, 'public');
    try {
      await mkdir(path.join(publicDir, 'media'), {recursive: true});
    } catch (error) {
      await rm(directory, {recursive: true, force: true});
      this.releaseIpReservation(reservation);
      throw error;
    }
    for (const item of media) item.filePath = path.join(publicDir, 'media', `${item.id}.${item.extension}`);

    const now = Date.now();
    const id = randomUUID();
    const snapshot: RenderSnapshot = {
      id,
      status: 'uploading',
      createdAt: now,
      updatedAt: now,
      progress: 0,
      stage: media.length ? 'Waiting for media upload…' : 'Ready to queue…',
      uploadedBytes: 0,
      totalBytes,
    };
    const record: RenderRecord = {
      snapshot,
      spec,
      media,
      ip: input.ip,
      reserved: true,
      directory,
      controller: new AbortController(),
      subscribers: new Set(),
      uploaded: new Set(),
    };
    this.jobs.set(id, record);
    if (media.length === 0) snapshot.stage = 'Ready to queue…';
    return {ok: true, job: clone(snapshot)};
  }

  get(id: string): RenderSnapshot | undefined {
    const record = this.jobs.get(id);
    return record ? clone(record.snapshot) : undefined;
  }

  getOutputPath(id: string): string | undefined {
    const record = this.jobs.get(id);
    return record?.snapshot.status === 'done' ? path.join(record.directory, 'video.mp4') : undefined;
  }

  subscribe(id: string, callback: (snapshot: RenderSnapshot) => void): (() => void) | null {
    const record = this.jobs.get(id);
    if (!record) return null;
    record.subscribers.add(callback);
    callback(clone(record.snapshot));
    return () => record.subscribers.delete(callback);
  }

  async uploadMedia(id: string, mediaId: string, input: Readable, contentLength: number | undefined): Promise<void> {
    const record = this.jobs.get(id);
    if (!record || record.snapshot.status !== 'uploading') throw new Error('This render is no longer accepting uploads.');
    const media = record.media.find((item) => item.id === mediaId);
    if (!media) throw new Error('This media id is not part of the render.');
    if (record.uploaded.has(mediaId)) throw new Error('This media file has already been uploaded.');
    if (contentLength !== undefined && contentLength !== media.size) throw new Error('Uploaded file size did not match its declared size.');

    let received = 0;
    let lastEmit = 0;
    const progress = new Transform({
      transform: (chunk: Buffer, _encoding, callback) => {
        received += chunk.length;
        if (received > media.size || received > MAX_FILE_BYTES) {
          callback(new Error('Uploaded media exceeded its declared size.'));
          return;
        }
        if (received - lastEmit >= 1024 * 1024 || received === media.size) {
          lastEmit = received;
          record.snapshot.uploadedBytes = record.media.reduce((sum, item) => sum + (record.uploaded.has(item.id) ? item.size : item.id === mediaId ? received : 0), 0);
          record.snapshot.stage = `Uploading media · ${record.uploaded.size + 1}/${record.media.length}`;
          this.emit(record);
        }
        callback(null, chunk);
      },
    });

    try {
      const temporaryPath = `${media.filePath}.uploading`;
      await pipeline(input, progress, createWriteStream(temporaryPath, {flags: 'wx'}));
      if (received !== media.size) throw new Error('Uploaded media was incomplete.');
      await rename(temporaryPath, media.filePath);
      record.uploaded.add(mediaId);
      record.snapshot.uploadedBytes = record.media.reduce((sum, item) => sum + (record.uploaded.has(item.id) ? item.size : 0), 0);
      record.snapshot.stage = record.uploaded.size === record.media.length ? 'Ready to render…' : `Uploaded ${record.uploaded.size}/${record.media.length} files`;
      this.emit(record);
    } catch (error) {
      await unlink(`${media.filePath}.uploading`).catch(() => undefined);
      await unlink(media.filePath).catch(() => undefined);
      throw error;
    }
  }

  start(id: string): boolean {
    const record = this.jobs.get(id);
    if (!record || record.snapshot.status !== 'uploading') return false;
    if (record.uploaded.size !== record.media.length) throw new Error('Upload all selected media before starting the render.');
    if (this.queue.length >= this.maxQueued) return false;
    this.releaseIpReservation(record);
    record.snapshot.status = 'queued';
    record.snapshot.stage = `Queued · ${this.queue.length} ahead`;
    this.queue.push(id);
    this.emit(record);
    this.pump();
    return true;
  }

  cancel(id: string): boolean {
    const record = this.jobs.get(id);
    if (!record) return false;
    if (terminal(record.snapshot.status)) return true;
    if (record.snapshot.status === 'queued' || record.snapshot.status === 'uploading') {
      const index = this.queue.indexOf(id);
      if (index >= 0) this.queue.splice(index, 1);
      this.releaseIpReservation(record);
      record.snapshot.status = 'cancelled';
      record.snapshot.stage = 'Render cancelled';
      record.completedAt = Date.now();
      this.emit(record);
      return true;
    }
    record.controller.abort();
    return true;
  }

  private releaseIpReservation(record: Pick<RenderRecord, 'ip' | 'reserved'>): void {
    if (!record.reserved) return;
    record.reserved = false;
    const ip = record.ip;
    const count = this.reservedPerIp.get(ip) ?? 0;
    if (count <= 1) this.reservedPerIp.delete(ip);
    else this.reservedPerIp.set(ip, count - 1);
  }

  private emit(record: RenderRecord): void {
    record.snapshot.updatedAt = Date.now();
    const snapshot = clone(record.snapshot);
    for (const subscriber of record.subscribers) {
      try {
        subscriber(snapshot);
      } catch {
        record.subscribers.delete(subscriber);
      }
    }
    if (terminal(record.snapshot.status)) record.subscribers.clear();
  }

  private pump(): void {
    while (this.running < this.maxConcurrent && this.queue.length) {
      const id = this.queue.shift();
      if (id) void this.execute(id);
    }
  }

  private async execute(id: string): Promise<void> {
    const record = this.jobs.get(id);
    if (!record || record.snapshot.status !== 'queued') return;
    this.running += 1;
    record.snapshot.status = 'rendering';
    record.snapshot.stage = 'Preparing renderer…';
    this.emit(record);

    const attachments: MediaAttachment[] = record.media.map((item) => {
      const source = path.relative(path.join(record.directory, 'public'), item.filePath).split(path.sep).join('/');
      const frames = item.frameTimes.map((timeSeconds) => ({timeSeconds, dataUrl: ''}));
      return {
        id: item.id,
        name: item.name,
        kind: item.kind,
        mimeType: item.mimeType,
        ...(item.durationSeconds === undefined ? {} : {durationSeconds: item.durationSeconds}),
        frames,
        ...(item.kind === 'audio' ? {audioSrc: source} : {renderSrc: source}),
      };
    });
    const outputPath = path.join(record.directory, 'video.mp4');

    try {
      await this.executor({
        spec: record.spec,
        attachments,
        entryPoint: path.join(this.projectRoot, 'src', 'render', 'entry.tsx'),
        rootDir: this.projectRoot,
        publicDir: path.join(record.directory, 'public'),
        bundleDir: path.join(record.directory, 'bundle'),
        outputPath,
        signal: record.controller.signal,
        onProgress: (progress, stage) => {
          if (record.snapshot.status !== 'rendering') return;
          record.snapshot.progress = Math.max(0, Math.min(1, progress));
          record.snapshot.stage = stage;
          this.emit(record);
        },
      });
      if (record.controller.signal.aborted) throw new Error('Render cancelled.');
      const output = await stat(outputPath);
      if (!output.isFile() || output.size === 0) throw new Error('The renderer did not produce an MP4 file.');
      record.snapshot.status = 'done';
      record.snapshot.progress = 1;
      record.snapshot.stage = 'MP4 ready to download';
    } catch (error) {
      record.snapshot.status = record.controller.signal.aborted ? 'cancelled' : 'error';
      record.snapshot.stage = record.controller.signal.aborted ? 'Render cancelled' : 'Render failed';
      record.snapshot.error = error instanceof Error ? error.message.slice(0, 800) : 'The video render failed.';
      await unlink(outputPath).catch(() => undefined);
    } finally {
      this.releaseIpReservation(record);
      record.completedAt = Date.now();
      this.running = Math.max(0, this.running - 1);
      this.emit(record);
      this.pump();
    }
  }

  private evictOldest(): void {
    if (this.jobs.size < 100) return;
    const finished = [...this.jobs.values()]
      .filter((job) => terminal(job.snapshot.status))
      .sort((a, b) => (a.completedAt ?? a.snapshot.createdAt) - (b.completedAt ?? b.snapshot.createdAt));
    for (const record of finished) {
      if (this.jobs.size < 100) break;
      this.jobs.delete(record.snapshot.id);
      void rm(record.directory, {recursive: true, force: true});
    }
  }

  private async sweep(): Promise<void> {
    const now = Date.now();
    for (const [id, record] of this.jobs) {
      const finished = record.completedAt ?? record.snapshot.createdAt;
      if (terminal(record.snapshot.status) && now - finished > this.ttlMs) {
        this.jobs.delete(id);
        await rm(record.directory, {recursive: true, force: true});
      } else if (!terminal(record.snapshot.status) && now - record.snapshot.createdAt > this.ttlMs) {
        this.cancel(id);
      }
    }
  }

  dispose(): void {
    clearInterval(this.sweeper);
    for (const record of this.jobs.values()) {
      if (!terminal(record.snapshot.status)) record.controller.abort();
      void rm(record.directory, {recursive: true, force: true});
    }
    this.jobs.clear();
    this.queue.length = 0;
    this.reservedPerIp.clear();
  }
}
