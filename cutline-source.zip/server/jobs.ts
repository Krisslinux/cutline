import {randomUUID} from 'node:crypto';
import {runAgent, type AgentChatFn} from './agent.ts';
import {formatProviderFailure} from './provider.ts';
import {normalizeSpec} from '../src/lib/spec.ts';
import type {VideoSpec} from '../src/types.ts';
import {emptyTokenUsage, normalizeAttachments, type MediaAttachment, type TokenUsage} from '../shared/media.ts';

export type JobStatus = 'queued' | 'running' | 'done' | 'error' | 'cancelled';

export interface JobStep {
  id: string;
  name: string;
  label: string;
  ok: boolean;
  at: number;
}

/** Everything the browser may see. Credentials are never part of this. */
export interface JobAttachmentSummary {
  id: string;
  name: string;
  kind: 'image' | 'video' | 'audio';
  mimeType: string;
  durationSeconds?: number;
  frameTimes: number[];
}

export interface JobSnapshot {
  id: string;
  status: JobStatus;
  createdAt: number;
  updatedAt: number;
  rounds: number;
  steps: JobStep[];
  spec: VideoSpec;
  reply: string;
  error?: string;
  changed: boolean;
  queuedAhead: number;
  attachments: JobAttachmentSummary[];
  usage: TokenUsage;
}

export interface JobInput {
  baseUrl: string;
  apiKey: string;
  model: string;
  spec: unknown;
  prompt: string;
  history: {role: 'user' | 'assistant'; text: string}[];
  attachments?: unknown;
  ip: string;
}

export interface JobStoreOptions {
  chat: AgentChatFn;
  maxConcurrent?: number;
  maxPerIp?: number;
  maxQueued?: number;
  /** Upper bound on jobs kept in memory (finished ones are evicted first). */
  maxJobs?: number;
  /** How long a finished job stays readable/reconnectable. */
  ttlMs?: number;
  /** Hard cap for a single edit. */
  jobTimeoutMs?: number;
}

interface JobRecord {
  snapshot: JobSnapshot;
  attachments: MediaAttachment[];
  credentials: {baseUrl: string; apiKey: string; model: string};
  prompt: string;
  history: {role: 'user' | 'assistant'; text: string}[];
  ip: string;
  controller: AbortController;
  timeout?: NodeJS.Timeout;
  subscribers: Set<(snapshot: JobSnapshot) => void>;
  completedAt?: number;
  timedOut?: boolean;
}

export type CreateJobResult =
  | {ok: true; job: JobSnapshot}
  | {ok: false; reason: 'rate-limited' | 'queue-full'; message: string};

const cloneSnapshot = (snapshot: JobSnapshot): JobSnapshot => structuredClone(snapshot);

const isTerminal = (status: JobStatus): boolean => status === 'done' || status === 'error' || status === 'cancelled';

export const isJobTerminal = isTerminal;

export class JobStore {
  private readonly jobs = new Map<string, JobRecord>();
  private readonly queue: string[] = [];
  private readonly chat: AgentChatFn;
  private readonly maxConcurrent: number;
  private readonly maxPerIp: number;
  private readonly maxQueued: number;
  private readonly maxJobs: number;
  private readonly ttlMs: number;
  private readonly jobTimeoutMs: number;
  private running = 0;
  private sweeper: NodeJS.Timeout;

  constructor(options: JobStoreOptions) {
    this.chat = options.chat;
    this.maxConcurrent = options.maxConcurrent ?? 6;
    this.maxPerIp = options.maxPerIp ?? 2;
    this.maxQueued = options.maxQueued ?? 40;
    this.maxJobs = options.maxJobs ?? 500;
    this.ttlMs = options.ttlMs ?? 30 * 60_000;
    this.jobTimeoutMs = options.jobTimeoutMs ?? 8 * 60_000;

    this.sweeper = setInterval(() => this.sweep(), 60_000);
    this.sweeper.unref?.();
  }

  /** Anonymous jobs: one IP can have a couple in flight, no account needed. */
  create(input: JobInput): CreateJobResult {
    this.evictOldest();
    const activeForIp = [...this.jobs.values()].filter(
      (job) => job.ip === input.ip && !isTerminal(job.snapshot.status),
    ).length;
    if (activeForIp >= this.maxPerIp) {
      return {
        ok: false,
        reason: 'rate-limited',
        message: `You already have ${activeForIp} edit${activeForIp === 1 ? '' : 's'} in flight. Wait for one to finish.`,
      };
    }
    if (this.queue.length >= this.maxQueued) {
      return {ok: false, reason: 'queue-full', message: 'The edit queue is full right now. Try again in a moment.'};
    }

    const now = Date.now();
    const id = randomUUID();
    const snapshot: JobSnapshot = {
      id,
      status: 'queued',
      createdAt: now,
      updatedAt: now,
      rounds: 0,
      steps: [],
      spec: normalizeSpec(input.spec),
      reply: '',
      changed: false,
      queuedAhead: this.queue.length,
      attachments: [],
      usage: emptyTokenUsage(),
    };

    const attachments = normalizeAttachments(input.attachments);
    snapshot.attachments = attachments.map(({id, name, kind, mimeType, durationSeconds, frames}) => ({
      id,
      name,
      kind,
      mimeType,
      ...(durationSeconds === undefined ? {} : {durationSeconds}),
      frameTimes: frames.map((frame) => frame.timeSeconds),
    }));

    const record: JobRecord = {
      snapshot,
      attachments,
      credentials: {baseUrl: input.baseUrl, apiKey: input.apiKey, model: input.model},
      prompt: input.prompt,
      history: input.history,
      ip: input.ip,
      controller: new AbortController(),
      subscribers: new Set(),
    };

    this.jobs.set(id, record);
    this.queue.push(id);
    this.pump();
    return {ok: true, job: cloneSnapshot(snapshot)};
  }

  get(id: string): JobSnapshot | undefined {
    const job = this.jobs.get(id);
    return job ? cloneSnapshot(job.snapshot) : undefined;
  }

  getAttachments(id: string): MediaAttachment[] | undefined {
    const job = this.jobs.get(id);
    if (!job) return undefined;
    return job.attachments.map(({id: attachmentId, name, kind, mimeType, durationSeconds, frames}) => ({
      id: attachmentId,
      name,
      kind,
      mimeType,
      ...(durationSeconds === undefined ? {} : {durationSeconds}),
      frames: frames.map((frame) => ({...frame})),
    }));
  }

  /** Sends the current snapshot immediately, then every update. */
  subscribe(id: string, callback: (snapshot: JobSnapshot) => void): (() => void) | null {
    const job = this.jobs.get(id);
    if (!job) return null;
    job.subscribers.add(callback);
    callback(cloneSnapshot(job.snapshot));
    return () => {
      job.subscribers.delete(callback);
    };
  }

  cancel(id: string): boolean {
    const job = this.jobs.get(id);
    if (!job) return false;
    if (isTerminal(job.snapshot.status)) return true;

    if (job.snapshot.status === 'queued') {
      const index = this.queue.indexOf(id);
      if (index >= 0) this.queue.splice(index, 1);
      job.snapshot.status = 'cancelled';
      job.snapshot.error = 'Stopped before it started.';
      job.completedAt = Date.now();
      job.credentials.apiKey = '';
      job.attachments = [];
      this.emit(job);
      return true;
    }

    job.controller.abort();
    return true;
  }

  stats(): {running: number; queued: number; jobs: number} {
    return {running: this.running, queued: this.queue.length, jobs: this.jobs.size};
  }

  private emit(job: JobRecord): void {
    job.snapshot.updatedAt = Date.now();
    job.snapshot.queuedAhead = Math.max(0, this.queue.indexOf(job.snapshot.id));
    const snapshot = cloneSnapshot(job.snapshot);
    for (const subscriber of job.subscribers) {
      try {
        subscriber(snapshot);
      } catch {
        job.subscribers.delete(subscriber);
      }
    }
    if (isTerminal(job.snapshot.status)) job.subscribers.clear();
  }

  private pump(): void {
    while (this.running < this.maxConcurrent && this.queue.length > 0) {
      const id = this.queue.shift();
      if (!id) return;
      void this.execute(id);
    }
  }

  private async execute(id: string): Promise<void> {
    const job = this.jobs.get(id);
    if (!job || job.snapshot.status !== 'queued') return;

    this.running += 1;
    job.snapshot.status = 'running';
    this.emit(job);

    job.timeout = setTimeout(() => {
      job.timedOut = true;
      job.controller.abort();
    }, this.jobTimeoutMs);

    try {
      const result = await runAgent(
        {
          settings: {baseUrl: job.credentials.baseUrl, apiKey: job.credentials.apiKey, model: job.credentials.model},
          spec: job.snapshot.spec,
          prompt: job.prompt,
          history: job.history,
          attachments: job.attachments,
          signal: job.controller.signal,
          onEvent: (event) => {
            if (event.type === 'tool') {
              job.snapshot.steps.push({
                id: randomUUID(),
                name: event.name,
                label: event.label,
                ok: event.ok,
                at: Date.now(),
              });
            } else if (event.type === 'spec') {
              job.snapshot.spec = event.spec;
              job.snapshot.changed = true;
            } else if (event.type === 'thinking') {
              job.snapshot.rounds = event.step;
            } else if (event.type === 'usage') {
              job.snapshot.usage = event.usage;
            }
            this.emit(job);
          },
        },
        {chat: this.chat},
      );

      job.snapshot.spec = result.spec;
      job.snapshot.reply = result.reply;
      job.snapshot.changed = result.changed;
      job.snapshot.usage = result.usage;
      job.snapshot.status = 'done';
    } catch (error) {
      if (job.controller.signal.aborted) {
        job.snapshot.status = 'cancelled';
        job.snapshot.error = job.timedOut
          ? 'The edit took too long and was stopped. Try a smaller change.'
          : 'Stopped. Partial edits are kept.';
      } else {
        job.snapshot.status = 'error';
        job.snapshot.error = formatProviderFailure(error, job.credentials.apiKey);
      }
    } finally {
      if (job.timeout) clearTimeout(job.timeout);
      job.credentials.apiKey = '';
      job.attachments = [];
      job.completedAt = Date.now();
      this.running = Math.max(0, this.running - 1);
      this.emit(job);
      this.pump();
    }
  }

  /** Bounds memory on a public box: finished jobs are the first to go. */
  private evictOldest(): void {
    if (this.jobs.size < this.maxJobs) return;
    const finished = [...this.jobs.values()]
      .filter((job) => isTerminal(job.snapshot.status))
      .sort((a, b) => (a.completedAt ?? a.snapshot.createdAt) - (b.completedAt ?? b.snapshot.createdAt));
    for (const job of finished) {
      if (this.jobs.size < this.maxJobs) break;
      this.jobs.delete(job.snapshot.id);
    }
  }

  private sweep(): void {
    const now = Date.now();
    for (const [id, job] of this.jobs) {
      const finished = job.completedAt ?? job.snapshot.createdAt;
      if (isTerminal(job.snapshot.status) && now - finished > this.ttlMs) {
        this.jobs.delete(id);
        continue;
      }
      // Never let a stuck job hold the queue forever.
      if (!isTerminal(job.snapshot.status) && now - job.snapshot.createdAt > this.ttlMs * 4) {
        job.controller.abort();
      }
    }
  }

  dispose(): void {
    clearInterval(this.sweeper);
    for (const job of this.jobs.values()) {
      if (!isTerminal(job.snapshot.status)) job.controller.abort();
    }
    this.jobs.clear();
  }
}
