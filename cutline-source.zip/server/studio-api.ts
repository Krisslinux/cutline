import type {IncomingMessage, ServerResponse} from 'node:http';
import {createHash, randomBytes, randomUUID} from 'node:crypto';
import {createReadStream, createWriteStream} from 'node:fs';
import {mkdir, rm, stat} from 'node:fs/promises';
import path from 'node:path';
import {pipeline} from 'node:stream/promises';
import {Transform} from 'node:stream';
import {z} from 'zod';
import {publicOrigin, sameOrigin, sessionId, signSession, providerUrl} from './studio-security.ts';
import {StudioStore, StudioError, timelineOf, publicJob} from './studio-store.ts';
import {toSrt} from '../shared/narration.ts';

export const mediaRoot = () => path.resolve(process.env.MEDIA_DIR ?? '.cutline/media');
export function mediaPath(key:string):string {
  if (!/^[a-zA-Z0-9_./-]+$/.test(key) || key.split('/').some(p => p==='..' || p==='.') || key.startsWith('/')) throw new StudioError('Invalid media reference.');
  return path.join(mediaRoot(),key);
}
export const json = (res:ServerResponse,status:number,body:unknown) => {
  res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'private, no-store','x-content-type-options':'nosniff','content-security-policy':"default-src 'none'"}); res.end(JSON.stringify(body));
};
async function body(req:IncomingMessage):Promise<unknown> {
  let size=0; const chunks:Buffer[]=[];
  for await(const chunk of req) {size+=chunk.length;if(size>2*1024*1024)throw new StudioError('Request too large.',413);chunks.push(chunk);}
  try{return JSON.parse(Buffer.concat(chunks).toString());}catch{throw new StudioError('Invalid JSON.');}
}
async function sendMedia(req:IncomingMessage,res:ServerResponse,file:string,mime:string,name?:string):Promise<void> {
  const info=await stat(file).catch(()=>null);if(!info?.isFile())throw new StudioError('File not found.',404);
  let start=0,end=info.size-1,status=200;
  if(req.headers.range){const m=/^bytes=(\d+)-(\d*)$/.exec(req.headers.range);if(!m)throw new StudioError('Invalid byte range.',416);start=Number(m[1]);end=m[2]?Math.min(Number(m[2]),end):end;if(start>end||start>=info.size)throw new StudioError('Invalid byte range.',416);status=206;}
  res.writeHead(status,{'content-type':mime,'content-length':end-start+1,'cache-control':'private, no-store','accept-ranges':'bytes','x-content-type-options':'nosniff',...(status===206?{'content-range':`bytes ${start}-${end}/${info.size}`}:{ }),...(name?{'content-disposition':`attachment; filename="${name}"`}:{})});
  if(req.method==='HEAD')res.end();else await pipeline(createReadStream(file,{start,end}),res);
}
const guestSessionLifetime=30*24*60*60*1000;
async function clearGuestData(store:StudioStore,owner:string):Promise<void>{
  const projects=await store.db.query<{id:string}>('SELECT id FROM projects WHERE owner_id=$1',[owner]);
  for(const project of projects)await rm(mediaPath(`${owner}/${project.id}`),{recursive:true,force:true});
  await store.db.query('DELETE FROM jobs WHERE owner_id=$1',[owner]);await store.db.query('DELETE FROM assets WHERE owner_id=$1',[owner]);await store.db.query('DELETE FROM projects WHERE owner_id=$1',[owner]);
  await store.db.query('DELETE FROM providers WHERE owner_id=$1',[owner]);await store.db.query('DELETE FROM sessions WHERE owner_id=$1',[owner]);await store.db.query('DELETE FROM owners WHERE id=$1',[owner]);
}
function guestIds(browserKey:string):{session:string;owner:string}{
  const secret=process.env.SESSION_SECRET??'cutline-development-guest-session-key';
  const derive=(purpose:string)=>createHash('sha256').update(secret).update(':').update(purpose).update(':').update(browserKey).digest('hex');
  return {session:derive('session'),owner:derive('owner')};
}
export function createStudioApi(store:StudioStore) {
  return async function handle(req:IncomingMessage,res:ServerResponse,url:URL):Promise<void>{
    try {
      const route=url.pathname;
      const mutation=!['GET','HEAD'].includes(req.method??'GET');
      if(mutation&&!sameOrigin(req))return json(res,403,{error:'Request origin is not allowed.'});
      if(route==='/api/studio/health')return json(res,200,{ok:true});
      if(route==='/api/studio/ready'){
        await store.db.query('SELECT 1 AS ok');
        const [worker]=await store.db.query<{heartbeat:number}>('SELECT heartbeat FROM workers ORDER BY heartbeat DESC LIMIT 1');
        const ready=Boolean(worker&&Date.now()-Number(worker.heartbeat)<45000);
        return json(res,ready?200:503,{ok:ready,database:true,worker:ready});
      }
      const now=Date.now();
      let session:{owner_id:string;username:string}|undefined;
      if(route==='/api/studio/session'&&req.method==='POST'){
        const value=z.object({browserKey:z.string().regex(/^[a-f0-9]{64}$/)}).strict().parse(await body(req));
        const ids=guestIds(value.browserKey),username=`guest-${ids.session.slice(0,24)}`;
        await store.db.query('DELETE FROM sessions WHERE expires_at<$1',[now]);
        await store.db.query('INSERT INTO owners(id,username,password_hash) VALUES($1,$2,$3) ON CONFLICT(id) DO NOTHING',[ids.owner,username,`guest:${randomBytes(48).toString('hex')}`]);
        await store.db.query('INSERT INTO sessions(id,owner_id,expires_at) VALUES($1,$2,$3) ON CONFLICT(id) DO UPDATE SET owner_id=excluded.owner_id,expires_at=excluded.expires_at',[ids.session,ids.owner,now+guestSessionLifetime]);
        const secure=publicOrigin().startsWith('https:')||req.headers.origin?.startsWith('https:');
        res.setHeader('set-cookie',`cutline_session=${signSession(ids.session)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${guestSessionLifetime/1000}${secure?'; Secure':''}`);
        const [restored]=await store.db.query<{owner_id:string;username:string}>('SELECT o.id AS owner_id,o.username FROM owners o WHERE o.id=$1',[ids.owner]);session=restored;
        return json(res,200,{username:session.username});
      }else{
        const cookieSid=sessionId(req);
        const [restored]=cookieSid?await store.db.query<{owner_id:string;username:string}>('SELECT s.owner_id,o.username FROM sessions s JOIN owners o ON o.id=s.owner_id WHERE s.id=$1 AND s.expires_at>$2',[cookieSid,now]):[];
        session=restored;
      }
      if(!session)return json(res,401,{error:'Start a private browser session to continue.'});
      const owner=session.owner_id;
      if(route==='/api/studio/session'&&req.method==='GET')return json(res,200,{username:session.username});
      if(route==='/api/studio/logout'&&req.method==='POST'&&session.username.startsWith('guest-')){
        const projects=await store.db.query<{id:string}>('SELECT id FROM projects WHERE owner_id=$1',[owner]);
        for(const project of projects){
          const assets=await store.db.query<{file_key:string}>('SELECT file_key FROM assets WHERE project_id=$1 AND owner_id=$2',[project.id,owner]);
          for(const asset of assets)await rm(mediaPath(asset.file_key),{force:true});
          const jobs=await store.db.query<{output_key:string|null}>('SELECT output_key FROM jobs WHERE project_id=$1 AND owner_id=$2',[project.id,owner]);
          for(const job of jobs)if(job.output_key)await rm(mediaPath(job.output_key),{force:true});
        }
        await store.db.query('DELETE FROM jobs WHERE owner_id=$1',[owner]);await store.db.query('DELETE FROM assets WHERE owner_id=$1',[owner]);await store.db.query('DELETE FROM projects WHERE owner_id=$1',[owner]);
        await store.db.query('DELETE FROM providers WHERE owner_id=$1',[owner]);await store.db.query('DELETE FROM sessions WHERE owner_id=$1',[owner]);await store.db.query('DELETE FROM owners WHERE id=$1',[owner]);
        res.setHeader('set-cookie','cutline_session=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0');return json(res,200,{ok:true});
      }
      if(route==='/api/studio/logout'&&req.method==='POST')return json(res,200,{ok:true});
      if(route==='/api/studio/worker'&&req.method==='GET')return json(res,200,await store.db.query('SELECT id,heartbeat FROM workers ORDER BY heartbeat DESC'));
      if(route==='/api/studio/provider'){
        if(req.method==='GET'){const p=await store.provider(owner);return json(res,200,p?{provider:p.provider,baseUrl:p.baseUrl,model:p.model,hasKey:Boolean(p.apiKey),keyMask:p.apiKey?'••••••••':''}:null);}
        if(req.method==='DELETE'){await store.db.query('DELETE FROM providers WHERE owner_id=$1',[owner]);return json(res,200,{ok:true});}
        if(req.method==='PUT'){
          const p=z.object({provider:z.enum(['openai-compatible','anthropic']),baseUrl:z.string().max(500),model:z.string().min(1).max(200),apiKey:z.string().max(4096).optional()}).strict().parse(await body(req));
          await providerUrl(p.baseUrl);const old=await store.provider(owner);
          await store.saveProvider(owner,{...p,apiKey:p.apiKey??old?.apiKey??''});return json(res,200,{ok:true});
        }
      }
      if(route==='/api/studio/projects'){
        if(req.method==='GET')return json(res,200,await store.db.query('SELECT id,title,revision,updated_at FROM projects WHERE owner_id=$1 ORDER BY updated_at DESC',[owner]));
        if(req.method==='POST'){
          const created=await store.create(owner,await body(req),async ids=>{
            for(const id of ids)await rm(mediaPath(`${owner}/${id}`),{recursive:true,force:true});
          });
          return json(res,201,created);
        }
      }
      let match=/^\/api\/studio\/projects\/([a-zA-Z0-9-]+)(?:\/(assets|draft|render|srt|json))?$/.exec(route);
      if(match){
        const [,id,action]=match;const project=await store.project(owner,id);
        if(!action&&req.method==='GET')return json(res,200,{...project,timeline:timelineOf(project),assets:(await store.assets(owner,id)).map(({file_key:_key,...a})=>a),jobs:(await store.db.query<import('./studio-store.ts').Job>('SELECT * FROM jobs WHERE project_id=$1 AND owner_id=$2 ORDER BY created_at DESC LIMIT 30',[id,owner])).map(publicJob)});
        if(!action&&req.method==='PUT'){
          const p=z.object({revision:z.number().int().nonnegative(),timeline:z.unknown()}).strict().parse(await body(req));const saved=await store.save(owner,id,p.revision,p.timeline);return json(res,200,{...saved,timeline:timelineOf(saved)});
        }
        if(action==='assets'&&req.method==='POST'){
          if(project.revision>0)throw new StudioError('Create a new project to replace source media. Existing revisions retain their original assets.');
          const assets=await store.assets(owner,id);if(assets.length>=41)throw new StudioError('Limit: one narration and 40 images.');
          const mime=(req.headers['content-type']??'').split(';')[0];
          const types:Record<string,{kind:string;ext:string}>={'audio/wav':{kind:'audio',ext:'wav'},'audio/x-wav':{kind:'audio',ext:'wav'},'audio/mpeg':{kind:'audio',ext:'mp3'},'audio/mp4':{kind:'audio',ext:'m4a'},'audio/x-m4a':{kind:'audio',ext:'m4a'},'image/png':{kind:'image',ext:'png'},'image/jpeg':{kind:'image',ext:'jpg'},'image/webp':{kind:'image',ext:'webp'}};
          const type=types[mime];if(!type)throw new StudioError('Use WAV, MP3, M4A, PNG, JPEG, or WebP.');
          if(type.kind==='audio'&&assets.some(a=>a.kind==='audio'))throw new StudioError('This project already has narration.');
          const assetId=randomUUID(),key=`${owner}/${id}/${assetId}.${type.ext}`,file=mediaPath(key);await mkdir(path.dirname(file),{recursive:true,mode:0o700});
          const limit=Math.min(Number(process.env.MAX_UPLOAD_MB??100),200)*1024*1024;
          const total=assets.reduce((s,a)=>s+Number(a.bytes),0);let size=0;const header:Buffer[]=[];let headerSize=0;
          const bounded=new Transform({transform(chunk:Buffer,_encoding,cb){size+=chunk.length;if(headerSize<32){header.push(chunk.subarray(0,32-headerSize));headerSize+=Math.min(chunk.length,32-headerSize);}if(size>limit||size+total>500*1024*1024)cb(new StudioError('Upload limit exceeded.',413));else cb(null,chunk);}});
          try{
            await pipeline(req,bounded,createWriteStream(file,{flags:'wx',mode:0o600}));
            if(size<12)throw new StudioError('Empty or invalid media.');
            const b=Buffer.concat(header);const valid=type.ext==='png'?b.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])):type.ext==='jpg'?b[0]===255&&b[1]===216&&b[2]===255:type.ext==='webp'?b.toString('ascii',0,4)==='RIFF'&&b.toString('ascii',8,12)==='WEBP':type.ext==='wav'?b.toString('ascii',0,4)==='RIFF'&&b.toString('ascii',8,12)==='WAVE':type.ext==='m4a'?b.toString('ascii',4,8)==='ftyp':b.toString('ascii',0,3)==='ID3'||b[0]===255&&(b[1]&224)===224;
            if(!valid)throw new StudioError('Media signature does not match its type.');
            const name=decodeURIComponent(String(req.headers['x-file-name']??'upload')).slice(0,200).replace(/[\x00-\x1f]/g,'');
            await store.db.query('INSERT INTO assets(id,project_id,owner_id,kind,name,mime,bytes,file_key,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9)',[assetId,id,owner,type.kind,name,mime,size,key,Date.now()]);return json(res,201,{id:assetId,name,kind:type.kind});
          }catch(e){await rm(file,{force:true});throw e;}
        }
        if((action==='draft'||action==='render')&&req.method==='POST')return json(res,202,publicJob(await store.enqueue(owner,id,action)));
        if((action==='srt'||action==='json')&&req.method==='GET'){
          const t=timelineOf(project);if(!t)throw new StudioError('No draft yet.');res.writeHead(200,{'content-type':action==='srt'?'application/x-subrip; charset=utf-8':'application/json','cache-control':'private, no-store','content-disposition':`attachment; filename="project.${action}"`});res.end(action==='srt'?toSrt(t):JSON.stringify(t,null,2));return;
        }
      }
      match=/^\/api\/studio\/assets\/([a-zA-Z0-9-]+)$/.exec(route);
      if(match&&['GET','HEAD'].includes(req.method??'')){const a=await store.asset(owner,match[1]);return sendMedia(req,res,mediaPath(a.file_key),a.mime);}
      match=/^\/api\/studio\/jobs\/([a-zA-Z0-9-]+)(?:\/(cancel|retry|download))?$/.exec(route);
      if(match){const [,id,action]=match;const job=await store.job(owner,id);
        if(!action&&req.method==='GET')return json(res,200,publicJob(job));
        if(action==='cancel'&&req.method==='POST'){
          await store.db.query("UPDATE jobs SET cancel_requested=1,state=CASE WHEN state='queued' THEN 'cancelled' ELSE state END,updated_at=$1 WHERE id=$2 AND owner_id=$3 AND state NOT IN ('completed','ready','failed','cancelled')",[Date.now(),id,owner]);return json(res,200,{ok:true});
        }
        if(action==='retry'&&req.method==='POST')return json(res,202,publicJob(await store.retry(owner,id)));
        if(action==='download'&&['GET','HEAD'].includes(req.method??'')){
          const project=await store.project(owner,job.project_id);
          if(job.state!=='completed'||!job.output_key||project.revision!==job.revision)throw new StudioError('Render is incomplete or stale. Render the saved revision again.',409);
          return sendMedia(req,res,mediaPath(job.output_key),'video/mp4','cutline.mp4');
        }
      }
      json(res,404,{error:'Route not found.'});
    }catch(error){if(res.headersSent){res.destroy();return;}const known=error instanceof StudioError;const validation=error instanceof z.ZodError;const conflict=typeof error==='object'&&error!==null&&('code' in error)&&(String(error.code)==='23505'||String(error.code).startsWith('SQLITE_CONSTRAINT'));json(res,known?error.status:validation?400:conflict?409:500,{error:known?error.message:validation?error.issues.map(i=>i.message).slice(0,3).join(' '):conflict?'Another request changed this project. Reload before retrying.':'Request failed. Check server configuration and retry.'});}
  };
}
