import type {IncomingMessage,ServerResponse} from 'node:http';
import {openDb,migrate} from './studio-db.ts';
import {StudioStore} from './studio-store.ts';
import {createStudioApi,json} from './studio-api.ts';
import {secrets, publicOrigin} from './studio-security.ts';
export async function studioRuntime():Promise<{handle:(req:IncomingMessage,res:ServerResponse,url:URL)=>Promise<void>;close:()=>Promise<void>}>{
  if(process.env.NODE_ENV === 'production'){secrets();publicOrigin();}
  const db=await openDb();await migrate(db);const api=createStudioApi(new StudioStore(db));
  return {handle:async(req,res,url)=>{
    if(url.pathname==='/api/health')return api(req,res,new URL('/api/studio/health',url));
    if(url.pathname==='/api/ready')return api(req,res,new URL('/api/studio/ready',url));
    if(!url.pathname.startsWith('/api/studio/'))return json(res,410,{error:'Use the authenticated narration studio API. Legacy anonymous processing is disabled.'});
    return api(req,res,url);
  },close:()=>db.close()};
}
