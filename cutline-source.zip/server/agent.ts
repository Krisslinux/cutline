import {addTokenUsage, readTokenUsage, type ChatCompletion, type ChatMessage, type ToolCall} from '../shared/chat.ts';
import {emptyTokenUsage, type MediaAttachment, type TokenUsage} from '../shared/media.ts';
import {totalSeconds} from '../src/lib/spec.ts';
import {TOOL_DEFINITIONS, applyTool, summarizeToolCall, type ToolOutcome} from '../src/lib/tools.ts';
import type {VideoSpec} from '../src/types.ts';

export interface AgentSettings {
  baseUrl: string;
  apiKey: string;
  model: string;
}

export interface ChatTurn {
  role: 'user' | 'assistant';
  text: string;
}

export type AgentEvent =
  | {type: 'thinking'; step: number}
  | {type: 'tool'; name: string; label: string; ok: boolean}
  | {type: 'spec'; spec: VideoSpec}
  | {type: 'assistant'; text: string}
  | {type: 'usage'; usage: TokenUsage};

export type AgentChatFn = (
  settings: AgentSettings,
  body: {messages: ChatMessage[]; tools?: unknown[]; temperature?: number; attachments?: MediaAttachment[]},
  signal?: AbortSignal,
) => Promise<ChatCompletion>;

export interface AgentInput {
  settings: AgentSettings;
  spec: VideoSpec;
  prompt: string;
  history: ChatTurn[];
  attachments?: MediaAttachment[];
  signal?: AbortSignal;
  onEvent?: (event: AgentEvent) => void;
}

export interface AgentResult {
  spec: VideoSpec;
  reply: string;
  changed: boolean;
  rounds: number;
  usage: TokenUsage;
}

export const MAX_TOOL_ROUNDS = 8;

export const SYSTEM_PROMPT = `You are the director inside Cutline, a video editor built on Remotion. The user talks to you; you change their video by calling tools. You never write code or JSON in the chat.

THE VIDEO
The video is a timeline of scenes rendered with Remotion. Scene kinds:
- title   — a big opening statement (kicker, headline, subhead)
- bullets — headline plus up to 6 short points
- image   — full-bleed image (imageUrl) with kicker/headline caption
- quote   — a pull quote (quote, author)
- stats   — 2-4 big values with labels
- outro   — closing headline, subhead and call-to-action label
Every scene has durationSeconds, an entrance animation (fade-up, slide, scale, blur, typewriter, none) and alignment (left, center).
The palette lives in the theme (background, text, accent, muted, font) and individual scenes can override background, textColor and accent.

HOW TO WORK
1. You always see the current spec in the <current_video_spec> block. Call get_spec only when you need fresh ids after many edits.
2. Use the smallest tool that does the job: update_scene for copy and timing, add_scene / remove_scene / move_scene for structure, set_theme for palette, set_format for aspect ratio, replace_spec only for a total rewrite.
3. Make the whole edit before replying. Do not ask for permission for obvious follow-through.
4. When the user asks a question instead of an edit, answer in one or two sentences and leave the video alone.
5. Never claim a change you did not make with a tool. If a tool fails, read the error and fix it.

DIRECTION
- 4-8 scenes is the sweet spot; 2-6 seconds each; keep the whole thing under 45 seconds unless asked otherwise.
- Headlines: under 8 words, concrete, no marketing mush. Kickers: 1-3 words. Bullets: parallel phrasing, no full stops.
- Keep one idea per scene. Tell a story: hook, substance, proof, close.
- Choose one palette and commit to it. Use the accent for rules, numbers and the call to action — nothing else.
- 9:16 for social, 16:9 for web, 1:1 for feeds. Vertical videos need shorter headlines.
- Default background is near-black; if you go light, change background AND text together for contrast.
- The user may attach images and videos. Their visible id, filename and video frame indexes are listed in <user_attachments>. Use only those exact attachment ids in mediaAttachmentId; each chosen attachment becomes an image scene in the video. Videos are shown to you as sampled still frames, not their complete audio/motion track. Never invent an attachment id or image URL.

OUTPUT
Finish with one or two plain sentences about what you changed, in the voice of an editor. No bullet lists, no markdown headings.`;

const specBlock = (spec: VideoSpec): string =>
  `<current_video_spec>\n${JSON.stringify(spec)}\n</current_video_spec>\n(length: ${totalSeconds(spec).toFixed(1)}s, ${spec.scenes.length} scenes)`;

const parseArguments = (raw: string | undefined): {args: Record<string, unknown>; error?: string} => {
  if (!raw || !raw.trim()) return {args: {}};
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return {args: parsed as Record<string, unknown>};
    }
    return {args: {}, error: 'Tool arguments must be a JSON object.'};
  } catch (error) {
    return {args: {}, error: `Could not parse tool arguments: ${error instanceof Error ? error.message : 'invalid JSON'}`};
  }
};

const toolResultMessage = (call: ToolCall, outcome: ToolOutcome): ChatMessage => ({
  role: 'tool',
  tool_call_id: call.id,
  content: JSON.stringify({ok: outcome.ok, message: outcome.message, spec: outcome.spec}),
});

export async function runAgent(
  input: AgentInput,
  deps: {chat: AgentChatFn},
): Promise<AgentResult> {
  const {settings, prompt, history, signal, onEvent} = input;
  let working = input.spec;
  let changed = false;
  let reply = '';

  const attachmentNote = input.attachments?.length
    ? `\n\n<user_attachments>\n${input.attachments
        .map((attachment, index) =>
          `${index + 1}. id=${attachment.id}; kind=${attachment.kind}; name=${attachment.name}; ${attachment.kind === 'video' ? `duration=${(attachment.durationSeconds ?? 0).toFixed(1)}s; ` : ''}frames=${attachment.frames.map((frame, frameIndex) => `${frameIndex} at ${frame.timeSeconds.toFixed(1)}s`).join(', ')}`,
        )
        .join('\n')}\nChoose a relevant attachment for an image scene by setting mediaAttachmentId to its exact id. For a video, mediaFrameIndex selects the visible representative still.`
    : '';
  const messages: ChatMessage[] = [
    {role: 'system', content: SYSTEM_PROMPT},
    ...history.slice(-10).map((turn) => ({role: turn.role, content: turn.text}) as ChatMessage),
    {role: 'user', content: `${prompt.trim()}\n\n${specBlock(working)}${attachmentNote}`},
  ];

  let usage = emptyTokenUsage();
  let rounds = 0;
  while (rounds < MAX_TOOL_ROUNDS) {
    rounds += 1;
    onEvent?.({type: 'thinking', step: rounds});

    const completion = await deps.chat(
      settings,
      {
        messages,
        tools: TOOL_DEFINITIONS as unknown[],
        temperature: 0.4,
        ...(input.attachments?.length ? {attachments: input.attachments} : {}),
      },
      signal,
    );

    usage = addTokenUsage(usage, readTokenUsage(completion));
    onEvent?.({type: 'usage', usage});

    const choice = completion.choices?.[0];
    const message = choice?.message;
    if (!message) throw new Error('The model returned an empty message.');
    const content = typeof message.content === 'string' ? message.content : '';
    if (content.trim()) reply = content.trim();

    const toolCalls = Array.isArray(message.tool_calls) ? message.tool_calls : [];
    messages.push({
      role: 'assistant',
      content: content || null,
      ...(toolCalls.length ? {tool_calls: toolCalls} : {}),
    });

    if (toolCalls.length === 0) {
      if (reply) onEvent?.({type: 'assistant', text: reply});
      return {
        spec: working,
        reply: reply || (changed ? 'Done — the cut is updated.' : 'Nothing changed.'),
        changed,
        rounds,
        usage,
      };
    }

    for (const call of toolCalls) {
      const name = call.function?.name ?? '';
      const {args, error} = parseArguments(call.function?.arguments);
      if (error) {
        messages.push({
          role: 'tool',
          tool_call_id: call.id,
          content: JSON.stringify({ok: false, message: error, spec: working}),
        });
        onEvent?.({type: 'tool', name, label: error, ok: false});
        continue;
      }

      const outcome = applyTool(working, name, args);
      if (outcome.ok && name !== 'get_spec') {
        working = outcome.spec;
        changed = true;
        onEvent?.({type: 'spec', spec: working});
      }
      onEvent?.({
        type: 'tool',
        name,
        label: summarizeToolCall(name, args, outcome),
        ok: outcome.ok,
      });
      messages.push(toolResultMessage(call, outcome));
    }
  }

  return {
    spec: working,
    reply: reply || `Stopped after ${MAX_TOOL_ROUNDS} edit rounds. Ask me to continue if you want more.`,
    changed,
    rounds,
    usage,
  };
}
