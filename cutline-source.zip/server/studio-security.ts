import {createCipheriv, createDecipheriv, createHmac, randomBytes, scrypt as scryptCallback, timingSafeEqual} from 'node:crypto';
import {promisify} from 'node:util';
import {lookup} from 'node:dns/promises';
import https from 'node:https';
import type {IncomingMessage} from 'node:http';
import {isPrivateHostname, isPrivateIp} from '../shared/chat.ts';
const scrypt = promisify(scryptCallback);
export async function hashPassword(password: string): Promise<string> {
  if (password.length < 12 || password.length > 256) throw new Error('Use a password with 12–256 characters.');
  const salt = randomBytes(16).toString('hex');
  return `${salt}:${(await scrypt(password, salt, 64) as Buffer).toString('hex')}`;
}
export async function checkPassword(password: string, stored: string): Promise<boolean> {
  const [salt, digest] = stored.split(':');
  if (!salt || !digest || password.length > 256) return false;
  const actual = await scrypt(password, salt, 64) as Buffer; const expected = Buffer.from(digest, 'hex');
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
export function secrets(): {session: string; encryption: Buffer} {
  const session = process.env.SESSION_SECRET;
  const key = process.env.CREDENTIALS_KEY;
  if (!session || session.length < 32 || !key || !/^[a-f0-9]{64}$/i.test(key) || session === key) throw new Error('Set independent SESSION_SECRET (32+ characters) and CREDENTIALS_KEY (64 hex characters) in your private environment.');
  return {session, encryption: Buffer.from(key, 'hex')};
}
export function encrypt(value: unknown): string {
  const iv = randomBytes(12); const cipher = createCipheriv('aes-256-gcm', secrets().encryption, iv);
  const data = Buffer.concat([cipher.update(JSON.stringify(value)), cipher.final()]);
  return [iv, cipher.getAuthTag(), data].map(x => x.toString('base64')).join('.');
}
export function decrypt<T>(value: string): T {
  const [iv, tag, data] = value.split('.').map(x => Buffer.from(x, 'base64'));
  const cipher = createDecipheriv('aes-256-gcm', secrets().encryption, iv); cipher.setAuthTag(tag);
  return JSON.parse(Buffer.concat([cipher.update(data), cipher.final()]).toString()) as T;
}
export function signSession(id: string): string {return `${id}.${createHmac('sha256', secrets().session).update(id).digest('hex')}`;}
export function sessionId(req: IncomingMessage): string | null {
  const raw = /(?:^|;\s*)cutline_session=([^;]+)/.exec(req.headers.cookie ?? '')?.[1];
  if (!raw) return null;
  if(!/^[a-zA-Z0-9_-]+\.[a-f0-9]{64}$/.test(raw))return null;
  const id = raw.split('.')[0]; const expected = signSession(id);
  const actualBytes=Buffer.from(raw),expectedBytes=Buffer.from(expected);
  return actualBytes.length === expectedBytes.length && timingSafeEqual(actualBytes, expectedBytes) ? id : null;
}
export function publicOrigin(): string {
  const raw = process.env.PUBLIC_APP_URL || (process.env.NODE_ENV === 'production' ? '' : 'http://localhost:3000');
  const u = new URL(raw);
  if (process.env.NODE_ENV === 'production' && u.protocol !== 'https:') throw new Error('PUBLIC_APP_URL must use HTTPS in production.');
  return u.origin;
}
export function sameOrigin(req: IncomingMessage): boolean {
  const origin = req.headers.origin;
  const allowed = [publicOrigin()];
  if (process.env.NODE_ENV !== 'production' && process.env.DEV_PREVIEW_ORIGIN) allowed.push(new URL(process.env.DEV_PREVIEW_ORIGIN).origin);
  return typeof origin === 'string' && allowed.includes(origin) && req.headers['sec-fetch-site'] !== 'cross-site';
}
export interface ProviderSettings {provider: 'openai-compatible' | 'anthropic'; baseUrl: string; model: string; apiKey: string}
export async function providerUrl(raw: string): Promise<{url: URL; address: string; family: number}> {
  const url = new URL(raw);
  if (url.protocol !== 'https:' || url.username || url.password || url.hash || url.search || isPrivateHostname(url.hostname)) throw new Error('Use a public HTTPS provider URL without credentials, query, or fragment.');
  const addresses = await lookup(url.hostname, {all: true});
  if (!addresses.length || addresses.some(x => isPrivateIp(x.address))) throw new Error('Provider address resolves to a private or reserved network.');
  return {url, ...addresses[0]};
}
export async function providerJson(raw: string, headers: Record<string, string>, body: unknown, signal?: AbortSignal): Promise<unknown> {
  const {url, address, family} = await providerUrl(raw);
  return new Promise((resolve, reject) => {
    const request = https.request(url, {method: 'POST', headers: {...headers, 'content-type': 'application/json'},
      lookup: (_hostname, options, callback) => {
        if(typeof options==='object' && options.all){
          const allCallback=callback as unknown as (error:Error|null,addresses:{address:string;family:number}[])=>void;
          allCallback(null,[{address,family}]);
        }else callback(null,address,family);
      }, signal, timeout: 120000}, response => {
      let size = 0; const chunks: Buffer[] = [];
      response.on('data', (chunk: Buffer) => {size += chunk.length; if (size > 2 * 1024 * 1024) {response.destroy(); reject(new Error('Provider response is too large.'));} else chunks.push(chunk);});
      response.on('error', () => reject(new Error('Provider response interrupted.')));
      response.on('end', () => {
        if (!response.statusCode || response.statusCode < 200 || response.statusCode >= 300) return reject(new Error(`Provider returned HTTP ${response.statusCode ?? 'error'}. Check provider settings and available credits.`));
        try {resolve(JSON.parse(Buffer.concat(chunks).toString()));} catch {reject(new Error('Provider returned invalid JSON.'));}
      });
    });
    request.on('timeout', () => request.destroy(new Error('Provider request timed out.')));
    request.on('error', () => reject(new Error(signal?.aborted ? 'Job cancelled.' : 'Provider connection failed.')));
    request.end(JSON.stringify(body));
  });
}
