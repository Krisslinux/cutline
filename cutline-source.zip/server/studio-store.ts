import {randomUUID} from 'node:crypto';
import {z} from 'zod';
import {timelineSchema, type NarrationTimeline} from '../shared/narration.ts';
import type {Db} from './studio-db.ts';
import {decrypt, encrypt, type ProviderSettings} from './studio-security.ts';
export const terminalStates = ['ready', 'completed', 'failed', 'cancelled'];
export interface Project extends Record<string, unknown> {id: string; owner_id: string; title: string; revision: number; timeline: string | null; hints: string; language: string; updated_at: number}
export interface Asset extends Record<string, unknown> {id: string; project_id: string; owner_id: string; kind: string; name: string; mime: string; bytes: number; duration_ms: number | null; file_key: string}
export interface Job extends Record<string, unknown> {id: string; project_id: string; owner_id: string; kind: 'draft' | 'render'; state: string; stage: string; progress: number | null; payload: string; revision: number; attempt: number; lease_owner: string | null; cancel_requested: number; error: string | null; output_key: string | null; created_at: number; updated_at: number}
export class StudioError extends Error {status: number; constructor(message: string, status = 400) {super(message); this.status = status;}}
export class StudioStore {
  public db: Db;
  constructor(db: Db) {this.db = db;}
  async project(owner: string, id: string): Promise<Project> {
    const [p] = await this.db.query<Project>('SELECT * FROM projects WHERE id=$1 AND owner_id=$2', [id, owner]);
    if (!p) throw new StudioError('Project not found.', 404); return p;
  }
  async assets(owner: string, id: string): Promise<Asset[]> {return this.db.query<Asset>('SELECT * FROM assets WHERE project_id=$1 AND owner_id=$2 ORDER BY created_at,id', [id, owner]);}
  async asset(owner: string, id: string): Promise<Asset> {
    const [a] = await this.db.query<Asset>('SELECT * FROM assets WHERE id=$1 AND owner_id=$2', [id, owner]);
    if (!a) throw new StudioError('Asset not found.', 404); return a;
  }
  async create(owner: string, input: unknown, removePreviousMedia?: (projectIds: string[]) => Promise<void>): Promise<Project> {
    const v = z.object({title: z.string().trim().min(1).max(160), hints: z.string().max(2000).default(''), language: z.string().regex(/^[a-z]{2}$/).default('en')}).strict().parse(input);
    const previous = await this.db.query<{id:string}>('SELECT id FROM projects WHERE owner_id=$1',[owner]);
    if(previous.length){
      const [active] = await this.db.query<{id:string}>('SELECT id FROM jobs WHERE owner_id=$1 AND state NOT IN (\'ready\',\'completed\',\'failed\',\'cancelled\') LIMIT 1',[owner]);
      if(active)throw new StudioError('Wait for the current edit to finish before starting a new one.',409);
      await removePreviousMedia?.(previous.map(project=>project.id));
      for(const project of previous){
        await this.db.query('DELETE FROM jobs WHERE project_id=$1 AND owner_id=$2',[project.id,owner]);
        await this.db.query('DELETE FROM assets WHERE project_id=$1 AND owner_id=$2',[project.id,owner]);
        await this.db.query('DELETE FROM projects WHERE id=$1 AND owner_id=$2',[project.id,owner]);
      }
    }
    const id = randomUUID();
    await this.db.query('INSERT INTO projects(id,owner_id,title,hints,language,updated_at) VALUES($1,$2,$3,$4,$5,$6)', [id,owner,v.title,v.hints,v.language,Date.now()]);
    return this.project(owner,id);
  }
  async save(owner: string, id: string, revision: number, input: unknown): Promise<Project> {
    await this.project(owner,id);
    const timeline = timelineSchema.parse(input);
    const assets = await this.assets(owner,id);
    if (!assets.some(a => a.id === timeline.audioAssetId && a.kind === 'audio') || timeline.imageAssets.some(a => !assets.some(x => x.id === a && x.kind === 'image'))) throw new StudioError('Unknown project assets.');
    const audio = assets.find(a => a.id === timeline.audioAssetId)!;
    if (audio.duration_ms && Math.abs(audio.duration_ms - timeline.durationMs) > 40) throw new StudioError('The timeline must preserve the full narration duration.');
    const result = await this.db.query<Project>('UPDATE projects SET timeline=$1,title=$2,revision=revision+1,updated_at=$3 WHERE id=$4 AND owner_id=$5 AND revision=$6 RETURNING *', [JSON.stringify(timeline),timeline.title,Date.now(),id,owner,revision]);
    if (!result.length) throw new StudioError('Project changed elsewhere. Reload before saving.',409);
    return result[0];
  }
  async job(owner: string, id: string): Promise<Job> {
    const [job] = await this.db.query<Job>('SELECT * FROM jobs WHERE id=$1 AND owner_id=$2',[id,owner]);
    if (!job) throw new StudioError('Job not found.',404); return job;
  }
  async enqueue(owner: string, projectId: string, kind: 'draft' | 'render'): Promise<Job> {
    const p = await this.project(owner,projectId); const assets = await this.assets(owner,projectId);
    if (!assets.some(a => a.kind === 'audio') || !assets.some(a => a.kind === 'image')) throw new StudioError('Upload narration and at least one image first.');
    if (kind === 'render' && !p.timeline) throw new StudioError('Create and save a draft first.');
    const id=randomUUID(), now=Date.now();
    const rows=await this.db.query<Job>(`INSERT INTO jobs(id,project_id,owner_id,kind,state,stage,payload,revision,created_at,updated_at)
      SELECT $1,$2,$3,$4,'queued','Waiting for worker',$5,$6,$7,$7
      WHERE (SELECT COUNT(*) FROM jobs WHERE owner_id=$3 AND state NOT IN ('ready','completed','failed','cancelled')) < 3
      AND NOT EXISTS(SELECT 1 FROM jobs WHERE project_id=$2 AND state NOT IN ('ready','completed','failed','cancelled')) RETURNING *`,
    [id,projectId,owner,kind,JSON.stringify({timeline:p.timeline ? JSON.parse(p.timeline) : null,hints:p.hints,language:p.language,title:p.title}),p.revision,now]);
    if (!rows.length) throw new StudioError('This project already has an active job, or your job limit has been reached.',429);
    return rows[0];
  }
  async claim(worker: string): Promise<Job | undefined> {
    const now=Date.now();
    await this.db.query(`UPDATE jobs SET state=CASE WHEN cancel_requested=1 THEN 'cancelled' ELSE 'failed' END,stage='Interrupted worker; retry available',error='Worker stopped or lease expired. Retry to reuse saved intermediate files.',lease_owner=NULL,updated_at=$1 WHERE state NOT IN ('queued','ready','completed','failed','cancelled') AND lease_until<$1`,[now]);
    const [job]=await this.db.query<Job>(`UPDATE jobs SET state=CASE WHEN kind='render' THEN 'rendering' ELSE 'transcribing' END,stage='Starting worker',lease_owner=$1,lease_until=$2,attempt=attempt+1,updated_at=$3
      WHERE id=(SELECT id FROM jobs WHERE state='queued' AND cancel_requested=0 ORDER BY created_at LIMIT 1) AND state='queued' RETURNING *`,[worker,now+60000,now]);
    return job;
  }
  async progress(id: string, worker: string, state: string, stage: string, progress: number | null): Promise<void> {
    const rows=await this.db.query('UPDATE jobs SET state=$1,stage=$2,progress=$3,updated_at=$4 WHERE id=$5 AND lease_owner=$6 AND cancel_requested=0 RETURNING id',[state,stage,progress,Date.now(),id,worker]);
    if (!rows.length) throw new Error('Job cancelled or worker lease lost.');
  }
  async retry(owner:string,id:string):Promise<Job> {
    const old=await this.job(owner,id);
    if (!['failed','cancelled'].includes(old.state)) throw new StudioError('Only failed or cancelled jobs may be retried.');
    return this.enqueue(owner,old.project_id,old.kind);
  }
  async provider(owner: string): Promise<ProviderSettings | null> {
    const [row]=await this.db.query<{settings:string}>('SELECT settings FROM providers WHERE owner_id=$1',[owner]);
    return row ? decrypt<ProviderSettings>(row.settings) : null;
  }
  async saveProvider(owner:string,value:ProviderSettings):Promise<void> {
    await this.db.query('INSERT INTO providers(owner_id,settings) VALUES($1,$2) ON CONFLICT(owner_id) DO UPDATE SET settings=excluded.settings',[owner,encrypt(value)]);
  }
}
export function timelineOf(project:Project):NarrationTimeline|null {return project.timeline ? timelineSchema.parse(JSON.parse(project.timeline)) : null;}
export function publicJob(job:Job):Record<string,unknown> {
  const {payload: _payload, lease_owner: _lease, owner_id: _owner, ...safe}=job; return safe;
}
