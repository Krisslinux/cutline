import {lookup} from 'node:dns/promises';
import {createReadStream} from 'node:fs';
import {stat} from 'node:fs/promises';
import type {IncomingMessage, ServerResponse} from 'node:http';
import {
  MAX_JOB_REQUEST_BYTES,
  MAX_REQUEST_BYTES,
  checkChatEndpoint,
  handleChatRequest,
  isPrivateHostname,
  isPrivateIp,
  resolveChatEndpoint,
} from '../shared/chat.ts';
import type {VideoSpec} from '../src/types.ts';
import {normalizeSpec} from '../src/lib/spec.ts';
import {normalizeAttachments} from '../shared/media.ts';
import {isJobTerminal, type JobSnapshot, type JobStore} from './jobs.ts';
import {RenderJobStore, type RenderSnapshot} from './render-jobs.ts';

const RATE_WINDOW_MS = 60_000;
const MAX_PROMPT_CHARS = 4_000;
const MAX_RENDER_UPLOAD_BYTES = 200 * 1024 * 1024;
const MAX_HISTORY_TURNS = 20;

export interface ApiOptions {
  store: JobStore;
  allowPrivateEndpoints?: boolean;
  trustProxy?: boolean;
  /** Per-IP limit for POSTs; 0 disables it. */
  rateLimitPerMinute?: number;
  renderStore?: RenderJobStore;
  /** If configured, the prompt editor receives isolated short-lived planning and render APIs. */
  enablePromptEditor?: boolean;
}

const SECURITY_HEADERS: Record<string, string> = {
  'x-content-type-options': 'nosniff',
  'x-frame-options': 'DENY',
  'referrer-policy': 'strict-origin-when-cross-origin',
  'content-security-policy': "default-src 'none'; frame-ancestors 'none'",
};

const sendJson = (res: ServerResponse, status: number, data: unknown): void => {
  if (res.headersSent) return;
  res.writeHead(status, {...SECURITY_HEADERS, 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store'});
  res.end(JSON.stringify(data));
};

const clientIp = (req: IncomingMessage, trustProxy: boolean): string => {
  if (trustProxy) {
    const forwarded = req.headers['x-forwarded-for'];
    if (typeof forwarded === 'string' && forwarded.trim()) return forwarded.split(',')[0].trim();
  }
  return req.socket.remoteAddress ?? 'unknown';
};

type RateBuckets = Map<string, {count: number; resetAt: number}>;

const isRateLimited = (buckets: RateBuckets, key: string, limit: number): boolean => {
  const now = Date.now();
  if (buckets.size > 10_000) {
    for (const [bucketKey, bucket] of buckets) {
      if (bucket.resetAt <= now) buckets.delete(bucketKey);
    }
  }
  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt <= now) {
    buckets.set(key, {count: 1, resetAt: now + RATE_WINDOW_MS});
    return false;
  }
  bucket.count += 1;
  return bucket.count > limit;
};

interface LimitedBody {
  ok: boolean;
  body: string;
}

const readLimitedBody = (req: IncomingMessage, limit = MAX_REQUEST_BYTES): Promise<LimitedBody> =>
  new Promise((resolve, reject) => {
    let size = 0;
    let settled = false;
    const chunks: Buffer[] = [];
    req.on('data', (chunk: Buffer) => {
      if (settled) return;
      size += chunk.length;
      if (size > limit) {
        settled = true;
        resolve({ok: false, body: ''});
        req.resume();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (settled) return;
      settled = true;
      resolve({ok: true, body: Buffer.concat(chunks).toString('utf8')});
    });
    req.on('error', (error) => {
      if (settled) return;
      settled = true;
      reject(error);
    });
  });

const resolvesToPrivateAddress = async (hostname: string): Promise<boolean> => {
  const host = hostname.replace(/^\[|\]$/g, '');
  if (isPrivateHostname(host)) return true;
  if (/^\d{1,3}(?:\.\d{1,3}){3}$/.test(host) || host.includes(':')) return isPrivateIp(host);
  try {
    const records = await lookup(host, {all: true, verbatim: true});
    return records.some((record) => isPrivateIp(record.address));
  } catch {
    // Unresolvable hosts are left to the provider call, which reports the error.
    return false;
  }
};

const pipeResponse = async (response: Response, res: ServerResponse): Promise<void> => {
  const headers: Record<string, string> = {...SECURITY_HEADERS};
  response.headers.forEach((value, key) => {
    headers[key.toLowerCase()] = value;
  });
  headers['cache-control'] = 'no-store';
  res.writeHead(response.status, headers);
  res.end(Buffer.from(await response.arrayBuffer()));
};

const streamRender = (req: IncomingMessage, res: ServerResponse, store: RenderJobStore, jobId: string): void => {
  const current = store.get(jobId);
  if (!current) {
    sendJson(res, 404, {error: {message: 'That render has expired or does not exist.'}});
    return;
  }
  res.writeHead(200, {
    ...SECURITY_HEADERS,
    'content-type': 'text/event-stream; charset=utf-8',
    'cache-control': 'no-store, no-transform',
    connection: 'keep-alive',
    'x-accel-buffering': 'no',
  });
  res.write('retry: 2000\n\n');
  const send = (snapshot: RenderSnapshot): void => {
    if (res.writableEnded) return;
    res.write(`data: ${JSON.stringify(snapshot)}\n\n`);
    if (['done', 'error', 'cancelled'].includes(snapshot.status)) res.end();
  };
  const unsubscribe = store.subscribe(jobId, send);
  if (!unsubscribe) {
    res.end();
    return;
  }
  const heartbeat = setInterval(() => {
    if (!res.writableEnded) res.write(': keep-alive\n\n');
  }, 15_000);
  heartbeat.unref?.();
  const cleanup = (): void => {
    clearInterval(heartbeat);
    unsubscribe();
  };
  req.on('close', cleanup);
  res.on('close', cleanup);
};

const sendRenderFile = async (req: IncomingMessage, res: ServerResponse, filePath: string): Promise<void> => {
  const info = await stat(filePath).catch(() => null);
  if (!info?.isFile()) return sendJson(res, 404, {error: {message: 'The rendered video is no longer available.'}});

  const range = req.headers.range;
  let start = 0;
  let end = info.size - 1;
  let status = 200;
  if (range) {
    const match = /^bytes=(\d*)-(\d*)$/.exec(range);
    if (!match || (!match[1] && !match[2])) {
      res.writeHead(416, {...SECURITY_HEADERS, 'content-range': `bytes */${info.size}`, 'cache-control': 'no-store'});
      res.end();
      return;
    }
    if (match[1]) {
      start = Number(match[1]);
      if (match[2]) end = Math.min(info.size - 1, Number(match[2]));
    } else {
      const suffix = Number(match[2]);
      start = Math.max(0, info.size - suffix);
    }
    if (start >= info.size || end < start) {
      res.writeHead(416, {...SECURITY_HEADERS, 'content-range': `bytes */${info.size}`, 'cache-control': 'no-store'});
      res.end();
      return;
    }
    status = 206;
  }

  const headers: Record<string, string | number> = {
    ...SECURITY_HEADERS,
    'content-type': 'video/mp4',
    'content-disposition': 'attachment; filename="cutline-video.mp4"',
    'accept-ranges': 'bytes',
    'content-length': end - start + 1,
    'cache-control': 'private, no-store',
  };
  if (status === 206) headers['content-range'] = `bytes ${start}-${end}/${info.size}`;
  res.writeHead(status, headers);
  if (req.method === 'HEAD') {
    res.end();
    return;
  }
  await new Promise<void>((resolve, reject) => {
    const stream = createReadStream(filePath, {start, end});
    stream.on('error', reject);
    res.on('finish', resolve);
    res.on('close', resolve);
    stream.pipe(res);
  });
};

const streamJob = (req: IncomingMessage, res: ServerResponse, store: JobStore, jobId: string): void => {
  const current = store.get(jobId);
  if (!current) {
    sendJson(res, 404, {error: {message: 'That edit job has expired or does not exist.'}});
    return;
  }

  res.writeHead(200, {
    ...SECURITY_HEADERS,
    'content-type': 'text/event-stream; charset=utf-8',
    'cache-control': 'no-store, no-transform',
    connection: 'keep-alive',
    'x-accel-buffering': 'no',
  });
  res.write('retry: 2000\n\n');

  const send = (snapshot: JobSnapshot): void => {
    if (res.writableEnded) return;
    res.write(`data: ${JSON.stringify(snapshot)}\n\n`);
    if (isJobTerminal(snapshot.status)) res.end();
  };

  const unsubscribe = store.subscribe(jobId, send);
  if (!unsubscribe) {
    res.end();
    return;
  }

  const heartbeat = setInterval(() => {
    if (!res.writableEnded) res.write(': keep-alive\n\n');
  }, 15_000);
  heartbeat.unref?.();

  const cleanup = (): void => {
    clearInterval(heartbeat);
    unsubscribe();
  };
  req.on('close', cleanup);
  res.on('close', cleanup);
};

interface JobPayload {
  baseUrl?: unknown;
  apiKey?: unknown;
  model?: unknown;
  prompt?: unknown;
  spec?: unknown;
  history?: unknown;
  attachments?: unknown;
}

const readString = (value: unknown): string => (typeof value === 'string' ? value.trim() : '');

export function createApiRouter(options: ApiOptions) {
  const buckets: RateBuckets = new Map();
  const limit = options.rateLimitPerMinute ?? 40;
  const allowPrivate = Boolean(options.allowPrivateEndpoints);
  const enablePromptEditor = Boolean(options.enablePromptEditor);
  const renderStore = enablePromptEditor ? options.renderStore : undefined;

  const limited = (req: IncomingMessage, res: ServerResponse): boolean => {
    if (limit <= 0) return false;
    if (isRateLimited(buckets, clientIp(req, Boolean(options.trustProxy)), limit)) {
      res.setHeader('retry-after', '60');
      sendJson(res, 429, {error: {message: 'Too many requests. Try again in a minute.'}});
      return true;
    }
    return false;
  };

  const handleJobs = async (req: IncomingMessage, res: ServerResponse): Promise<void> => {
    if (req.method !== 'POST') return sendJson(res, 405, {error: {message: 'Use POST to start an edit.'}});
    if (limited(req, res)) return;

    const body = await readLimitedBody(req, MAX_JOB_REQUEST_BYTES);
    if (!body.ok) return sendJson(res, 413, {error: {message: 'Request body too large.'}});

    let payload: JobPayload;
    try {
      payload = JSON.parse(body.body) as JobPayload;
    } catch {
      return sendJson(res, 400, {error: {message: 'Request body must be JSON.'}});
    }

    const baseUrl = readString(payload.baseUrl);
    const apiKey = readString(payload.apiKey);
    const model = readString(payload.model);
    const prompt = readString(payload.prompt);

    if (!baseUrl) return sendJson(res, 400, {error: {message: 'Missing baseUrl. Add your API base URL in Settings.'}});
    if (!model) return sendJson(res, 400, {error: {message: 'Missing model. Add your model id in Settings.'}});
    if (!prompt) return sendJson(res, 400, {error: {message: 'Say what you want changed.'}});
    if (prompt.length > MAX_PROMPT_CHARS) {
      return sendJson(res, 400, {error: {message: `Keep prompts under ${MAX_PROMPT_CHARS} characters.`}});
    }
    if (typeof payload.spec !== 'object' || payload.spec === null) {
      return sendJson(res, 400, {error: {message: 'Missing spec.'}});
    }

    const check = checkChatEndpoint(baseUrl, {allowPrivateEndpoints: allowPrivate});
    if (!check.ok) return sendJson(res, 400, {error: {message: check.message}});
    if (!allowPrivate && (await resolvesToPrivateAddress(check.hostname))) {
      return sendJson(res, 400, {
        error: {
          message: `That base URL resolves to a private address (${check.hostname}). Use a public endpoint, or set ALLOW_PRIVATE_ENDPOINTS=true if you host the model yourself.`,
        },
      });
    }

    let attachments;
    try {
      attachments = normalizeAttachments(payload.attachments);
    } catch (error) {
      return sendJson(res, 400, {error: {message: error instanceof Error ? error.message : 'Invalid attachments.'}});
    }

    const history = Array.isArray(payload.history)
      ? payload.history
          .filter((turn): turn is {role: 'user' | 'assistant'; text: string} => {
            if (typeof turn !== 'object' || turn === null) return false;
            const record = turn as Record<string, unknown>;
            return (record.role === 'user' || record.role === 'assistant') && typeof record.text === 'string';
          })
          .slice(-MAX_HISTORY_TURNS)
          .map((turn) => ({role: turn.role, text: turn.text.slice(0, 2_000)}))
      : [];

    const result = options.store.create({
      baseUrl,
      apiKey,
      model,
      spec: payload.spec as VideoSpec,
      prompt,
      history,
      attachments,
      ip: clientIp(req, Boolean(options.trustProxy)),
    });

    if (!result.ok) {
      return sendJson(res, result.reason === 'rate-limited' ? 429 : 503, {error: {message: result.message}});
    }
    return sendJson(res, 202, {id: result.job.id, status: result.job.status, queuedAhead: result.job.queuedAhead});
  };

  return async function handleApiRequest(
    req: IncomingMessage,
    res: ServerResponse,
    url: URL,
  ): Promise<void> {
    const pathname = url.pathname;

    if (pathname === '/api/health') {
      return sendJson(res, 200, {ok: true, uptime: Math.round(process.uptime()), jobs: options.store.stats()});
    }

    if (pathname === '/api/chat') {
      if (!enablePromptEditor) return sendJson(res, 410, {error: {message: 'Prompt-directed editing is not enabled on this server.'}});
      if (req.method === 'OPTIONS') {
        res.writeHead(204, {...SECURITY_HEADERS, allow: 'POST, OPTIONS'});
        res.end();
        return;
      }
      if (req.method !== 'POST') return sendJson(res, 405, {error: {message: 'Use POST to reach your model.'}});
      if (limited(req, res)) return;

      const body = await readLimitedBody(req);
      if (!body.ok) return sendJson(res, 413, {error: {message: 'Request body too large.'}});

      if (!allowPrivate) {
        try {
          const parsed = JSON.parse(body.body) as {baseUrl?: unknown};
          if (typeof parsed.baseUrl === 'string' && parsed.baseUrl.trim()) {
            const hostname = new URL(resolveChatEndpoint(parsed.baseUrl)).hostname;
            if (await resolvesToPrivateAddress(hostname)) {
              return sendJson(res, 400, {
                error: {
                  message: `That base URL points at a private or local address (${hostname}). Use a public endpoint, or set ALLOW_PRIVATE_ENDPOINTS=true if you host the model yourself.`,
                },
              });
            }
          }
        } catch {
          // Invalid JSON or URL: delegated call returns the precise error.
        }
      }

      const request = new Request('http://localhost/api/chat', {
        method: 'POST',
        headers: {'content-type': 'application/json'},
        body: body.body,
      });
      const response = await handleChatRequest(request, {allowPrivateEndpoints: allowPrivate});
      await pipeResponse(response, res);
      return;
    }

    if (pathname === '/api/jobs') {
      if (!enablePromptEditor) return sendJson(res, 410, {error: {message: 'Prompt-directed editing is not enabled on this server.'}});
      return handleJobs(req, res);
    }

    if (pathname === '/api/renders') {
      if (!enablePromptEditor) return sendJson(res, 410, {error: {message: 'Prompt-directed rendering is not enabled on this server.'}});
      if (!renderStore) return sendJson(res, 503, {error: {message: 'Server-side rendering is not configured.'}});
      if (req.method !== 'POST') return sendJson(res, 405, {error: {message: 'Use POST to start a render.'}});
      if (limited(req, res)) return;
      const body = await readLimitedBody(req, MAX_REQUEST_BYTES);
      if (!body.ok) return sendJson(res, 413, {error: {message: 'Render request body too large.'}});
      let payload: {spec?: unknown; media?: unknown};
      try {
        payload = JSON.parse(body.body) as {spec?: unknown; media?: unknown};
      } catch {
        return sendJson(res, 400, {error: {message: 'Render request must be JSON.'}});
      }
      try {
        const spec = normalizeSpec(payload.spec);
        if (spec.scenes.some((scene) => scene.imageUrl && !scene.mediaAttachmentId)) {
          throw new Error('For server rendering, upload external image URLs as image attachments first.');
        }
        const result = await renderStore.create({spec, attachments: payload.media, ip: clientIp(req, Boolean(options.trustProxy))});
        if (!result.ok) return sendJson(res, result.reason === 'rate-limited' ? 429 : 503, {error: {message: result.message}});
        return sendJson(res, 202, result.job);
      } catch (error) {
        return sendJson(res, 400, {error: {message: error instanceof Error ? error.message : 'Invalid render request.'}});
      }
    }

    const renderMatch = /^\/api\/renders\/([0-9a-fA-F-]{36})(?:\/(events|cancel|start|download|media\/([a-zA-Z0-9_-]{1,80})))?$/.exec(pathname);
    if (renderMatch) {
      if (!enablePromptEditor) return sendJson(res, 410, {error: {message: 'Prompt-directed rendering is not enabled on this server.'}});
      if (!renderStore) return sendJson(res, 503, {error: {message: 'Server-side rendering is not configured.'}});
      const [, renderId, action, mediaId] = renderMatch;
      if (action?.startsWith('media/')) {
        if (req.method !== 'PUT') return sendJson(res, 405, {error: {message: 'Use PUT to upload render media.'}});
        if (limited(req, res)) return;
        const size = Number(req.headers['content-length']);
        if (!Number.isSafeInteger(size) || size < 1 || size > MAX_RENDER_UPLOAD_BYTES) {
          return sendJson(res, 413, {error: {message: 'Each uploaded media file must be no larger than 200 MB.'}});
        }
        try {
          await renderStore.uploadMedia(renderId, mediaId, req, size);
          return sendJson(res, 200, {ok: true, render: renderStore.get(renderId)});
        } catch (error) {
          return sendJson(res, 400, {error: {message: error instanceof Error ? error.message : 'Media upload failed.'}});
        }
      }
      if (action === 'start') {
        if (req.method !== 'POST') return sendJson(res, 405, {error: {message: 'Use POST to queue the render.'}});
        if (limited(req, res)) return;
        try {
          const started = renderStore.start(renderId);
          if (!started) return sendJson(res, 503, {error: {message: 'The render queue is full or this render already started.'}});
          return sendJson(res, 202, renderStore.get(renderId));
        } catch (error) {
          return sendJson(res, 400, {error: {message: error instanceof Error ? error.message : 'Could not start the render.'}});
        }
      }
      if (action === 'cancel') {
        if (req.method !== 'POST') return sendJson(res, 405, {error: {message: 'Use POST to cancel the render.'}});
        if (limited(req, res)) return;
        if (!renderStore.cancel(renderId)) return sendJson(res, 404, {error: {message: 'That render has expired or does not exist.'}});
        return sendJson(res, 200, {ok: true, render: renderStore.get(renderId)});
      }
      if (action === 'events') {
        if (req.method !== 'GET') return sendJson(res, 405, {error: {message: 'Use GET for render progress.'}});
        return streamRender(req, res, renderStore, renderId);
      }
      if (action === 'download') {
        if (req.method !== 'GET' && req.method !== 'HEAD') return sendJson(res, 405, {error: {message: 'Use GET to download the MP4.'}});
        const filePath = renderStore.getOutputPath(renderId);
        if (!filePath) return sendJson(res, 404, {error: {message: 'The rendered video is not ready or has expired.'}});
        return sendRenderFile(req, res, filePath);
      }
      if (req.method !== 'GET') return sendJson(res, 405, {error: {message: 'Use GET to read render status.'}});
      const snapshot = renderStore.get(renderId);
      if (!snapshot) return sendJson(res, 404, {error: {message: 'That render has expired or does not exist.'}});
      return sendJson(res, 200, snapshot);
    }

    const jobMatch = /^\/api\/jobs\/([0-9a-fA-F-]{36})(?:\/(events|cancel))?$/.exec(pathname);
    if (jobMatch) {
      if (!enablePromptEditor) return sendJson(res, 410, {error: {message: 'Prompt-directed editing is not enabled on this server.'}});
      const [, jobId, action] = jobMatch;
      if (action === 'cancel') {
        if (req.method !== 'POST') return sendJson(res, 405, {error: {message: 'Use POST to cancel.'}});
        if (limited(req, res)) return;
        const cancelled = options.store.cancel(jobId);
        if (!cancelled) return sendJson(res, 404, {error: {message: 'That edit job has expired or does not exist.'}});
        return sendJson(res, 200, {ok: true, job: options.store.get(jobId)});
      }
      if (action === 'events') {
        if (req.method !== 'GET') return sendJson(res, 405, {error: {message: 'Use GET for the event stream.'}});
        return streamJob(req, res, options.store, jobId);
      }
      if (req.method !== 'GET') return sendJson(res, 405, {error: {message: 'Use GET to read a job.'}});
      const job = options.store.get(jobId);
      if (!job) return sendJson(res, 404, {error: {message: 'That edit job has expired or does not exist.'}});
      return sendJson(res, 200, job);
    }

    return sendJson(res, 404, {error: {message: 'Not found.'}});
  };
}
