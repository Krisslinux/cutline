/**
 * Production server for a VPS deployment: serves the built SPA from dist/ and
 * wires the shared API (chat proxy, background job queue, SSE progress).
 *
 * Run with `npm run build && npm start`.
 */
import {createReadStream} from 'node:fs';
import {readFile, stat} from 'node:fs/promises';
import {createServer, type IncomingMessage, type Server, type ServerResponse} from 'node:http';
import path from 'node:path';
import {pipeline} from 'node:stream/promises';
import {pathToFileURL} from 'node:url';
import {gzipSync} from 'node:zlib';
import {createApiRouter} from './api.ts';
import {JobStore} from './jobs.ts';
import {createProviderChat} from './provider.ts';
import {RenderJobStore} from './render-jobs.ts';

const MIME_TYPES: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.map': 'application/json; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
  '.webmanifest': 'application/manifest+json',
};

const COMPRESSIBLE = new Set(['.html', '.js', '.mjs', '.css', '.json', '.svg', '.map', '.txt', '.xml', '.webmanifest']);

const SECURITY_HEADERS: Record<string, string> = {
  'x-content-type-options': 'nosniff',
  'x-frame-options': 'DENY',
  'referrer-policy': 'strict-origin-when-cross-origin',
  'permissions-policy': 'camera=(), microphone=(), geolocation=(), payment=()',
  'content-security-policy': [
    "default-src 'self'",
    "script-src 'self'",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' data: https://fonts.gstatic.com",
    "img-src 'self' data: blob: https:",
    "media-src 'self' blob: data: https:",
    "connect-src 'self'",
    "worker-src 'self' blob:",
    "frame-ancestors 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "object-src 'none'",
  ].join('; '),
};

export interface ServerOptions {
  staticDir?: string;
  /** Off by default: blocks private/local model endpoints to prevent SSRF. */
  allowPrivateEndpoints?: boolean;
  /** Trust the first X-Forwarded-For hop (set behind Caddy/nginx). */
  trustProxy?: boolean;
  rateLimitPerMinute?: number;
  /** Injectable for tests; a default store is created otherwise. */
  store?: JobStore;
  renderStore?: RenderJobStore;
  enablePromptEditor?: boolean;
  apiHandler?: (req: IncomingMessage, res: ServerResponse, url: URL) => Promise<void>;
}

const sendJson = (res: ServerResponse, status: number, data: unknown): void => {
  if (res.headersSent) return;
  res.writeHead(status, {...SECURITY_HEADERS, 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store'});
  res.end(JSON.stringify(data));
};

const sendFile = async (
  req: IncomingMessage,
  res: ServerResponse,
  filePath: string,
  cacheControl: string,
): Promise<boolean> => {
  const info = await stat(filePath).catch(() => null);
  if (!info || !info.isFile()) return false;

  const extension = path.extname(filePath).toLowerCase();
  const etag = `W/"${info.size.toString(16)}-${Math.floor(info.mtimeMs).toString(16)}"`;
  const headers: Record<string, string | number> = {
    ...SECURITY_HEADERS,
    'content-type': MIME_TYPES[extension] ?? 'application/octet-stream',
    'cache-control': cacheControl,
    etag,
  };

  if (req.headers['if-none-match'] === etag) {
    res.writeHead(304, headers);
    res.end();
    return true;
  }

  const wantsGzip = /\bgzip\b/.test(String(req.headers['accept-encoding'] ?? ''));
  if (COMPRESSIBLE.has(extension) && wantsGzip && info.size > 1400) {
    const compressed = gzipSync(await readFile(filePath), {level: 6});
    res.writeHead(200, {
      ...headers,
      'content-encoding': 'gzip',
      'content-length': compressed.length,
      vary: 'accept-encoding',
    });
    res.end(req.method === 'HEAD' ? undefined : compressed);
    return true;
  }

  res.writeHead(200, {...headers, 'content-length': info.size});
  if (req.method === 'HEAD') {
    res.end();
    return true;
  }
  await pipeline(createReadStream(filePath), res).catch(() => res.destroy());
  return true;
};

const serveStatic = async (
  req: IncomingMessage,
  res: ServerResponse,
  url: URL,
  staticDir: string,
): Promise<void> => {
  let pathname: string;
  try {
    pathname = decodeURIComponent(url.pathname);
  } catch {
    return sendJson(res, 400, {error: {message: 'Bad request.'}});
  }
  if (pathname.includes('\0') || pathname.split('/').includes('..')) {
    return sendJson(res, 400, {error: {message: 'Bad request.'}});
  }

  const root = path.resolve(staticDir);
  const relative = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
  const filePath = path.resolve(root, relative);
  if (filePath !== root && !filePath.startsWith(root + path.sep)) {
    return sendJson(res, 404, {error: {message: 'Not found.'}});
  }

  const hashedAsset = relative.startsWith('assets/') && /-[A-Za-z0-9_-]{8,}\./.test(relative);
  const cacheControl = relative === 'index.html' ? 'no-cache' : hashedAsset ? 'public, max-age=31536000, immutable' : 'public, max-age=3600';

  if (await sendFile(req, res, filePath, cacheControl)) return;

  const looksLikeFile = relative.startsWith('assets/') || /\.\w{2,5}$/.test(relative);
  if (looksLikeFile) return sendJson(res, 404, {error: {message: 'Not found.'}});

  const servedIndex = await sendFile(req, res, path.join(root, 'index.html'), 'no-cache');
  if (!servedIndex) {
    return sendJson(res, 503, {error: {message: 'Build output missing. Run `npm run build` first.'}});
  }
};

export function createApp(options: ServerOptions = {}): Server {
  const staticDir = options.staticDir ?? path.resolve(process.cwd(), 'dist');
  const allowPrivate = Boolean(options.allowPrivateEndpoints);
  const store = options.store ?? new JobStore({chat: createProviderChat(allowPrivate)});
  const api = options.apiHandler ?? createApiRouter({
    store,
    renderStore: options.renderStore,
    enablePromptEditor: options.enablePromptEditor,
    allowPrivateEndpoints: allowPrivate,
    trustProxy: options.trustProxy,
    rateLimitPerMinute: options.rateLimitPerMinute,
  });

  return createServer((req, res) => {
    const url = new URL(req.url ?? '/', `http://${req.headers.host ?? 'localhost'}`);

    const route = async () => {
      if (url.pathname === '/api' || url.pathname.startsWith('/api/')) {
        return api(req, res, url);
      }
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        return sendJson(res, 405, {error: {message: 'Method not allowed.'}});
      }
      return serveStatic(req, res, url, staticDir);
    };

    route().catch((error: unknown) => {
      console.error('[cutline] request failed', error instanceof Error ? error.message : error);
      if (!res.headersSent) sendJson(res, 500, {error: {message: 'Server error.'}});
      else res.destroy();
    });
  });
}

export const startStudioWorker = async (options: {pollIntervalMs?: number} = {}): Promise<() => Promise<void>> => {
  const {runWorker} = await import('../worker/index.ts');
  const controller = new AbortController();
  const workerPromise = runWorker({signal: controller.signal, pollIntervalMs: options.pollIntervalMs});
  return async () => {
    controller.abort();
    await workerPromise;
  };
};

const readIntegerEnv = (name: string, fallback: number, minimum = 1): number => {
  const raw = process.env[name];
  if (raw === undefined || raw.trim() === '') return fallback;
  const value = Number(raw);
  return Number.isSafeInteger(value) && value >= minimum ? value : fallback;
};

const isDirectRun = (() => {
  const entry = process.argv[1];
  if (!entry) return false;
  try {
    return pathToFileURL(path.resolve(entry)).href === import.meta.url;
  } catch {
    return false;
  }
})();

if (isDirectRun) {
  const {studioRuntime} = await import('./studio-runtime.ts');
  const studio = await studioRuntime();
  const parsedPort = Number(process.env.PORT ?? '');
  const port = Number.isFinite(parsedPort) && parsedPort > 0 ? parsedPort : 3000;
  const host = process.env.HOST ?? '0.0.0.0';
  const allowPrivateEndpoints = process.env.ALLOW_PRIVATE_ENDPOINTS === 'true';
  const store = new JobStore({chat: createProviderChat(allowPrivateEndpoints)});
  const renderStore = new RenderJobStore({
    projectRoot: process.cwd(),
    maxConcurrent: 1,
    maxPerIp: readIntegerEnv('RENDER_JOBS_PER_IP', 1),
    maxQueued: readIntegerEnv('RENDER_QUEUE_LIMIT', 2),
    ttlMs: readIntegerEnv('RENDER_RETENTION_SECONDS', 900, 60) * 1_000,
  });
  const stopStudioWorker = await startStudioWorker();

  const server = createApp({
    apiHandler: studio.handle,
    staticDir: process.env.STATIC_DIR ?? path.resolve(process.cwd(), 'dist'),
    store,
    renderStore,
    enablePromptEditor: true,
    allowPrivateEndpoints,
    trustProxy: process.env.TRUST_PROXY === 'true',
    rateLimitPerMinute: readIntegerEnv('API_RATE_LIMIT_PER_MINUTE', 30),
  });

  server.listen(port, host, () => {
    console.log(`[cutline] listening on http://${host}:${port}`);

  });

  const shutdown = (signal: string) => {
    console.log(`[cutline] ${signal} received, shutting down`);
    server.close(() => {
      store.dispose();
      renderStore.dispose();
      void Promise.all([studio.close(), stopStudioWorker()]).finally(() => process.exit(0));
    });
    setTimeout(() => process.exit(1), 10_000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}
