import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App';
import {NarrationStudio} from './components/NarrationStudio';
import './index.css';

const container = document.getElementById('root');
if (!container) throw new Error('Root element missing');

createRoot(container).render(
  <StrictMode>
    {new URLSearchParams(location.search).get('editor') === 'classic' ? <App /> : <NarrationStudio />}
  </StrictMode>,
);
