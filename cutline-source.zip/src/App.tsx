import type {PlayerRef} from '@remotion/player';
import {useCallback, useEffect, useRef, useState} from 'react';
import {ChatPanel, type ChatEntry} from './components/ChatPanel';
import {ExportDialog} from './components/ExportDialog';
import {PreviewStage} from './components/PreviewStage';
import {SceneRail} from './components/SceneRail';
import {SettingsDialog} from './components/SettingsDialog';
import {TopBar} from './components/TopBar';
import {cancelJob, createJob, fetchJob, isTerminalStatus, watchJob, type JobSnapshot} from './lib/jobs';
import {
  DEFAULT_SPEC,
  makeScene,
  normalizeSpec,
  sceneStartFrame,
  setAspect,
  totalFrames,
  totalSeconds,
} from './lib/spec';
import {describeEndpoint, isConfigured, loadSettings, saveSettings, type AiSettings} from './lib/settings';
import type {AspectRatio, MediaAttachment, Scene, VideoSpec, VideoTheme} from './types';
import {prepareMediaFiles} from './lib/media';
import {createPromptStoryboard} from './lib/prompt-storyboard';
import {cancelRender, createRender, downloadRender, fetchRender, watchRender, type RenderSnapshot} from './lib/render';

const SPEC_KEY = 'cutline.spec.v1';
const LOG_KEY = 'cutline.log.v1';
const JOB_KEY = 'cutline.job.v1';

interface History {
  past: VideoSpec[];
  present: VideoSpec;
  future: VideoSpec[];
}

interface StoredJob {
  id: string;
  seen: number;
}

interface RetryableEdit {
  prompt: string;
  settings: AiSettings;
  history: {role: 'user' | 'assistant'; text: string}[];
  attachments: MediaAttachment[];
}

const loadSpec = (): VideoSpec => {
  try {
    const raw = localStorage.getItem(SPEC_KEY);
    if (raw) return normalizeSpec(JSON.parse(raw));
  } catch {
    /* fall through to the starter project */
  }
  return normalizeSpec(DEFAULT_SPEC);
};

const loadLog = (): ChatEntry[] => {
  try {
    const raw = localStorage.getItem(LOG_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((entry): entry is ChatEntry => {
      if (typeof entry !== 'object' || entry === null) return false;
      const record = entry as Record<string, unknown>;
      return typeof record.id === 'string' && typeof record.role === 'string';
    }).slice(-60);
  } catch {
    return [];
  }
};

const loadStoredJob = (): StoredJob | null => {
  try {
    const raw = localStorage.getItem(JOB_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Partial<StoredJob>;
    if (typeof parsed.id !== 'string' || !parsed.id) return null;
    return {id: parsed.id, seen: typeof parsed.seen === 'number' ? parsed.seen : 0};
  } catch {
    return null;
  }
};

const saveStoredJob = (job: StoredJob | null): void => {
  try {
    if (job) localStorage.setItem(JOB_KEY, JSON.stringify(job));
    else localStorage.removeItem(JOB_KEY);
  } catch {
    /* ignore */
  }
};

export default function App() {
  const [history, setHistory] = useState<History>(() => ({past: [], present: loadSpec(), future: []}));
  const [entries, setEntries] = useState<ChatEntry[]>(loadLog);
  const [selectedId, setSelectedId] = useState<string | null>(() => history.present.scenes[0]?.id ?? null);
  const [settings, setSettings] = useState<AiSettings>(loadSettings);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [jobId, setJobId] = useState<string | null>(null);
  const [status, setStatus] = useState('Thinking…');
  const [toast, setToast] = useState<string | null>(null);
  const [attachments, setAttachments] = useState<MediaAttachment[]>([]);
  const [uploading, setUploading] = useState(false);
  const [usage, setUsage] = useState<JobSnapshot['usage'] | null>(null);
  const [retryableEdit, setRetryableEdit] = useState<RetryableEdit | null>(null);
  const [render, setRender] = useState<RenderSnapshot | null>(null);
  const [renderBusy, setRenderBusy] = useState(false);
  const renderWatchRef = useRef<(() => void) | null>(null);
  const renderAttachmentsRef = useRef<MediaAttachment[]>([]);
  renderAttachmentsRef.current = attachments;

  const playerRef = useRef<PlayerRef | null>(null);
  const counter = useRef(0);
  const jobRef = useRef<{id: string; before: VideoSpec; seen: number} | null>(null);
  const stopWatchRef = useRef<(() => void) | null>(null);
  const finishedRef = useRef<string | null>(null);
  const attachmentsRef = useRef<MediaAttachment[]>([]);
  attachmentsRef.current = attachments;

  const spec = history.present;
  const configured = isConfigured(settings);
  const selectedScene = spec.scenes.find((scene) => scene.id === selectedId) ?? spec.scenes[0] ?? null;

  const specRef = useRef(spec);
  specRef.current = spec;

  const nextId = (): string => `e_${Date.now().toString(36)}_${counter.current++}`;

  useEffect(() => {
    const timeout = setTimeout(() => {
      try {
        localStorage.setItem(SPEC_KEY, JSON.stringify(spec));
      } catch {
        /* storage full or blocked — the session still works */
      }
    }, 400);
    return () => clearTimeout(timeout);
  }, [spec]);

  useEffect(() => {
    try {
      localStorage.setItem(LOG_KEY, JSON.stringify(entries.slice(-60)));
    } catch {
      /* ignore */
    }
  }, [entries]);

  useEffect(() => {
    if (!toast) return;
    const timeout = setTimeout(() => setToast(null), 3200);
    return () => clearTimeout(timeout);
  }, [toast]);

  useEffect(
    () => () => {
      stopWatchRef.current?.();
      renderWatchRef.current?.();
      for (const attachment of attachmentsRef.current) {
        if (attachment.videoSrc) URL.revokeObjectURL(attachment.videoSrc);
        if (attachment.audioSrc) URL.revokeObjectURL(attachment.audioSrc);
      }
    },
    [],
  );

  const edit = useCallback((updater: (current: VideoSpec) => VideoSpec) => {
    setHistory((current) => ({
      past: [...current.past, current.present].slice(-40),
      present: updater(current.present),
      future: [],
    }));
  }, []);

  const replacePresent = useCallback((updater: (current: VideoSpec) => VideoSpec) => {
    setHistory((current) => ({...current, present: updater(current.present)}));
  }, []);

  const undo = useCallback(() => {
    setHistory((current) => {
      if (!current.past.length) return current;
      return {
        past: current.past.slice(0, -1),
        present: current.past[current.past.length - 1],
        future: [current.present, ...current.future].slice(0, 40),
      };
    });
  }, []);

  const redo = useCallback(() => {
    setHistory((current) => {
      if (!current.future.length) return current;
      return {
        past: [...current.past, current.present].slice(-40),
        present: current.future[0],
        future: current.future.slice(1),
      };
    });
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const meta = event.metaKey || event.ctrlKey;
      if (meta && event.key.toLowerCase() === 'z') {
        event.preventDefault();
        if (event.shiftKey) redo();
        else undo();
      }
      if (meta && event.key === ',') {
        event.preventDefault();
        setSettingsOpen(true);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [undo, redo]);

  const selectScene = useCallback(
    (sceneId: string) => {
      setSelectedId(sceneId);
      playerRef.current?.seekTo(sceneStartFrame(spec, sceneId));
    },
    [spec],
  );

  const patchScene = (sceneId: string, patch: Partial<Scene>) => {
    edit((current) => ({
      ...current,
      scenes: current.scenes.map((scene) => (scene.id === sceneId ? {...scene, ...patch} : scene)),
    }));
  };

  const deleteScene = (sceneId: string) => {
    const index = spec.scenes.findIndex((scene) => scene.id === sceneId);
    if (index < 0 || spec.scenes.length <= 1) return;
    const neighbour = spec.scenes[index + 1] ?? spec.scenes[index - 1];
    edit((current) => ({...current, scenes: current.scenes.filter((scene) => scene.id !== sceneId)}));
    if (selectedScene?.id === sceneId) setSelectedId(neighbour?.id ?? null);
  };

  const moveScene = (sceneId: string, direction: -1 | 1) => {
    const index = spec.scenes.findIndex((scene) => scene.id === sceneId);
    const target = index + direction;
    if (index < 0 || target < 0 || target >= spec.scenes.length) return;
    edit((current) => {
      const scenes = [...current.scenes];
      const [moved] = scenes.splice(index, 1);
      scenes.splice(target, 0, moved);
      return {...current, scenes};
    });
  };

  const addScene = () => {
    const scene = makeScene(spec, {
      kind: 'title',
      headline: 'New scene',
      kicker: '',
      durationSeconds: 3,
      animation: 'fade-up',
      align: 'left',
    });
    const start = totalFrames(spec);
    edit((current) => ({...current, scenes: [...current.scenes, scene]}));
    setSelectedId(scene.id);
    setTimeout(() => playerRef.current?.seekTo(start), 0);
  };

  const patchTheme = (patch: Partial<VideoTheme>) => {
    edit((current) => ({...current, theme: {...current.theme, ...patch}}));
  };

  const changeAspect = (aspect: AspectRatio) => {
    edit((current) => setAspect(current, aspect));
  };

  const changeTitle = (title: string) => {
    replacePresent((current) => ({...current, meta: {...current.meta, title}}));
  };

  const finishJob = useCallback((snapshot: JobSnapshot) => {
    if (finishedRef.current === snapshot.id) return;
    finishedRef.current = snapshot.id;
    const session = jobRef.current;

    stopWatchRef.current?.();
    stopWatchRef.current = null;
    jobRef.current = null;
    saveStoredJob(null);
    setBusy(false);
    setJobId(null);
    setStatus('Thinking…');

    if (session && snapshot.changed) {
      setHistory((current) => ({
        past: [...current.past, session.before].slice(-40),
        present: snapshot.spec,
        future: [],
      }));
      playerRef.current?.seekTo(0);
      playerRef.current?.play();
    }

    if (snapshot.status === 'done') {
      setRetryableEdit(null);
      setEntries((current) => [...current, {id: nextId(), role: 'assistant', text: snapshot.reply || 'Done.'}]);
    } else if (snapshot.status === 'cancelled') {
      setRetryableEdit(null);
      setEntries((current) => [
        ...current,
        {id: nextId(), role: 'assistant', text: snapshot.error || 'Stopped. Partial edits are kept — ⌘Z undoes them.'},
      ]);
    } else {
      setEntries((current) => [
        ...current,
        {id: nextId(), role: 'error', text: snapshot.error || 'The edit failed. Your current timeline is preserved.', settingsAction: true, retryAction: true},
      ]);
    }
  }, []);

  const applySnapshot = useCallback(
    (snapshot: JobSnapshot) => {
      const session = jobRef.current;
      if (!session || session.id !== snapshot.id) return;

      if (snapshot.status === 'queued') {
        setStatus(snapshot.queuedAhead > 0 ? `Queued · ${snapshot.queuedAhead} ahead` : 'Queued…');
      } else if (snapshot.status === 'running') {
        setStatus(snapshot.rounds > 1 ? `Editing · round ${snapshot.rounds}` : 'Thinking…');
      }

      setUsage(snapshot.usage);

      if (snapshot.steps.length > session.seen) {
        const fresh = snapshot.steps.slice(session.seen);
        session.seen = snapshot.steps.length;
        saveStoredJob({id: session.id, seen: session.seen});
        setEntries((current) => [
          ...current,
          ...fresh.map((step) => ({id: step.id, role: 'tool' as const, name: step.name, label: step.label, ok: step.ok})),
        ]);
      }

      if (snapshot.status !== 'queued') {
        setHistory((current) => ({...current, present: snapshot.spec}));
      }

      if (isTerminalStatus(snapshot.status)) finishJob(snapshot);
    },
    [finishJob],
  );

  const startJobWatch = useCallback(
    (id: string, before: VideoSpec, seen: number) => {
      stopWatchRef.current?.();
      jobRef.current = {id, before, seen};
      finishedRef.current = null;
      saveStoredJob({id, seen});
      setJobId(id);
      setBusy(true);
      setStatus('Starting…');
      stopWatchRef.current = watchJob(id, applySnapshot, (message) => {
        stopWatchRef.current = null;
        jobRef.current = null;
        saveStoredJob(null);
        setBusy(false);
        setJobId(null);
        setStatus('Thinking…');
        setEntries((current) => [...current, {id: nextId(), role: 'error', text: `${message} The current timeline is preserved.`, settingsAction: true, retryAction: true}]);
      });
    },
    [applySnapshot],
  );

  // Resume an edit that was still running (or just finished) before a reload.
  useEffect(() => {
    const stored = loadStoredJob();
    if (!stored) return;
    let cancelled = false;
    void (async () => {
      const snapshot = await fetchJob(stored.id);
      if (cancelled) return;
      if (!snapshot) {
        saveStoredJob(null);
        return;
      }
      startJobWatch(stored.id, specRef.current, Math.min(stored.seen, snapshot.steps.length));
      if (isTerminalStatus(snapshot.status)) applySnapshot(snapshot);
    })();
    return () => {
      cancelled = true;
    };
  }, [applySnapshot, startJobWatch]);

  const applyRenderSnapshot = useCallback((snapshot: RenderSnapshot) => {
    setRender(snapshot);
    setRenderBusy(['uploading', 'queued', 'rendering'].includes(snapshot.status));
    if (snapshot.status === 'error') setToast(snapshot.error || 'The video render failed.');
    if (snapshot.status === 'done') setToast('Video render complete — download your MP4.');
  }, []);

  const startRenderWatch = useCallback((id: string) => {
    renderWatchRef.current?.();
    renderWatchRef.current = watchRender(id, applyRenderSnapshot, (message) => {
      renderWatchRef.current = null;
      setRenderBusy(false);
      setToast(message);
    });
  }, [applyRenderSnapshot]);

  useEffect(() => {
    const stored = localStorage.getItem('cutline.render.v1');
    if (!stored) return;
    let cancelled = false;
    void (async () => {
      const snapshot = await fetchRender(stored);
      if (cancelled || !snapshot) return;
      applyRenderSnapshot(snapshot);
      if (['uploading', 'queued', 'rendering'].includes(snapshot.status)) startRenderWatch(snapshot.id);
    })();
    return () => { cancelled = true; };
  }, [applyRenderSnapshot, startRenderWatch]);

  const renderVideo = useCallback(async () => {
    if (renderBusy || busy || uploading) return;
    if (totalSeconds(specRef.current) > 120) {
      setToast('Server rendering is limited to videos up to two minutes.');
      return;
    }
    setRenderBusy(true);
    setRender({id: '', status: 'uploading', createdAt: Date.now(), updatedAt: Date.now(), progress: 0, stage: 'Preparing render…', uploadedBytes: 0, totalBytes: 0});
    try {
      const snapshot = await createRender(specRef.current, renderAttachmentsRef.current, applyRenderSnapshot);
      localStorage.setItem('cutline.render.v1', snapshot.id);
      applyRenderSnapshot(snapshot);
      startRenderWatch(snapshot.id);
    } catch (error) {
      setRenderBusy(false);
      setRender(null);
      localStorage.removeItem('cutline.render.v1');
      setToast(error instanceof Error ? error.message : 'Could not start rendering.');
    }
  }, [applyRenderSnapshot, busy, renderBusy, startRenderWatch, uploading]);

  const stopRender = useCallback(() => {
    if (!render?.id) return;
    renderWatchRef.current?.();
    renderWatchRef.current = null;
    void cancelRender(render.id);
    setRenderBusy(false);
    setRender({...render, status: 'cancelled', stage: 'Render cancelled'});
  }, [render]);

  const send = useCallback(
    async (rawPrompt: string) => {
      const prompt = rawPrompt.trim();
      if ((!prompt && attachments.length === 0) || busy || uploading) return;
      if (!isConfigured(settings)) {
        setSettingsOpen(true);
        setToast('Add your API URL and model first');
        return;
      }

      const before = specRef.current;
      const turns = entries
        .filter((entry): entry is Extract<ChatEntry, {role: 'user' | 'assistant'}> => entry.role === 'user' || entry.role === 'assistant')
        .map((entry) => ({role: entry.role, text: entry.text}))
        .slice(-10);

      const jobAttachments = attachments;
      const actualPrompt = prompt || 'Use the attached media to create a short video.';
      const retry = {prompt: actualPrompt, settings, history: turns, attachments: jobAttachments};
      setRetryableEdit(retry);
      setEntries((current) => [...current, {id: nextId(), role: 'user', text: actualPrompt}]);
      setBusy(true);
      setStatus('Starting…');
      setUsage({inputTokens: 0, outputTokens: 0, totalTokens: 0, reported: false, requests: 0});

      try {
        const {id} = await createJob({settings, spec: before, prompt: actualPrompt, history: turns, attachments: jobAttachments});
        startJobWatch(id, before, 0);
      } catch (error) {
        setBusy(false);
        setStatus('Thinking…');
        setEntries((current) => [
          ...current,
          {id: nextId(), role: 'error', text: error instanceof Error ? error.message : 'Could not start the edit.', settingsAction: true, retryAction: true},
        ]);
      }
    },
    [attachments, busy, entries, settings, startJobWatch, uploading],
  );

  const createVideo = useCallback(async (prompt: string) => {
    if (busy || uploading) return;
    if (!isConfigured(settings) || !settings.apiKey.trim()) {
      setSettingsOpen(true);
      setToast('Add your provider token in Settings to direct the edit.');
      return;
    }
    const jobAttachments = attachments;
    setBusy(true);
    setStatus('Planning your edit…');
    setUsage({inputTokens: 0, outputTokens: 0, totalTokens: 0, reported: false, requests: 0});
    setEntries((current) => [...current, {id: nextId(), role: 'user', text: prompt}]);
    try {
      const result = await createPromptStoryboard(settings, prompt, jobAttachments);
      setUsage(result.usage);
      edit(() => result.spec);
      setEntries((current) => [...current, {id: nextId(), role: 'assistant', text: result.reply}]);
      setToast('AI cut ready — review the preview and render when you’re happy.');
      setAttachments([]);
      setStatus('Thinking…');
    } catch (error) {
      setEntries((current) => [...current, {id: nextId(), role: 'error', text: error instanceof Error ? error.message : 'Could not create the video.'}]);
    } finally {
      setBusy(false);
    }
  }, [attachments, busy, settings, uploading, edit]);

  const retryEdit = useCallback(() => {
    if (!retryableEdit || busy || uploading) return;
    setEntries((current) => [...current, {id: nextId(), role: 'user', text: `Retry: ${retryableEdit.prompt}`}]);
    setBusy(true);
    setStatus('Retrying…');
    setUsage({inputTokens: 0, outputTokens: 0, totalTokens: 0, reported: false, requests: 0});
    void createJob({
      settings,
      spec: specRef.current,
      prompt: retryableEdit.prompt,
      history: retryableEdit.history,
      attachments: retryableEdit.attachments,
    }).then(({id}) => startJobWatch(id, specRef.current, 0)).catch((error: unknown) => {
      setBusy(false);
      setStatus('Thinking…');
      setEntries((current) => [...current, {
        id: nextId(),
        role: 'error',
        text: error instanceof Error ? error.message : 'Could not retry the edit. Your current timeline is preserved.',
        settingsAction: true,
        retryAction: true,
      }]);
    });
  }, [busy, retryableEdit, settings, startJobWatch, uploading]);

  const stop = useCallback(() => {
    const id = jobRef.current?.id ?? jobId;
    if (!id) return;
    setStatus('Stopping…');
    void cancelJob(id);
  }, [jobId]);

  return (
    <div className="app">
      <TopBar
        title={spec.meta.title}
        onTitleChange={changeTitle}
        sceneCount={spec.scenes.length}
        seconds={totalSeconds(spec)}
        canUndo={history.past.length > 0}
        canRedo={history.future.length > 0}
        onUndo={undo}
        onRedo={redo}
        model={settings.model}
        endpointHost={describeEndpoint(settings)}
        configured={configured}
        locked={busy}
        onOpenSettings={() => setSettingsOpen(true)}
        onExport={() => setExportOpen(true)}
        onRender={renderVideo}
        rendering={renderBusy}
      />

      <div className="workspace">
        <ChatPanel
          entries={entries}
          busy={busy || uploading}
          status={uploading ? 'Preparing attachments…' : status}
          attachments={attachments}
          usage={usage}
          onAddFiles={async (files) => {
            setUploading(true);
            try {
              const prepared = await prepareMediaFiles(files, attachments.length);
              setAttachments((current) => [...current, ...prepared]);
            } catch (error) {
              setEntries((current) => [...current, {id: nextId(), role: 'error', text: error instanceof Error ? error.message : 'Could not read that media file.'}]);
            } finally {
              setUploading(false);
            }
          }}
          onRemoveAttachment={(id) => setAttachments((current) => {
            const removed = current.find((item) => item.id === id);
            if (removed?.videoSrc) URL.revokeObjectURL(removed.videoSrc);
            if (removed?.audioSrc) URL.revokeObjectURL(removed.audioSrc);
            return current.filter((item) => item.id !== id);
          })}
          onDropFiles={(files) => void (async () => {
            setUploading(true);
            try {
              const prepared = await prepareMediaFiles(files, attachments.length);
              setAttachments((current) => [...current, ...prepared]);
            } catch (error) {
              setEntries((current) => [...current, {id: nextId(), role: 'error', text: error instanceof Error ? error.message : 'Could not read that media file.'}]);
            } finally {
              setUploading(false);
            }
          })()}
          model={settings.model}
          configured={configured}
          onSend={send}
          onCreateVideo={createVideo}
          onRetry={retryEdit}
          onStop={stop}
          onOpenSettings={() => setSettingsOpen(true)}
        />
        <PreviewStage
          spec={spec}
          playerRef={playerRef}
          selectedSceneId={selectedScene?.id ?? null}
          attachments={attachments}
          locked={busy}
          onSelectScene={selectScene}
          onSetAspect={changeAspect}
        />
        <SceneRail
          spec={spec}
          attachments={attachments}
          selectedSceneId={selectedScene?.id ?? null}
          locked={busy}
          onSelect={selectScene}
          onPatchScene={patchScene}
          onDeleteScene={deleteScene}
          onMoveScene={moveScene}
          onAddScene={addScene}
          onPatchTheme={patchTheme}
        />
      </div>        <SettingsDialog
          open={settingsOpen}
        settings={settings}
        onClose={() => setSettingsOpen(false)}
        onSave={(next) => {
          setSettings(next);
          saveSettings(next);
          setToast('Model saved to this browser');
        }}
      />
      <ExportDialog open={exportOpen} spec={spec} attachments={attachments} onClose={() => setExportOpen(false)} onNotify={setToast} />
      {render ? (
        <div className="render-status" role="status" aria-live="polite">
          <div className="render-status-head">
            <strong>{render.status === 'done' ? 'Video ready' : render.stage}</strong>
            {renderBusy ? <button className="icon-btn" aria-label="Cancel render" onClick={stopRender}>×</button> : null}
          </div>
          {render.status === 'uploading' && render.totalBytes > 0 ? (
            <progress max={render.totalBytes} value={render.uploadedBytes} />
          ) : render.status === 'rendering' || render.status === 'queued' ? (
            <progress max={100} value={Math.round(render.progress * 100)} />
          ) : null}
          <div className="render-status-foot">
            <span>{render.status === 'uploading' && render.totalBytes ? `${Math.floor(render.uploadedBytes / 1_048_576)} / ${Math.ceil(render.totalBytes / 1_048_576)} MiB` : render.status === 'rendering' ? `${Math.round(render.progress * 100)}%` : render.stage}</span>
            {render.status === 'done' ? <button className="btn btn-primary" onClick={() => downloadRender(render.id, `${spec.meta.title.replace(/[^a-z0-9]+/gi, '-').toLowerCase() || 'cutline-video'}.mp4`)}>Download MP4</button> : null}
            {['error', 'cancelled'].includes(render.status) ? <button className="btn btn-ghost" onClick={() => setRender(null)}>Dismiss</button> : null}
          </div>
        </div>
      ) : null}


      {toast ? <div className="toast">{toast}</div> : null}
    </div>
  );
}
