import {
  AbsoluteFill,
  Audio,
  Img,
  OffthreadVideo,
  Series,
  staticFile,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import type {ReactNode} from 'react';
import type {MediaAttachment, Scene, SceneAnimation, VideoSpec, VideoTheme} from '../types';

const SANS = "'Inter', 'Helvetica Neue', Arial, sans-serif";
const SERIF = "'Instrument Serif', 'Iowan Old Style', Georgia, serif";
const MONO = "'JetBrains Mono', ui-monospace, SFMono-Regular, monospace";

const FONT_IMPORT = `@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family=Instrument+Serif:ital@0;1&family=JetBrains+Mono:wght@400;500&display=swap');`;

const GRAIN = `url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='140' height='140'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='3' stitchTiles='stitch'/></filter><rect width='140' height='140' filter='url(%23n)' opacity='0.5'/></svg>")`;

type Motion = {opacity: number; transform?: string; filter?: string};

const useUnit = (): number => {
  const {width, height} = useVideoConfig();
  return Math.min(width, height) / 100;
};

const useEnter = (animation: SceneAnimation | undefined, delay = 0, distance = 3): Motion => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const u = useUnit();
  const progress = spring({
    frame: Math.max(0, frame - delay),
    fps,
    config: {damping: 200, stiffness: 120, mass: 0.6},
    durationInFrames: 20,
  });

  if (animation === 'none') return {opacity: 1, transform: 'none'};
  if (frame < delay) return {opacity: 0, transform: 'none'};

  switch (animation) {
    case 'slide':
      return {opacity: Math.min(1, progress * 1.3), transform: `translateX(${(1 - progress) * -distance * 4 * u}px)`};
    case 'scale':
      return {opacity: Math.min(1, progress), transform: `scale(${0.9 + 0.1 * progress})`};
    case 'blur':
      return {opacity: Math.min(1, progress * 1.2), transform: 'none', filter: `blur(${(1 - progress) * 10}px)`};
    case 'typewriter':
      return {opacity: 1, transform: 'none'};
    default:
      return {opacity: Math.min(1, progress * 1.25), transform: `translateY(${(1 - progress) * distance * u}px)`};
  }
};

const pad2 = (value: number): string => String(value).padStart(2, '0');

/** Supporting typeface chosen in the theme; headlines always stay serif. */
const bodyFont = (theme: VideoTheme): string =>
  theme.font === 'serif' ? SERIF : theme.font === 'mono' ? MONO : SANS;

const Kicker: React.FC<{text?: string; theme: VideoTheme; size: number; motion?: Motion}> = ({
  text,
  theme,
  size,
  motion,
}) => {
  if (!text) return null;
  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        gap: size * 1.1,
        fontFamily: MONO,
        fontSize: size,
        letterSpacing: '0.26em',
        textTransform: 'uppercase',
        color: theme.muted,
        ...(motion ?? {}),
      }}
    >
      <span style={{display: 'block', width: size * 2.6, height: Math.max(2, size * 0.14), background: theme.accent}} />
      {text}
    </div>
  );
};

const SceneFrame: React.FC<{
  scene: Scene;
  theme: VideoTheme;
  index: number;
  count: number;
  offset: number;
  total: number;
  children: ReactNode;
}> = ({scene, theme, index, count, offset, total, children}) => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const u = Math.min(width, height) / 100;
  const pad = Math.round(Math.min(width, height) * 0.078);
  const accent = scene.accent ?? theme.accent;
  const background = scene.background ?? theme.background;
  const exit = interpolate(frame, [scene.durationInFrames - 7, scene.durationInFrames], [1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const progress = interpolate(offset + frame, [0, Math.max(1, total)], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <AbsoluteFill style={{background, color: scene.textColor ?? theme.text, opacity: exit, overflow: 'hidden'}}>
      <AbsoluteFill
        style={{
          background: `radial-gradient(120% 95% at 84% 0%, color-mix(in srgb, ${accent} 18%, transparent), transparent 62%)`,
        }}
      />
      <AbsoluteFill style={{backgroundImage: GRAIN, opacity: 0.05, mixBlendMode: 'overlay'}} />
      {children}
      <div
        style={{
          position: 'absolute',
          top: pad * 0.46,
          right: pad * 0.62,
          fontFamily: MONO,
          fontSize: u * 1.15,
          letterSpacing: '0.24em',
          color: theme.muted,
          opacity: 0.9,
        }}
      >
        {pad2(index + 1)} / {pad2(count)}
      </div>
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          bottom: 0,
          height: Math.max(2, u * 0.3),
          background: `color-mix(in srgb, ${theme.muted} 22%, transparent)`,
        }}
      >
        <div style={{width: `${progress * 100}%`, height: '100%', background: accent}} />
      </div>
    </AbsoluteFill>
  );
};

const TitleScene: React.FC<{scene: Scene; theme: VideoTheme; u: number; pad: number}> = ({scene, theme, u, pad}) => {
  const align = scene.align ?? 'left';
  const centered = align === 'center';
  const kicker = useEnter(scene.animation, 0, 1.2);
  const head = useEnter(scene.animation, 4, 3.4);
  const sub = useEnter(scene.animation, 14, 2);

  return (
    <div
      style={{
        height: '100%',
        padding: pad,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: centered ? 'center' : 'flex-start',
        gap: u * 2.8,
        textAlign: align,
      }}
    >
      <Kicker text={scene.kicker} theme={theme} size={u * 1.35} motion={kicker} />
      <h1
        style={{
          ...head,
          fontFamily: SERIF,
          fontWeight: 400,
          fontSize: u * 8,
          lineHeight: 1.02,
          letterSpacing: '-0.025em',
          margin: 0,
          color: theme.text,
          maxWidth: centered ? '92%' : '84%',
        }}
      >
        {scene.headline ?? ''}
      </h1>
      {scene.subhead ? (
        <p
          style={{
            ...sub,
            fontFamily: bodyFont(theme),
            fontSize: u * 2.25,
            lineHeight: 1.5,
            color: theme.muted,
            margin: 0,
            maxWidth: centered ? '62%' : '52%',
          }}
        >
          {scene.subhead}
        </p>
      ) : null}
    </div>
  );
};

const BulletRow: React.FC<{
  item: string;
  index: number;
  theme: VideoTheme;
  u: number;
  animation?: SceneAnimation;
}> = ({item, index, theme, u, animation}) => {
  const motion = useEnter(animation === 'typewriter' ? 'fade-up' : animation, 10 + index * 5, 1.4);
  return (
    <div
      style={{
        ...motion,
        display: 'flex',
        alignItems: 'baseline',
        gap: u * 1.8,
        paddingTop: u * 1.7,
        paddingBottom: u * 1.7,
        borderTop: `1px solid color-mix(in srgb, ${theme.muted} 26%, transparent)`,
      }}
    >
      <span style={{fontFamily: MONO, fontSize: u * 1.3, letterSpacing: '0.12em', color: theme.accent}}>
        {pad2(index + 1)}
      </span>
      <span style={{fontFamily: bodyFont(theme), fontSize: u * 2.25, lineHeight: 1.35, color: theme.text}}>{item}</span>
    </div>
  );
};

const BulletsScene: React.FC<{scene: Scene; theme: VideoTheme; u: number; pad: number}> = ({scene, theme, u, pad}) => {
  const align = scene.align ?? 'left';
  const kicker = useEnter(scene.animation, 0, 1.2);
  const head = useEnter(scene.animation, 4, 2.4);
  const items = scene.items ?? [];

  return (
    <div
      style={{
        height: '100%',
        padding: pad,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        gap: u * 2.4,
        textAlign: align,
        alignItems: align === 'center' ? 'center' : 'stretch',
      }}
    >
      <Kicker text={scene.kicker} theme={theme} size={u * 1.3} motion={kicker} />
      <h2
        style={{
          ...head,
          fontFamily: SERIF,
          fontWeight: 400,
          fontSize: u * 5.2,
          lineHeight: 1.05,
          letterSpacing: '-0.02em',
          margin: 0,
          color: theme.text,
        }}
      >
        {scene.headline ?? ''}
      </h2>
      {scene.subhead ? (
        <p style={{fontFamily: bodyFont(theme), fontSize: u * 1.9, lineHeight: 1.5, color: theme.muted, margin: 0}}>
          {scene.subhead}
        </p>
      ) : null}
      <div style={{marginTop: u * 1.2, maxWidth: '88%'}}>
        {items.map((item, index) => (
          <BulletRow key={`${index}-${item}`} item={item} index={index} theme={theme} u={u} animation={scene.animation} />
        ))}
      </div>
    </div>
  );
};

const QuoteScene: React.FC<{scene: Scene; theme: VideoTheme; u: number; pad: number}> = ({scene, theme, u, pad}) => {
  const mark = useEnter(scene.animation, 0, 1);
  const quote = useEnter(scene.animation === 'typewriter' ? 'fade-up' : scene.animation, 4, 2.4);
  const author = useEnter(scene.animation, 16, 1.2);

  return (
    <div
      style={{
        height: '100%',
        padding: pad * 1.1,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        gap: u * 2.6,
        textAlign: 'center',
      }}
    >
      <div style={{...mark, fontFamily: SERIF, fontSize: u * 6, lineHeight: 0.7, color: theme.accent}}>&ldquo;</div>
      <blockquote
        style={{
          ...quote,
          fontFamily: SERIF,
          fontStyle: 'italic',
          fontSize: u * 6.4,
          lineHeight: 1.1,
          letterSpacing: '-0.015em',
          margin: 0,
          maxWidth: '82%',
          color: theme.text,
        }}
      >
        {scene.quote ?? scene.headline ?? ''}
      </blockquote>
      {scene.author ? (
        <div
          style={{
            ...author,
            fontFamily: MONO,
            fontSize: u * 1.3,
            letterSpacing: '0.24em',
            textTransform: 'uppercase',
            color: theme.muted,
          }}
        >
          {scene.author}
        </div>
      ) : null}
    </div>
  );
};

const StatCell: React.FC<{
  value: string;
  label: string;
  index: number;
  theme: VideoTheme;
  u: number;
  animation?: SceneAnimation;
}> = ({value, label, index, theme, u, animation}) => {
  const motion = useEnter(animation === 'typewriter' ? 'fade-up' : animation, 10 + index * 6, 2);
  return (
    <div style={{...motion, flex: 1, minWidth: '18%', display: 'flex', flexDirection: 'column', gap: u * 0.9}}>
      <div style={{height: Math.max(2, u * 0.2), width: '34%', background: theme.accent, opacity: 0.9}} />
      <div
        style={{
          fontFamily: SERIF,
          fontSize: u * 8.6,
          lineHeight: 1,
          letterSpacing: '-0.03em',
          color: theme.text,
        }}
      >
        {value}
      </div>
      <div
        style={{
          fontFamily: MONO,
          fontSize: u * 1.2,
          letterSpacing: '0.18em',
          textTransform: 'uppercase',
          color: theme.muted,
          lineHeight: 1.5,
        }}
      >
        {label}
      </div>
    </div>
  );
};

const StatsScene: React.FC<{scene: Scene; theme: VideoTheme; u: number; pad: number}> = ({scene, theme, u, pad}) => {
  const kicker = useEnter(scene.animation, 0, 1.2);
  const head = useEnter(scene.animation, 4, 2);
  const stats = scene.stats ?? [];

  return (
    <div
      style={{
        height: '100%',
        padding: pad,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        gap: u * 2.2,
      }}
    >
      <Kicker text={scene.kicker} theme={theme} size={u * 1.3} motion={kicker} />
      {scene.headline ? (
        <h2
          style={{
            ...head,
            fontFamily: SERIF,
            fontWeight: 400,
            fontSize: u * 4.4,
            lineHeight: 1.08,
            margin: 0,
            color: theme.text,
            maxWidth: '76%',
          }}
        >
          {scene.headline}
        </h2>
      ) : null}
      <div style={{display: 'flex', gap: u * 3, marginTop: u * 2, flexWrap: 'wrap'}}>
        {stats.map((stat, index) => (
          <StatCell
            key={`${index}-${stat.label}`}
            value={stat.value}
            label={stat.label}
            index={index}
            theme={theme}
            u={u}
            animation={scene.animation}
          />
        ))}
      </div>
    </div>
  );
};

const ImageScene: React.FC<{scene: Scene; theme: VideoTheme; u: number; pad: number; attachments: MediaAttachment[]}> = ({scene, theme, u, pad, attachments}) => {
  const frame = useCurrentFrame();
  const zoom = interpolate(frame, [0, Math.max(1, scene.durationInFrames)], [1.07, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const kicker = useEnter(scene.animation, 4, 1.4);
  const head = useEnter(scene.animation, 8, 2.6);
  const attachment = attachments.find((item) => item.id === scene.mediaAttachmentId);
  const frameIndex = Math.max(0, Math.min((attachment?.frames.length ?? 1) - 1, scene.mediaFrameIndex ?? 0));
  const still = attachment?.frames[frameIndex]?.dataUrl;
  const sourcePath = attachment?.renderSrc;
  const durationSeconds = scene.durationInFrames / useVideoConfig().fps;
  const videoTrimBefore = Math.round((scene.sourceStartSeconds ?? 0) * useVideoConfig().fps);
  const videoTrimAfter = Math.round((scene.sourceEndSeconds ?? (scene.sourceStartSeconds ?? 0) + durationSeconds) * useVideoConfig().fps);
  const videoSource = attachment?.kind === 'video' && (sourcePath || attachment.videoSrc)
    ? sourcePath
      ? staticFile(sourcePath.replace(/^\/+/, ''))
      : attachment.videoSrc!.startsWith('blob:')
        ? attachment.videoSrc
        : staticFile(attachment.videoSrc!.replace(/^\/+/, ''))
    : scene.imageUrl?.startsWith('blob:')
      ? scene.imageUrl
      : undefined;
  const renderStill = attachment?.kind === 'image' && sourcePath ? staticFile(sourcePath.replace(/^\/+/, '')) : undefined;
  const rawImageSource = scene.imageUrl ?? renderStill ?? still;
  const imageSource = videoSource
    ? undefined
    : rawImageSource?.startsWith('media/') || rawImageSource?.startsWith('/media/')
      ? staticFile(rawImageSource.replace(/^\/+/, ''))
      : rawImageSource;

  return (
    <AbsoluteFill>
      {videoSource ? (
        <OffthreadVideo
          src={videoSource}
          muted={!scene.keepSourceAudio}
          trimBefore={videoTrimBefore}
          trimAfter={videoTrimAfter}
          style={{width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${zoom})`}}
          onError={() => undefined}
        />
      ) : imageSource ? (
        <Img
          src={imageSource}
          style={{width: '100%', height: '100%', objectFit: 'cover', transform: `scale(${zoom})`}}
        />
      ) : (
        <AbsoluteFill
          style={{
            background: `linear-gradient(135deg, color-mix(in srgb, ${theme.accent} 42%, ${theme.background}), ${theme.background} 72%)`,
          }}
        />
      )}
      <AbsoluteFill
        style={{
          background: `linear-gradient(to top, ${theme.background} 4%, color-mix(in srgb, ${theme.background} 62%, transparent) 44%, transparent 84%)`,
        }}
      />
      <div
        style={{
          position: 'absolute',
          left: pad,
          right: pad,
          bottom: pad * 1.3,
          display: 'flex',
          flexDirection: 'column',
          gap: u * 1.7,
        }}
      >
        <Kicker text={scene.kicker} theme={theme} size={u * 1.25} motion={kicker} />
        {scene.headline ? (
          <h2
            style={{
              ...head,
              fontFamily: SERIF,
              fontWeight: 400,
              fontSize: u * 4.8,
              lineHeight: 1.05,
              margin: 0,
              maxWidth: '74%',
              color: theme.text,
            }}
          >
            {scene.headline}
          </h2>
        ) : null}
        {scene.subhead ? (
          <p style={{fontFamily: bodyFont(theme), fontSize: u * 1.9, color: theme.muted, margin: 0, maxWidth: '62%'}}>
            {scene.subhead}
          </p>
        ) : null}
      </div>
    </AbsoluteFill>
  );
};

const OutroScene: React.FC<{scene: Scene; theme: VideoTheme; u: number; pad: number}> = ({scene, theme, u, pad}) => {
  const kicker = useEnter(scene.animation, 0, 1.2);
  const head = useEnter(scene.animation, 4, 3);
  const sub = useEnter(scene.animation, 12, 1.8);
  const cta = useEnter(scene.animation, 20, 1.4);

  return (
    <div
      style={{
        height: '100%',
        padding: pad,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: 'center',
        gap: u * 2.4,
      }}
    >
      <Kicker text={scene.kicker} theme={theme} size={u * 1.3} motion={kicker} />
      <h2
        style={{
          ...head,
          fontFamily: SERIF,
          fontWeight: 400,
          fontSize: u * 6.8,
          lineHeight: 1.03,
          letterSpacing: '-0.025em',
          margin: 0,
          maxWidth: '86%',
          color: theme.text,
        }}
      >
        {scene.headline ?? ''}
      </h2>
      {scene.subhead ? (
        <p style={{...sub, fontFamily: bodyFont(theme), fontSize: u * 2.05, lineHeight: 1.5, color: theme.muted, margin: 0, maxWidth: '64%'}}>
          {scene.subhead}
        </p>
      ) : null}
      {scene.cta ? (
        <div
          style={{
            ...cta,
            marginTop: u * 1.6,
            padding: `${u * 1.6}px ${u * 3.4}px`,
            background: theme.accent,
            color: theme.background,
            fontFamily: MONO,
            fontSize: u * 1.35,
            letterSpacing: '0.18em',
            textTransform: 'uppercase',
            borderRadius: 999,
          }}
        >
          {scene.cta}
        </div>
      ) : null}
    </div>
  );
};

const SceneBody: React.FC<{scene: Scene; theme: VideoTheme; u: number; pad: number; attachments: MediaAttachment[]}> = ({scene, theme, u, pad, attachments}) => {
  switch (scene.kind) {
    case 'bullets':
      return <BulletsScene scene={scene} theme={theme} u={u} pad={pad} />;
    case 'quote':
      return <QuoteScene scene={scene} theme={theme} u={u} pad={pad} />;
    case 'stats':
      return <StatsScene scene={scene} theme={theme} u={u} pad={pad} />;
    case 'image':
      return <ImageScene scene={scene} theme={theme} u={u} pad={pad} attachments={attachments} />;
    case 'outro':
      return <OutroScene scene={scene} theme={theme} u={u} pad={pad} />;
    case 'title':
    default:
      return <TitleScene scene={scene} theme={theme} u={u} pad={pad} />;
  }
};

const SceneStage: React.FC<{
  spec: VideoSpec;
  scene: Scene;
  index: number;
  count: number;
  offset: number;
  total: number;
  attachments: MediaAttachment[];
}> = ({spec, scene, index, count, offset, total, attachments}) => {
  const {width, height} = useVideoConfig();
  const u = Math.min(width, height) / 100;
  const pad = Math.round(Math.min(width, height) * 0.078);
  const theme: VideoTheme = {
    ...spec.theme,
    text: scene.textColor ?? spec.theme.text,
    accent: scene.accent ?? spec.theme.accent,
  };

  return (
    <SceneFrame scene={scene} theme={theme} index={index} count={count} offset={offset} total={total}>
      <SceneBody scene={scene} theme={theme} u={u} pad={pad} attachments={attachments} />
    </SceneFrame>
  );
};

export const Video: React.FC<{spec: VideoSpec; attachments?: MediaAttachment[]}> = ({spec, attachments = []}) => {
  const total = Math.max(1, spec.scenes.reduce((sum, scene) => sum + scene.durationInFrames, 0));
  const audioId = spec.scenes.find((scene) => scene.audioAttachmentId)?.audioAttachmentId;
  const audioSource = attachments.find((item) => item.id === audioId)?.audioSrc;
  const renderAudioSource = audioSource ? (audioSource.startsWith('blob:') ? audioSource : staticFile(audioSource.replace(/^\/+/, ''))) : undefined;
  let cursor = 0;

  return (
    <AbsoluteFill style={{background: spec.theme.background, color: spec.theme.text, fontFamily: bodyFont(spec.theme)}}>
      <style>{FONT_IMPORT}</style>
      {renderAudioSource ? <Audio src={renderAudioSource} /> : null}
      <Series>
        {spec.scenes.map((scene, index) => {
          const offset = cursor;
          cursor += scene.durationInFrames;
          return (
            <Series.Sequence key={scene.id} durationInFrames={Math.max(1, scene.durationInFrames)}>
              <SceneStage
                spec={spec}
                scene={scene}
                index={index}
                count={spec.scenes.length}
                offset={offset}
                total={total}
                attachments={attachments}
              />
            </Series.Sequence>
          );
        })}
      </Series>
    </AbsoluteFill>
  );
};

export default Video;
