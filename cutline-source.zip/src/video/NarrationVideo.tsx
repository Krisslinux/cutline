import {Fragment} from 'react';
import {AbsoluteFill, Audio, Easing, Img, interpolate, useCurrentFrame} from 'remotion';
import {TransitionSeries, linearTiming, type TransitionPresentationComponentProps} from '@remotion/transitions';
import {fade} from '@remotion/transitions/fade';
import {loadFont} from '@remotion/fonts';
import fontUrl from '@fontsource/inter/files/inter-latin-400-normal.woff2?url';
import type {NarrationTimeline, Shot} from '../../shared/narration';

loadFont({family: 'Cutline Narration', url: fontUrl, weight: '400'});
export interface NarrationProps extends Record<string, unknown> {timeline: NarrationTimeline; assets: Record<string, string>}

type MaskProps = {kind: 'diagonal' | 'radial'};
const Mask = ({children, presentationProgress: p, presentationDirection, passedProps}: TransitionPresentationComponentProps<MaskProps>) => {
  if (presentationDirection === 'exiting') return <AbsoluteFill>{children}</AbsoluteFill>;
  const mask = passedProps.kind === 'radial'
    ? `radial-gradient(circle at 50% 50%, black ${p * 170 - 12}%, transparent ${p * 170}%)`
    : `linear-gradient(135deg, black ${p * 125 - 14}%, transparent ${p * 125}%)`;
  return <AbsoluteFill style={{maskImage: p >= 1 ? undefined : mask, WebkitMaskImage: p >= 1 ? undefined : mask}}>{children}</AbsoluteFill>;
};
const ShotImage = ({shot, src}: {shot: Shot; src: string}) => {
  const frame = useCurrentFrame();
  const progress = interpolate(frame, [0, shot.endFrame - shot.startFrame - 1], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.quad)});
  return <AbsoluteFill style={{background: '#08090c', overflow: 'hidden'}}>
    <Img src={src} style={{width: '100%', height: '100%', objectFit: shot.fit, objectPosition: `${shot.focalPoint.x * 100}% ${shot.focalPoint.y * 100}%`,
      transform: `translate(${progress * shot.pan.x}px, ${progress * shot.pan.y}px) scale(${shot.startScale + progress * (shot.endScale - shot.startScale)})`, transformOrigin: `${shot.focalPoint.x * 100}% ${shot.focalPoint.y * 100}%`}} />
  </AbsoluteFill>;
};
export const NarrationVideo = ({timeline, assets}: NarrationProps) => {
  const frame = useCurrentFrame();
  const page = timeline.captionPages.find(c => frame >= c.startFrame && frame < c.endFrame);
  const fadeIn = Math.min(1, frame / 8);
  const fadeOut = Math.min(1, (timeline.durationInFrames - 1 - frame) / 8);
  return <AbsoluteFill style={{backgroundColor: '#08090c', fontFamily: 'Cutline Narration'}}>
    <AbsoluteFill style={{opacity: Math.min(fadeIn, fadeOut)}}>
      <TransitionSeries>
        {timeline.shots.map((shot, i) => <Fragment key={shot.id}>
          <TransitionSeries.Sequence durationInFrames={shot.endFrame - shot.startFrame}>
            <ShotImage shot={shot} src={assets[shot.imageAssetId]} />
          </TransitionSeries.Sequence>
          {i < timeline.shots.length - 1 && shot.transitionFrames > 0 && (shot.transitionOut === 'diagonal' || shot.transitionOut === 'radial'
            ? <TransitionSeries.Transition timing={linearTiming({durationInFrames: shot.transitionFrames})} presentation={{component: Mask, props: {kind: shot.transitionOut}}} />
            : <TransitionSeries.Transition timing={linearTiming({durationInFrames: shot.transitionFrames})} presentation={fade()} />)}
        </Fragment>)}
      </TransitionSeries>
    </AbsoluteFill>
    <Audio src={assets[timeline.audioAssetId]} />
    <AbsoluteFill style={{background: 'linear-gradient(transparent 55%, rgba(0,0,0,.28))', pointerEvents: 'none'}} />
    {page && <div style={{position: 'absolute', width: 580, left: 70, bottom: 156, color: '#fff', fontSize: 30, lineHeight: 1.35, fontWeight: 400,
      textAlign: 'center', textShadow: '0 2px 8px rgba(0,0,0,.95)', overflowWrap: 'anywhere', whiteSpace: 'normal'}}>{page.text}</div>}
  </AbsoluteFill>;
};
