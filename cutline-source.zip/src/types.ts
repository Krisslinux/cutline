/**
 * The video is a plain JSON document (a "spec"). The AI edits the spec through
 * tools, the Remotion composition renders it, and the exporter ships the same
 * spec + renderer as a real Remotion project. Keeping it serialisable is what
 * makes all three work.
 */

export type SceneKind = 'title' | 'bullets' | 'image' | 'quote' | 'stats' | 'outro';

export type SceneAnimation = 'fade-up' | 'slide' | 'scale' | 'blur' | 'typewriter' | 'none';

export type FontStyle = 'sans' | 'serif' | 'mono';

export type SceneAlign = 'left' | 'center';

export type AspectRatio = '16:9' | '9:16' | '1:1';

export const SCENE_KINDS: SceneKind[] = ['title', 'bullets', 'image', 'quote', 'stats', 'outro'];

export const SCENE_ANIMATIONS: SceneAnimation[] = ['fade-up', 'slide', 'scale', 'blur', 'typewriter', 'none'];

export const SCENE_ALIGNS: SceneAlign[] = ['left', 'center'];

export const FONT_STYLES: FontStyle[] = ['sans', 'serif', 'mono'];

export const ASPECT_PRESETS: Record<AspectRatio, {width: number; height: number}> = {
  '16:9': {width: 1920, height: 1080},
  '9:16': {width: 1080, height: 1920},
  '1:1': {width: 1080, height: 1080},
};

export interface Stat {
  value: string;
  label: string;
}

export interface MediaAttachment {
  id: string;
  name: string;
  kind: 'image' | 'video' | 'audio';
  mimeType: string;
  durationSeconds?: number;
  frames: {timeSeconds: number; dataUrl: string}[];
  /** Browser object URL, retained locally for rendering/export but never sent to the server. */
  videoSrc?: string;
  /** Local source blob for playback and server render upload; excluded from the spec and AI edit request. */
  videoBlob?: Blob;
  /** Local audio URL and original file for server-side mixing. */
  audioSrc?: string;
  audioBlob?: Blob;
  /** Local image source blob for server render upload; never serialized into the spec. */
  imageBlob?: Blob;
  /** Original audio bytes are included only when explicitly enabling audio-aware AI. */
  audioBytes?: number;
  /** Relative file path used when the server renders this media. */
  renderSrc?: string;
}

export interface Scene {
  id: string;
  kind: SceneKind;
  durationInFrames: number;
  kicker?: string;
  headline?: string;
  subhead?: string;
  items?: string[];
  stats?: Stat[];
  imageUrl?: string;
  /** Browser attachment id; renderer chooses a still/frame from the attachment. */
  mediaAttachmentId?: string;
  mediaFrameIndex?: number;
  audioAttachmentId?: string;
  sourceStartSeconds?: number;
  sourceEndSeconds?: number;
  keepSourceAudio?: boolean;
  quote?: string;
  author?: string;
  cta?: string;
  background?: string;
  textColor?: string;
  accent?: string;
  animation?: SceneAnimation;
  align?: SceneAlign;
}

export interface VideoTheme {
  background: string;
  text: string;
  accent: string;
  muted: string;
  font: FontStyle;
}

export interface VideoMeta {
  title: string;
  aspect: AspectRatio;
  fps: number;
  width: number;
  height: number;
}

export interface VideoSpec {
  version: 1;
  meta: VideoMeta;
  theme: VideoTheme;
  scenes: Scene[];
}

export const aspectOf = (meta: VideoMeta): AspectRatio => {
  const ratio = meta.width / meta.height;
  if (Math.abs(ratio - 16 / 9) < 0.02) return '16:9';
  if (Math.abs(ratio - 9 / 16) < 0.02) return '9:16';
  if (Math.abs(ratio - 1) < 0.02) return '1:1';
  return meta.aspect;
};
