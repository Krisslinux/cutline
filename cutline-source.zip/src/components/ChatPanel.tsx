import {AlertTriangle, ArrowUp, AudioLines, Check, FileVideo2, ImagePlus, KeyRound, Paperclip, Sparkles, Square, Wand2, X} from 'lucide-react';
import {useEffect, useRef, useState, type DragEvent} from 'react';
import type {MediaAttachment} from '../types';
import type {TokenUsage} from '../../shared/media';
import {formatTokenUsage} from '../lib/usage';

export type ChatEntry =
  | {id: string; role: 'user'; text: string}
  | {id: string; role: 'assistant'; text: string}
  | {id: string; role: 'error'; text: string; settingsAction?: boolean; retryAction?: boolean}
  | {id: string; role: 'tool'; name: string; label: string; ok: boolean};

const SUGGESTIONS = [
  'A 20-second launch teaser, 16:9, warm palette',
  'Vertical 9:16 hook for a fitness app, punchy copy',
  'Make it moodier: big serif type, one strong quote',
  'Tighten the cut — fewer scenes, faster pacing',
];

interface ChatPanelProps {
  entries: ChatEntry[];
  busy: boolean;
  status: string;
  model: string;
  configured: boolean;
  attachments: MediaAttachment[];
  usage: TokenUsage | null;
  onSend: (prompt: string) => void;
  onCreateVideo: (prompt: string) => void;
  onRetry: () => void;
  onStop: () => void;
  onOpenSettings: () => void;
  onAddFiles: (files: File[]) => void;
  onRemoveAttachment: (id: string) => void;
  onDropFiles: (files: File[]) => void;
}

export function ChatPanel({
  entries,
  busy,
  status,
  model,
  configured,
  attachments,
  usage,
  onSend,
  onCreateVideo,
  onRetry,
  onStop,
  onOpenSettings,
  onAddFiles,
  onRemoveAttachment,
  onDropFiles,
}: ChatPanelProps) {
  const [draft, setDraft] = useState('');
  const [dragOver, setDragOver] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [entries.length, busy, status, usage?.totalTokens]);

  const submit = () => {
    const text = draft.trim();
    if ((!text && attachments.length === 0) || busy) return;
    if (attachments.length) {
      if (!text) return;
      setDraft('');
      onCreateVideo(text);
      return;
    }
    setDraft('');
    onSend(text);
  };

  const handleDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    setDragOver(false);
    const files = Array.from(event.dataTransfer.files);
    if (files.length) onDropFiles(files);
  };

  return (
    <section
      className={`chat-pane${dragOver ? ' chat-pane-dragging' : ''}`}
      onDragOver={(event) => {
        if (Array.from(event.dataTransfer.items).some((item) => item.kind === 'file')) {
          event.preventDefault();
          setDragOver(true);
        }
      }}
      onDragLeave={(event) => {
        if (!event.currentTarget.contains(event.relatedTarget as Node | null)) setDragOver(false);
      }}
      onDrop={handleDrop}
    >
      <div className="pane-head">
        <div>
          <h2 className="pane-title">Director</h2>
          <p className="pane-sub">Describe it. AI directs the edit from your clips and photos.</p>
        </div>
        <span className="pane-badge">
          <Sparkles size={12} />
          agent
        </span>
      </div>

      <div className="chat-scroll" ref={scrollRef}>
        {!configured ? (
          <div className="setup-card">
            <div className="setup-icon">
              <KeyRound size={18} />
            </div>
            <h3>Connect your model</h3>
            <p>
              Add your provider URL, model, and API token. The token stays in this browser and is used only when AI creates or revises your edit. Provider usage may cost money.
            </p>
            <button className="btn btn-primary" onClick={onOpenSettings}>
              Add credentials
            </button>
            <p className="setup-note">
              Choose a model that supports structured tool calls. Images and selected frames are sent to that provider for planning; video/audio files are rendered locally on your server.
            </p>
          </div>
        ) : null}

        {configured && entries.length === 0 ? (
          <div className="chat-empty">
            <h3>Make a video from your media</h3>
            <p>
              Upload photos, video clips, and optional narration or music. Describe the result; AI assembles the edit and renders up to two minutes. Your provider token pays for the AI calls.
            </p>
            <div className="prompt-chips">
              {SUGGESTIONS.map((suggestion) => (
                <button key={suggestion} className="prompt-chip" disabled={busy || !configured} onClick={() => onSend(suggestion)}>
                  {suggestion}
                </button>
              ))}
            </div>
          </div>
        ) : null}

        {entries.map((entry) => {
          if (entry.role === 'user') {
            return (
              <div className="msg msg-user" key={entry.id}>
                <span className="msg-role">You</span>
                <p className="msg-body">{entry.text}</p>
              </div>
            );
          }
          if (entry.role === 'assistant') {
            return (
              <div className="msg msg-assistant" key={entry.id}>
                <span className="msg-role">
                  <Wand2 size={12} /> Director
                </span>
                <p className="msg-body">{entry.text}</p>
              </div>
            );
          }
          if (entry.role === 'error') {
            return (
              <div className="msg msg-error" key={entry.id}>
                <span className="msg-role">
                  <AlertTriangle size={12} /> Error
                </span>
                <p className="msg-body">{entry.text}</p>
                <div className="error-actions">
                  {entry.settingsAction ? (
                    <button className="btn btn-ghost error-settings-action" onClick={onOpenSettings}>
                      Check model settings
                    </button>
                  ) : null}
                  {entry.retryAction ? (
                    <button className="btn btn-primary error-settings-action" onClick={onRetry} disabled={busy}>
                      Retry edit
                    </button>
                  ) : null}
                </div>
              </div>
            );
          }
          return (
            <div className="tool-row" key={entry.id} data-ok={entry.ok}>
              <span className="tool-check">{entry.ok ? <Check size={11} /> : <AlertTriangle size={11} />}</span>
              <span className="tool-name">{entry.name}</span>
              <span className="tool-label">{entry.label}</span>
            </div>
          );
        })}

        {busy ? (
          <div className="status-block">
            <div className="status-row">
              <span className="spinner" />
              <span>{status}</span>
              {usage && usage.requests > 0 ? (() => {
                const display = formatTokenUsage(usage);
                return (
                  <span className="token-usage" data-source={display.source} title={display.detail}>
                    <span className="token-count">{display.total}</span> tokens
                    {usage.reported ? <span className="token-breakdown">{display.detail}</span> : <span className="token-breakdown">usage unavailable</span>}
                  </span>
                );
              })() : null}
            </div>
            <p className="status-note">
              Runs on the server — you can leave this tab and come back.
              {usage?.requests ? ` · ${usage.requests} model ${usage.requests === 1 ? 'call' : 'calls'}` : ''}
            </p>
          </div>
        ) : usage && usage.requests > 0 ? (
          <div className="usage-summary" data-source={usage.reported ? 'provider' : 'unreported'} title={formatTokenUsage(usage).detail}>
            <span>{usage.reported ? `${formatTokenUsage(usage).total} tokens used` : 'Token usage not reported by endpoint'}</span>
            {usage.reported ? <span>{formatTokenUsage(usage).detail}</span> : null}
          </div>
        ) : null}
      </div>

      <div className="composer" aria-label="Write an AI edit prompt">
        <div className="composer-intro">
          <strong>Tell Cutline what you want</strong>
          <span>Describe a video to create or a change to make.</span>
        </div>
        {attachments.length ? (
          <div className="attachment-strip">
            {attachments.map((attachment) => (
              <div className="attachment-card" key={attachment.id} title={`${attachment.name}${attachment.durationSeconds ? ` · ${attachment.durationSeconds.toFixed(1)}s` : ''}`}>
                {attachment.kind === 'image' ? (
                  <img src={attachment.frames[0]?.dataUrl} alt="" className="attachment-thumb" />
                ) : attachment.kind === 'audio' ? (
                  <div className="attachment-video-thumb"><AudioLines size={20} /><span>Audio</span></div>
                ) : (
                  <div className="attachment-video-thumb">
                    <img src={attachment.frames[0]?.dataUrl} alt="" className="attachment-thumb" />
                    <FileVideo2 size={14} />
                  </div>
                )}
                <span className="attachment-name">{attachment.name}</span>
                {attachment.durationSeconds ? (
                  <span className="attachment-duration">{attachment.durationSeconds.toFixed(1)}s</span>
                ) : null}
                <button className="attachment-remove" aria-label={`Remove ${attachment.name}`} disabled={busy} onClick={() => onRemoveAttachment(attachment.id)}>
                  <X size={11} />
                </button>
              </div>
            ))}
          </div>
        ) : null}
        <div className="composer-row">
          <input
            ref={fileRef}
            className="visually-hidden-input"
            type="file"
            accept="image/*,video/*,audio/*,.jpg,.jpeg,.png,.webp,.gif,.avif,.mp4,.m4v,.mov,.webm,.ogv,.mp3,.wav,.m4a,.aac,.ogg,.opus,.flac"
            multiple
            onChange={(event) => {
              const files = Array.from(event.target.files ?? []);
              if (files.length) onAddFiles(files);
              event.currentTarget.value = '';
            }}
          />
          <textarea
            className="composer-input"
            value={draft}
            placeholder={configured ? (attachments.length ? 'What should I do with these?' : 'Describe the video or edit…') : 'Connect your model to start describing your video'}
            aria-label="Describe the video or edit you want"
            rows={2}
            spellCheck={false}
            onChange={(event) => setDraft(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault();
                submit();
              }
            }}
          />
          <button className="icon-btn attach-btn" onClick={() => fileRef.current?.click()} disabled={busy || attachments.length >= 6} title="Attach images, video, or audio" aria-label="Attach images, video, or audio">
            <Paperclip size={16} />
          </button>
          {busy ? (
            <button className="send-btn" onClick={onStop} title="Stop" aria-label="Stop">
              <Square size={14} />
            </button>
          ) : (
            <button className="send-btn" onClick={submit} disabled={!draft.trim() && !attachments.length} title="Send" aria-label="Send">
              <ArrowUp size={16} />
            </button>
          )}
        </div>
        <div className="composer-hint">
          <span>{attachments.length ? `${attachments.length}/6 files · 2 min max` : configured ? model : 'No model connected'}</span>
          <span className="kbd">Attach photos, clips, audio · describe the video · Enter to create</span>
        </div>
        {dragOver ? <div className="drop-hint"><ImagePlus size={16} /> Drop images, clips, or audio</div> : null}
      </div>
    </section>
  );
}
