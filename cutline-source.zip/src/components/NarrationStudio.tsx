import {useCallback,useEffect,useRef,useState} from 'react';
import {Player} from '@remotion/player';
import {NarrationVideo} from '../video/NarrationVideo';
import {captionPages,timelineSchema,type NarrationTimeline,type Shot} from '../../shared/narration';
import '../studio.css';
interface ProjectSummary {id:string;title:string;revision:number}
interface Asset {id:string;name:string;kind:string;duration_ms:number|null}
interface Job {id:string;kind:string;state:string;stage:string;progress:number|null;error:string|null;revision:number}
interface Project extends ProjectSummary {timeline:NarrationTimeline|null;assets:Asset[];jobs:Job[]}
const browserKey=()=>{
  const existing=localStorage.getItem('cutline.browser-session.v1');
  if(existing&&/^[a-f0-9]{64}$/.test(existing))return existing;
  const bytes=crypto.getRandomValues(new Uint8Array(32));
  const generated=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
  localStorage.setItem('cutline.browser-session.v1',generated);
  return generated;
};
const api=async<T,>(route:string,method='GET',data?:unknown):Promise<T>=>{
  const response=await fetch('/api/studio'+route,{method,headers:data?{'content-type':'application/json'}:undefined,body:data?JSON.stringify(data):undefined});
  const result=await response.json();if(!response.ok)throw new Error(result.error??`Request failed (${response.status})`);return result as T;
};
const terminal=(state:string)=>['ready','completed','failed','cancelled'].includes(state);
export function NarrationStudio(){
  const [sessionReady,setSessionReady]=useState(false),[checking,setChecking]=useState(true),[error,setError]=useState(''),[busy,setBusy]=useState(false);
  const [projects,setProjects]=useState<ProjectSummary[]>([]),[project,setProject]=useState<Project|null>(null),[timeline,setTimeline]=useState<NarrationTimeline|null>(null),[dirty,setDirty]=useState(false);
  const [section,setSection]=useState<'words'|'shots'|'json'>('words'),[jsonText,setJsonText]=useState(''),[worker,setWorker]=useState<boolean|null>(null),[providerOpen,setProviderOpen]=useState(false),[uploadProgress,setUploadProgress]=useState(0);
  const selected=useRef<string|null>(null);selected.current=project?.id??null;
  const working=project?.jobs.some(j=>!terminal(j.state))??false;
  const refreshList=useCallback(async()=>setProjects(await api<ProjectSummary[]>('/projects')),[]);
  const startSession=useCallback(async()=>{
    setChecking(true);setError('');
    try{await api<{username:string}>('/session','POST',{browserKey:browserKey()});await refreshList();setSessionReady(true);}
    catch(e){setError(e instanceof Error?e.message:'Could not open a private browser session.');setSessionReady(false);}
    finally{setChecking(false);}
  },[refreshList]);
  const perform=async(fn:()=>Promise<void>)=>{setBusy(true);setError('');try{await fn();}catch(e){setError(e instanceof Error?e.message:'Operation failed.');}finally{setBusy(false);}};
  const open=useCallback(async(id:string,replace=true)=>{const p=await api<Project>(`/projects/${id}`);setProject(p);if(replace){setTimeline(p.timeline);setJsonText(JSON.stringify(p.timeline,null,2));setDirty(false);}},[]);
  useEffect(()=>{void startSession();},[startSession]);
  useEffect(()=>{if(!sessionReady)return;let stopped=false;const check=async()=>{try{const r=await api<{heartbeat:number}[]>('/worker');if(!stopped)setWorker(r.some(w=>Date.now()-Number(w.heartbeat)<45000));}catch{if(!stopped)setWorker(false);}};void check();const timer=setInterval(()=>void check(),10000);return()=>{stopped=true;clearInterval(timer);};},[sessionReady]);
  useEffect(()=>{if(!project?.id||!working)return;const id=project.id;let stopped=false;const timer=setInterval(()=>{api<Project>(`/projects/${id}`).then(p=>{if(stopped||selected.current!==id)return;setProject(p);if(!p.jobs.some(j=>!terminal(j.state))){setTimeline(p.timeline);setJsonText(JSON.stringify(p.timeline,null,2));setDirty(false);void refreshList().catch(e=>setError(e.message));}}).catch(e=>setError(e.message));},2000);return()=>{stopped=true;clearInterval(timer);};},[project?.id,working,refreshList]);
  const edit=(next:NarrationTimeline)=>{setTimeline({...next,captionPages:next.captionPages.map(p=>({...p,text:p.wordIds.map(id=>next.captionWords.find(w=>w.id===id)?.text??'').join(' ')}))});setDirty(true);};
  const save=async()=>{if(!project||!timeline)return;const current={...timeline,captionPages:timeline.captionPages.map(p=>({...p,text:p.wordIds.map(id=>timeline.captionWords.find(w=>w.id===id)?.text??'').join(' ')}))};const validated=timelineSchema.parse(current);await api(`/projects/${project.id}`,'PUT',{revision:project.revision,timeline:validated});await open(project.id);await refreshList();};
  const upload=(file:File)=>new Promise<void>((resolve,reject)=>{
    const xhr=new XMLHttpRequest();xhr.open('POST',`/api/studio/projects/${project!.id}/assets`);
    const ext=file.name.toLowerCase().split('.').at(-1);const fallback:Record<string,string>={wav:'audio/wav',mp3:'audio/mpeg',m4a:'audio/mp4',png:'image/png',jpg:'image/jpeg',jpeg:'image/jpeg',webp:'image/webp'};
    xhr.setRequestHeader('Content-Type',fallback[ext??'']??file.type);xhr.setRequestHeader('X-File-Name',encodeURIComponent(file.name));
    xhr.upload.onprogress=e=>{if(e.lengthComputable)setUploadProgress(e.loaded/e.total);};
    xhr.onerror=()=>reject(new Error('Upload interrupted. Please retry.'));xhr.onload=()=>{if(xhr.status>=200&&xhr.status<300)resolve();else{try{reject(new Error(JSON.parse(xhr.responseText).error));}catch{reject(new Error(`Upload failed (${xhr.status}).`));}}};xhr.send(file);
  });
  if(checking)return <main className="studio-login"><p>Opening your private studio…</p></main>;
  if(!sessionReady)return <main className="studio-login"><section className="setup-card"><span className="pane-badge">No account required</span><h1>Your private studio.</h1><p>Edits are isolated to this browser. Enable browser storage to continue.</p>{error&&<p role="alert" className="notice notice-error">{error}</p>}<button className="btn btn-primary" onClick={()=>void startSession()}>Try again</button></section></main>;
  return <main className="narration-studio">
    <header className="topbar"><div className="brand"><span className="brand-mark">C</span><span className="brand-name">Cutline</span><span className="mono-tag">Narration studio</span></div>
      <div className="studio-actions"><span className="studio-session-note">Private to this browser</span><a className="btn btn-ghost" href="?editor=classic">Classic editor</a><button className="btn" onClick={()=>setProviderOpen(!providerOpen)}>Provider settings</button></div></header>
    <div className="studio-body"><aside className="studio-sidebar"><div className="pane-head"><h2 className="pane-title">Current edit</h2></div>
      <div className="studio-projects">{projects.map(p=><button className="studio-project" data-selected={project?.id===p.id} key={p.id} onClick={()=>{if(dirty&&!confirm('Discard unsaved corrections?'))return;void perform(()=>open(p.id));}}>{p.title}<small>Revision {p.revision}</small></button>)}</div>
      <form className="studio-new" onSubmit={e=>{e.preventDefault();if(projects.length>0&&!confirm('Start a new edit? This permanently removes the previous edit, uploaded files, and export from this browser.'))return;const data=new FormData(e.currentTarget);void perform(async()=>{const p=await api<ProjectSummary>('/projects','POST',{title:data.get('title'),hints:data.get('hints')??'',language:data.get('language')??'en'});await refreshList();await open(p.id);});}}>
        <h3>Start a new edit</h3><p className="hint studio-replace-note">Starting over deletes this browser’s previous edit, uploads, and export.</p><label className="field"><span>Title</span><input className="input" name="title" required maxLength={160} placeholder="The story of Neith" /></label>
        <label className="field"><span>Name spelling hints</span><textarea className="input textarea" name="hints" placeholder="Neith, Tefnut, Hathor, Wepwawet" maxLength={2000}/></label>
        <label className="field"><span>Language code</span><input className="input" name="language" defaultValue="en" pattern="[a-z]{2}" required maxLength={2}/></label><button className="btn btn-primary" disabled={busy}>Create project</button>
      </form><p className="hint studio-worker">Worker: {worker===null?'checking…':worker?'connected':'offline — processing waits until it starts'}</p>
    </aside>
    <section className="studio-main">
      {error&&<div role="alert" className="notice notice-error">{error}</div>}
      {providerOpen&&<ProviderForm onError={setError} onClose={()=>setProviderOpen(false)}/>}
      {!project?<div className="studio-empty"><span className="pane-badge">Audio → illustrations → film</span><h1>Your voice.<br/>A world of stories.</h1><p>Create a project, upload your prepared illustrations and narration, and let the worker draft a synchronized edit. No planning API key is required.</p></div>:<>
        <div className="studio-heading"><div>{timeline?<input className="project-title" aria-label="Film title" value={timeline.title} disabled={busy||working} onChange={e=>edit({...timeline,title:e.target.value})}/>:<h1>{project.title}</h1>}<p className="hint">720 × 1280 · 30 fps · {project.assets.find(a=>a.kind==='audio')?.duration_ms?`${(Number(project.assets.find(a=>a.kind==='audio')!.duration_ms)/1000).toFixed(2)}s narration`:'Narration duration is inspected by the worker'} · Revision {project.revision}{dirty?' · Unsaved changes':''}</p></div>
        <div className="studio-actions"><button className="btn" disabled={busy||working||!timeline||!dirty} onClick={()=>void perform(save)}>Save corrections</button><button className="btn btn-primary" disabled={busy||working||!timeline||dirty} onClick={()=>void perform(async()=>{await api(`/projects/${project.id}/render`,'POST');await open(project.id,false);})}>Render MP4</button></div></div>
        {!timeline&&<section className="setup-card studio-upload"><h2>Bring your story</h2><p>One WAV, MP3 or M4A narration, plus PNG, JPEG or WebP illustrations. Up to ten minutes of narration; 40 images. Files stay private.</p>
          <label className="field"><span>Upload narration and illustrations</span><input type="file" multiple accept=".wav,.mp3,.m4a,.png,.jpg,.jpeg,.webp" disabled={busy||working} onChange={e=>{const files=Array.from(e.target.files??[]);void perform(async()=>{for(const f of files)await upload(f);setUploadProgress(0);await open(project.id);});e.target.value='';}}/></label>
          {busy&&uploadProgress>0&&<progress max={1} value={uploadProgress} aria-label="Upload progress"/>}<ul>{project.assets.map(a=><li key={a.id}>{a.kind==='audio'?'♫':'▧'} {a.name}</li>)}</ul>
          <button className="btn btn-primary" disabled={busy||working||!project.assets.some(a=>a.kind==='audio')||!project.assets.some(a=>a.kind==='image')} onClick={()=>void perform(async()=>{await api(`/projects/${project.id}/draft`,'POST');await open(project.id,false);})}>Transcribe & create draft</button></section>}
        {timeline&&<><div className="studio-review"><div className="studio-player"><Player component={NarrationVideo} inputProps={{timeline,assets:Object.fromEntries(project.assets.map(a=>[a.id,`/api/studio/assets/${a.id}`]))}} compositionWidth={720} compositionHeight={1280} fps={30} durationInFrames={timeline.durationInFrames} controls style={{width:'100%',maxHeight:'65vh',aspectRatio:'9/16'}} /></div>
          <section className="studio-corrections"><div className="studio-actions studio-tabs" role="tablist" aria-label="Edit tools"><button className="btn" role="tab" aria-selected={section==='words'} onClick={()=>setSection('words')}>Transcript & timing</button><button className="btn" role="tab" aria-selected={section==='shots'} onClick={()=>setSection('shots')}>Shots & framing</button><button className="btn" role="tab" aria-selected={section==='json'} onClick={()=>{setSection('json');setJsonText(JSON.stringify(timeline,null,2));}}>Timeline JSON</button></div>
            <fieldset disabled={busy||working} className="studio-fields">
            {section==='words'&&<><p className="hint">Correct spelling and word start/end times in seconds. Low-confidence words are flagged. Regroup phrases after corrections, or edit phrase timing below.</p><div className="studio-words">{timeline.captionWords.map((w,i)=><div className="studio-word" key={w.id}><input aria-label={`Word ${i+1}`} className="input" value={w.text} onChange={e=>edit({...timeline,captionWords:timeline.captionWords.map(x=>x.id===w.id?{...x,text:e.target.value}:x)})}/><input aria-label={`Word ${i+1} start seconds`} type="number" step="0.01" min="0" className="input" value={w.startMs/1000} onChange={e=>edit({...timeline,captionWords:timeline.captionWords.map(x=>x.id===w.id?{...x,startMs:Number(e.target.value)*1000}:x)})}/><input aria-label={`Word ${i+1} end seconds`} type="number" step="0.01" min="0" className="input" value={w.endMs/1000} onChange={e=>edit({...timeline,captionWords:timeline.captionWords.map(x=>x.id===w.id?{...x,endMs:Number(e.target.value)*1000}:x)})}/>{w.uncertain&&<span title="Review this low-confidence word">⚑</span>}</div>)}</div>
            <button className="btn" onClick={()=>edit({...timeline,captionPages:captionPages(timeline.captionWords)})}>Regroup caption phrases</button><h3>Caption phrases</h3>{timeline.captionPages.map((p,i)=><div className="studio-word" key={p.id}><span>{p.wordIds.map(id=>timeline.captionWords.find(w=>w.id===id)?.text).join(' ')}</span><input aria-label={`Phrase ${i+1} start frame`} className="input" type="number" value={p.startFrame} onChange={e=>edit({...timeline,captionPages:timeline.captionPages.map(c=>c.id===p.id?{...c,startFrame:Number(e.target.value)}:c)})}/><input aria-label={`Phrase ${i+1} end frame`} className="input" type="number" value={p.endFrame} onChange={e=>edit({...timeline,captionPages:timeline.captionPages.map(c=>c.id===p.id?{...c,endFrame:Number(e.target.value)}:c)})}/></div>)}</>}
            {section==='shots'&&timeline.shots.map((shot,i)=><ShotEditor key={shot.id} shot={shot} index={i} count={timeline.shots.length} assets={project.assets.filter(a=>a.kind==='image')} onChange={s=>edit({...timeline,shots:timeline.shots.map(x=>x.id===s.id?s:x)})} onMove={direction=>{const shots=[...timeline.shots],other=i+direction;if(other<0||other>=shots.length)return;const a=shots[i],b=shots[other];shots[i]={...a,imageAssetId:b.imageAssetId,focalPoint:b.focalPoint,fit:b.fit,startScale:b.startScale,endScale:b.endScale,pan:b.pan};shots[other]={...b,imageAssetId:a.imageAssetId,focalPoint:a.focalPoint,fit:a.fit,startScale:a.startScale,endScale:a.endScale,pan:a.pan};edit({...timeline,shots});}}/>)}
            {section==='json'&&<><textarea aria-label="Editable timeline JSON" className="input textarea studio-json" value={jsonText} onChange={e=>setJsonText(e.target.value)}/><button className="btn" onClick={()=>{try{edit(timelineSchema.parse(JSON.parse(jsonText)));setError('');}catch(e){setError(e instanceof Error?e.message:'Invalid timeline.');}}}>Apply validated JSON</button></>}
            </fieldset><p className="hint">Changes invalidate older renders. Save before exporting; caption text must match your corrected words.</p>
          </section></div><div className="studio-actions"><a className="btn" href={`/api/studio/projects/${project.id}/srt`}>Download saved SRT</a><a className="btn" href={`/api/studio/projects/${project.id}/json`}>Download saved timeline</a></div></>}
        <section className="studio-jobs"><h2>Processing & exports</h2>{!project.jobs.length&&<p className="hint">Jobs will appear here with real processing stages.</p>}{project.jobs.map(job=><article key={job.id} className="studio-job"><div><strong>{job.kind==='draft'?'Draft':'MP4 render'} · {job.state}</strong><p>{job.stage}</p>{job.error&&<p className="notice-error" role="alert">{job.error}</p>}{job.progress!==null&&!terminal(job.state)&&<progress value={job.progress} max={1} aria-label="Processing progress"/>}</div><div className="studio-actions">
          {!terminal(job.state)&&<button className="btn" onClick={()=>void perform(async()=>{await api(`/jobs/${job.id}/cancel`,'POST');await open(project.id,false);})}>Cancel</button>}
          {['failed','cancelled'].includes(job.state)&&<button className="btn" disabled={busy||working} onClick={()=>void perform(async()=>{await api(`/jobs/${job.id}/retry`,'POST');await open(project.id,false);})}>Retry</button>}
          {job.state==='completed'&&job.revision===project.revision&&!dirty&&<a className="btn btn-primary" href={`/api/studio/jobs/${job.id}/download`}>Download MP4</a>}</div>
          {job.state==='completed'&&job.revision===project.revision&&!dirty&&<video controls preload="metadata" src={`/api/studio/jobs/${job.id}/download`} aria-label="Completed rendered video"/>}
        </article>)}</section>
      </>}
    </section></div>
  </main>;
}
function ShotEditor({shot:s,index,count,assets,onChange,onMove}:{shot:Shot;index:number;count:number;assets:Asset[];onChange:(s:Shot)=>void;onMove:(d:number)=>void}){
  const number=(label:string,value:number,change:(n:number)=>void,step=.01)=><label className="field"><span>{label}</span><input className="input" type="number" value={value} step={step} onChange={e=>change(Number(e.target.value))}/></label>;
  return <article className="studio-shot"><div className="studio-actions"><h3>Shot {index+1}</h3><button className="btn btn-small" disabled={index===0} onClick={()=>onMove(-1)}>↑ Move image</button><button className="btn btn-small" disabled={index===count-1} onClick={()=>onMove(1)}>↓ Move image</button></div>
    <label className="field"><span>Illustration</span><select className="input" value={s.imageAssetId} onChange={e=>onChange({...s,imageAssetId:e.target.value})}>{assets.map(a=><option key={a.id} value={a.id}>{a.name}</option>)}</select></label>
    <div className="studio-number-grid">{number('Start frame',s.startFrame,n=>onChange({...s,startFrame:n}),1)}{number('End frame',s.endFrame,n=>onChange({...s,endFrame:n}),1)}{number('Focal X (0–1)',s.focalPoint.x,n=>onChange({...s,focalPoint:{...s.focalPoint,x:n}}))}{number('Focal Y (0–1)',s.focalPoint.y,n=>onChange({...s,focalPoint:{...s.focalPoint,y:n}}))}{number('Start zoom',s.startScale,n=>onChange({...s,startScale:n}))}{number('End zoom',s.endScale,n=>onChange({...s,endScale:n}))}{number('Pan X',s.pan.x,n=>onChange({...s,pan:{...s.pan,x:n}}),1)}{number('Pan Y',s.pan.y,n=>onChange({...s,pan:{...s.pan,y:n}}),1)}</div>
    <label className="field"><span>Framing</span><select className="input" value={s.fit} onChange={e=>onChange({...s,fit:e.target.value as Shot['fit']})}><option value="contain">Contain — preserve full illustration</option><option value="cover">Fill — crop to frame</option></select></label>
    <label className="field"><span>Transition out</span><select className="input" value={s.transitionOut} onChange={e=>onChange({...s,transitionOut:e.target.value as Shot['transitionOut'],transitionFrames:e.target.value==='none'?0:s.transitionFrames||18})}>{['none','fade','diagonal','radial'].map(v=><option key={v}>{v}</option>)}</select></label>{number('Overlap frames',s.transitionFrames,n=>onChange({...s,transitionFrames:n}),1)}
  </article>;
}
function ProviderForm({onError,onClose}:{onError:(e:string)=>void;onClose:()=>void}){
  const [settings,setSettings]=useState({provider:'openai-compatible',baseUrl:'https://api.openai.com/v1',model:'',hasKey:false}),[key,setKey]=useState(''),[busy,setBusy]=useState(false);
  useEffect(()=>{api<typeof settings|null>('/provider').then(p=>{if(p)setSettings(p);}).catch(e=>onError(e.message));},[onError]);
  return <form className="setup-card studio-provider" onSubmit={e=>{e.preventDefault();setBusy(true);api('/provider','PUT',{provider:settings.provider,baseUrl:settings.baseUrl,model:settings.model,...(key?{apiKey:key}:{})}).then(()=>{setKey('');onClose();}).catch(e=>onError(e.message)).finally(()=>setBusy(false));}}><h2>Optional planning provider</h2><p className="hint">Without a key, drafts use punctuation and pauses with images assigned in order. Keys are encrypted on the backend, never saved in browser storage.</p>
    <label className="field"><span>Adapter</span><select className="input" value={settings.provider} onChange={e=>setSettings({...settings,provider:e.target.value,baseUrl:e.target.value==='anthropic'?'https://api.anthropic.com/v1':'https://api.openai.com/v1'})}><option value="openai-compatible">OpenAI-compatible Chat Completions</option><option value="anthropic">Anthropic Messages</option></select></label>
    <label className="field"><span>Public HTTPS base URL</span><input className="input" value={settings.baseUrl} onChange={e=>setSettings({...settings,baseUrl:e.target.value})} required/></label><label className="field"><span>Model</span><input className="input" value={settings.model} onChange={e=>setSettings({...settings,model:e.target.value})} required/></label>
    <label className="field"><span>{settings.hasKey?'Key saved: •••••••• — leave blank to keep':'API key'}</span><input className="input" type="password" autoComplete="off" value={key} onChange={e=>setKey(e.target.value)}/></label><div className="studio-actions"><button className="btn btn-primary" disabled={busy}>Save encrypted settings</button><button type="button" className="btn" disabled={busy} onClick={()=>{setBusy(true);api('/provider','DELETE').then(onClose).catch(e=>onError(e.message)).finally(()=>setBusy(false));}}>Remove provider</button><button type="button" className="btn" onClick={onClose}>Close</button></div>
  </form>;
}
