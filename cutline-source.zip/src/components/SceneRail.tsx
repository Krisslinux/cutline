import {ChevronDown, ChevronUp, Plus, Trash2} from 'lucide-react';
import type {ReactNode} from 'react';
import type {MediaAttachment} from '../types';
import {
  SCENE_ALIGNS,
  SCENE_ANIMATIONS,
  SCENE_KINDS,
  type FontStyle,
  type Scene,
  type SceneAlign,
  type SceneAnimation,
  type SceneKind,
  type Stat,
  type VideoSpec,
  type VideoTheme,
} from '../types';
import {MAX_SCENE_SECONDS, MIN_SCENE_SECONDS} from '../lib/spec';

interface SceneRailProps {
  spec: VideoSpec;
  attachments?: MediaAttachment[];
  selectedSceneId: string | null;
  /** Manual edits are locked while the background worker rewrites the cut. */
  locked?: boolean;
  onSelect: (sceneId: string) => void;
  onPatchScene: (sceneId: string, patch: Partial<Scene>) => void;
  onDeleteScene: (sceneId: string) => void;
  onMoveScene: (sceneId: string, direction: -1 | 1) => void;
  onAddScene: () => void;
  onPatchTheme: (patch: Partial<VideoTheme>) => void;
}

const Field = ({label, children, hint}: {label: string; children: ReactNode; hint?: string}) => (
  <label className="field">
    <span>{label}</span>
    {children}
    {hint ? <small className="hint">{hint}</small> : null}
  </label>
);

const TextInput = ({
  value,
  onChange,
  placeholder,
  mono,
}: {
  value?: string;
  onChange: (value: string) => void;
  placeholder?: string;
  mono?: boolean;
}) => (
  <input
    className={`input${mono ? ' mono' : ''}`}
    value={value ?? ''}
    placeholder={placeholder}
    spellCheck={false}
    onChange={(event) => onChange(event.target.value)}
  />
);

const TextArea = ({
  value,
  onChange,
  rows = 3,
  placeholder,
}: {
  value?: string;
  onChange: (value: string) => void;
  rows?: number;
  placeholder?: string;
}) => (
  <textarea
    className="input textarea"
    value={value ?? ''}
    rows={rows}
    placeholder={placeholder}
    spellCheck={false}
    onChange={(event) => onChange(event.target.value)}
  />
);

const ColorField = ({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value?: string;
  onChange: (value: string) => void;
  placeholder?: string;
}) => {
  const hex = typeof value === 'string' && /^#[0-9a-fA-F]{6}$/.test(value);
  return (
    <label className="color-field">
      <span>{label}</span>
      <div className="color-controls">
        {hex ? (
          <input
            type="color"
            className="color-input"
            value={value}
            aria-label={`${label} colour picker`}
            onChange={(event) => onChange(event.target.value)}
          />
        ) : (
          <span className="color-empty" aria-hidden />
        )}
        <input
          className="input mono"
          value={value ?? ''}
          placeholder={placeholder ?? '#111111'}
          spellCheck={false}
          onChange={(event) => onChange(event.target.value)}
        />
      </div>
    </label>
  );
};

const SceneTag = ({kind}: {kind: SceneKind}) => (
  <span className={`scene-tag scene-tag-${kind}`}>{kind}</span>
);

export function SceneRail({
  spec,
  attachments = [],
  selectedSceneId,
  locked = false,
  onSelect,
  onPatchScene,
  onDeleteScene,
  onMoveScene,
  onAddScene,
  onPatchTheme,
}: SceneRailProps) {
  const selected = spec.scenes.find((scene) => scene.id === selectedSceneId) ?? spec.scenes[0];

  const patchStats = (scene: Scene, stats: Stat[]) => onPatchScene(scene.id, {stats});
  const updateStat = (scene: Scene, index: number, patch: Partial<Stat>) => {
    const stats = (scene.stats ?? []).map((stat, position) => (position === index ? {...stat, ...patch} : stat));
    patchStats(scene, stats);
  };

  return (
    <aside className="rail">
      <fieldset className="rail-lock" disabled={locked}>
      <div className="rail-section">
        <div className="rail-head">
          <h2 className="pane-title">Timeline</h2>
          <button className="btn btn-ghost btn-small" onClick={onAddScene}>
            <Plus size={13} />
            Scene
          </button>
        </div>
        <div className="scene-list">
          {spec.scenes.map((scene, index) => (
            <div
              key={scene.id}
              className="scene-row"
              data-selected={scene.id === selected?.id}
              onClick={() => onSelect(scene.id)}
              role="button"
              tabIndex={0}
              onKeyDown={(event) => {
                if (event.key === 'Enter' || event.key === ' ') onSelect(scene.id);
              }}
            >
              <span className="scene-index">{String(index + 1).padStart(2, '0')}</span>
              <span className="scene-main">
                <span className="scene-name">{scene.headline || scene.kind}</span>
                <span className="scene-sub">
                  <SceneTag kind={scene.kind} />
                  {(scene.durationInFrames / spec.meta.fps).toFixed(1)}s
                </span>
              </span>
              <span className="row-actions">
                <button
                  className="mini-btn"
                  title="Move up"
                  aria-label="Move up"
                  disabled={index === 0}
                  onClick={(event) => {
                    event.stopPropagation();
                    onMoveScene(scene.id, -1);
                  }}
                >
                  <ChevronUp size={13} />
                </button>
                <button
                  className="mini-btn"
                  title="Move down"
                  aria-label="Move down"
                  disabled={index === spec.scenes.length - 1}
                  onClick={(event) => {
                    event.stopPropagation();
                    onMoveScene(scene.id, 1);
                  }}
                >
                  <ChevronDown size={13} />
                </button>
                <button
                  className="mini-btn danger"
                  title="Delete scene"
                  aria-label="Delete scene"
                  disabled={spec.scenes.length <= 1}
                  onClick={(event) => {
                    event.stopPropagation();
                    onDeleteScene(scene.id);
                  }}
                >
                  <Trash2 size={13} />
                </button>
              </span>
            </div>
          ))}
        </div>
      </div>

      {selected ? (
        <div className="rail-section">
          <div className="rail-head">
            <h2 className="pane-title">Scene</h2>
            <span className="mono-tag">{selected.id}</span>
          </div>

          <div className="inspector">
            <Field label="Kind">
              <select
                className="input select"
                value={selected.kind}
                onChange={(event) => onPatchScene(selected.id, {kind: event.target.value as SceneKind})}
              >
                {SCENE_KINDS.map((kind) => (
                  <option key={kind} value={kind}>
                    {kind}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Kicker">
              <TextInput value={selected.kicker} onChange={(value) => onPatchScene(selected.id, {kicker: value})} placeholder="Optional label" />
            </Field>

            <Field label="Headline">
              <TextArea
                value={selected.headline}
                rows={2}
                onChange={(value) => onPatchScene(selected.id, {headline: value})}
                placeholder="Say it in a few words"
              />
            </Field>

            <Field label="Subhead">
              <TextArea
                value={selected.subhead}
                rows={2}
                onChange={(value) => onPatchScene(selected.id, {subhead: value})}
                placeholder="Optional supporting line"
              />
            </Field>

            {selected.kind === 'bullets' ? (
              <Field label="Points" hint="One per line, max 6.">
                <TextArea
                  value={(selected.items ?? []).join('\n')}
                  rows={4}
                  onChange={(value) =>
                    onPatchScene(selected.id, {items: value.split('\n').map((item) => item.trim()).filter(Boolean).slice(0, 6)})
                  }
                />
              </Field>
            ) : null}

            {selected.kind === 'quote' ? (
              <>
                <Field label="Quote">
                  <TextArea value={selected.quote} rows={3} onChange={(value) => onPatchScene(selected.id, {quote: value})} />
                </Field>
                <Field label="Attribution">
                  <TextInput value={selected.author} onChange={(value) => onPatchScene(selected.id, {author: value})} />
                </Field>
              </>
            ) : null}

            {selected.kind === 'image' ? (
              <>
                <Field label="Use attached media" hint="AI can choose uploaded stills; attached video scenes can play in the local preview.">
                  <select
                    className="input select"
                    value={selected.mediaAttachmentId ?? ''}
                    onChange={(event) => onPatchScene(selected.id, {mediaAttachmentId: event.target.value || undefined, mediaFrameIndex: undefined})}
                  >
                    <option value="">None · gradient or image URL</option>
                    {attachments.map((attachment) => (
                      <option key={attachment.id} value={attachment.id}>
                        {attachment.kind === 'video' ? 'Video' : 'Image'} · {attachment.name}
                      </option>
                    ))}
                  </select>
                </Field>
                {attachments.find((attachment) => attachment.id === selected.mediaAttachmentId)?.kind === 'video' ? (
                  <Field label="Video still frame" hint="The edit model sees sampled stills; the preview plays the local clip.">
                    <select
                      className="input select"
                      value={selected.mediaFrameIndex ?? 0}
                      onChange={(event) => onPatchScene(selected.id, {mediaFrameIndex: Number(event.target.value)})}
                    >
                      {attachments.find((attachment) => attachment.id === selected.mediaAttachmentId)?.frames.map((frame, index) => (
                        <option key={index} value={index}>{index + 1} · {frame.timeSeconds.toFixed(1)}s</option>
                      ))}
                    </select>
                  </Field>
                ) : null}
                <Field label="Image URL" hint="Optional external image URL.">
                  <TextInput mono value={selected.imageUrl} onChange={(value) => onPatchScene(selected.id, {imageUrl: value})} placeholder="https://…" />
                </Field>
              </>
            ) : null}

            {selected.kind === 'outro' ? (
              <Field label="Button label">
                <TextInput value={selected.cta} onChange={(value) => onPatchScene(selected.id, {cta: value})} placeholder="Start editing" />
              </Field>
            ) : null}

            {selected.kind === 'stats' ? (
              <div className="field">
                <span>Numbers</span>
                <div className="stat-editor">
                  {(selected.stats ?? []).map((stat, index) => (
                    <div className="stat-row" key={index}>
                      <input
                        className="input mono"
                        value={stat.value}
                        placeholder="3x"
                        onChange={(event) => updateStat(selected, index, {value: event.target.value})}
                      />
                      <input
                        className="input"
                        value={stat.label}
                        placeholder="faster edits"
                        onChange={(event) => updateStat(selected, index, {label: event.target.value})}
                      />
                      <button
                        className="mini-btn danger"
                        aria-label="Remove stat"
                        onClick={() => patchStats(selected, (selected.stats ?? []).filter((_, position) => position !== index))}
                      >
                        <Trash2 size={12} />
                      </button>
                    </div>
                  ))}
                  {(selected.stats ?? []).length < 4 ? (
                    <button
                      className="btn btn-ghost btn-small"
                      onClick={() => patchStats(selected, [...(selected.stats ?? []), {value: '00', label: 'label'}])}
                    >
                      <Plus size={12} />
                      Add number
                    </button>
                  ) : null}
                </div>
              </div>
            ) : null}

            <Field label={`Duration — ${(selected.durationInFrames / spec.meta.fps).toFixed(1)}s`}>
              <input
                className="range"
                type="range"
                min={MIN_SCENE_SECONDS}
                max={MAX_SCENE_SECONDS}
                step={0.5}
                value={selected.durationInFrames / spec.meta.fps}
                onChange={(event) =>
                  onPatchScene(selected.id, {
                    durationInFrames: Math.round(Number(event.target.value) * spec.meta.fps),
                  })
                }
              />
            </Field>

            <Field label="Entrance">
              <select
                className="input select"
                value={selected.animation ?? 'fade-up'}
                onChange={(event) => onPatchScene(selected.id, {animation: event.target.value as SceneAnimation})}
              >
                {SCENE_ANIMATIONS.map((animation) => (
                  <option key={animation} value={animation}>
                    {animation}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Alignment">
              <div className="segmented segmented-wide">
                {SCENE_ALIGNS.map((align) => (
                  <button
                    key={align}
                    data-active={(selected.align ?? 'left') === align}
                    onClick={() => onPatchScene(selected.id, {align: align as SceneAlign})}
                  >
                    {align}
                  </button>
                ))}
              </div>
            </Field>

            <ColorField
              label="Scene background"
              value={selected.background}
              onChange={(value) => onPatchScene(selected.id, {background: value})}
              placeholder="theme default"
            />
            <ColorField
              label="Scene text"
              value={selected.textColor}
              onChange={(value) => onPatchScene(selected.id, {textColor: value})}
              placeholder="theme default"
            />
            <ColorField
              label="Scene accent"
              value={selected.accent}
              onChange={(value) => onPatchScene(selected.id, {accent: value})}
              placeholder="theme default"
            />
          </div>
        </div>
      ) : null}

      <div className="rail-section">
        <div className="rail-head">
          <h2 className="pane-title">Theme</h2>
        </div>
        <div className="inspector">
          <ColorField label="Background" value={spec.theme.background} onChange={(value) => onPatchTheme({background: value})} />
          <ColorField label="Text" value={spec.theme.text} onChange={(value) => onPatchTheme({text: value})} />
          <ColorField label="Accent" value={spec.theme.accent} onChange={(value) => onPatchTheme({accent: value})} />
          <ColorField label="Muted" value={spec.theme.muted} onChange={(value) => onPatchTheme({muted: value})} />
          <Field label="Supporting type">
            <select
              className="input select"
              value={spec.theme.font}
              onChange={(event) => onPatchTheme({font: event.target.value as FontStyle})}
            >
              <option value="sans">Sans · Inter</option>
              <option value="serif">Serif · Instrument</option>
              <option value="mono">Mono · JetBrains</option>
            </select>
          </Field>
        </div>
      </div>
      </fieldset>
    </aside>
  );
}
