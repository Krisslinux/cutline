import {Player, type PlayerRef} from '@remotion/player';
import {useEffect, useMemo, useRef, useState, type RefObject} from 'react';
import {Video} from '../video/Video';
import {aspectOf, type AspectRatio, type MediaAttachment, type VideoSpec} from '../types';
import {formatTimecode, totalFrames} from '../lib/spec';

interface PreviewStageProps {
  spec: VideoSpec;
  playerRef: RefObject<PlayerRef | null>;
  selectedSceneId: string | null;
  attachments?: MediaAttachment[];
  locked?: boolean;
  onSelectScene: (sceneId: string) => void;
  onSetAspect: (aspect: AspectRatio) => void;
}

const ASPECTS: AspectRatio[] = ['16:9', '9:16', '1:1'];

export function PreviewStage({
  spec,
  playerRef,
  selectedSceneId,
  attachments = [],
  locked = false,
  onSelectScene,
  onSetAspect,
}: PreviewStageProps) {
  const stageRef = useRef<HTMLDivElement>(null);
  const [box, setBox] = useState({width: 0, height: 0});
  const [frame, setFrame] = useState(0);
  const total = totalFrames(spec);
  const aspect = aspectOf(spec.meta);

  useEffect(() => {
    const element = stageRef.current;
    if (!element) return;
    const observer = new ResizeObserver((entries) => {
      const rect = entries[0]?.contentRect;
      if (rect) setBox({width: rect.width, height: rect.height});
    });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  const fit = useMemo(() => {
    const maxWidth = Math.max(0, box.width - 72);
    const maxHeight = Math.max(0, box.height - 72);
    if (!maxWidth || !maxHeight) return {width: 0, height: 0};
    const ratio = spec.meta.width / spec.meta.height;
    const width = Math.min(maxWidth, maxHeight * ratio);
    return {width: Math.round(width), height: Math.round(width / ratio)};
  }, [box, spec.meta.width, spec.meta.height]);

  useEffect(() => {
    let raf = 0;
    let detach: (() => void) | undefined;

    // The Player mounts only once the stage has been measured, so wait for its ref.
    const attach = () => {
      const player = playerRef.current;
      if (!player) {
        raf = requestAnimationFrame(attach);
        return;
      }
      const onFrame = (event: {detail: {frame: number}}) => setFrame(event.detail.frame);
      player.addEventListener('frameupdate', onFrame);
      detach = () => player.removeEventListener('frameupdate', onFrame);
    };
    attach();

    return () => {
      cancelAnimationFrame(raf);
      detach?.();
    };
  }, [playerRef, spec.meta.width, spec.meta.height, fit.width]);

  const seekToRatio = (ratio: number) => {
    const next = Math.round(Math.min(1, Math.max(0, ratio)) * (total - 1));
    playerRef.current?.seekTo(next);
    setFrame(next);
  };

  return (
    <section className="preview-pane">
      <div className="preview-toolbar">
        <div className="toolbar-group">
          <span className="pane-label">Preview</span>
          <span className="meta-text">
            {spec.meta.width}×{spec.meta.height}
          </span>
        </div>
        <div className="segmented" role="group" aria-label="Aspect ratio">
          {ASPECTS.map((option) => (
            <button
              key={option}
              data-active={aspect === option}
              disabled={locked}
              onClick={() => onSetAspect(option)}
              title={`${option} canvas`}
            >
              {option}
            </button>
          ))}
        </div>
      </div>

      <div className="preview-stage" ref={stageRef}>
        <div className="player-shell" style={{width: fit.width || undefined, height: fit.height || undefined}}>
          {fit.width > 0 ? (
            <Player
              ref={playerRef}
              component={Video}
              inputProps={{spec, attachments}}
              durationInFrames={total}
              compositionWidth={spec.meta.width}
              compositionHeight={spec.meta.height}
              fps={spec.meta.fps}
              controls
              loop
              clickToPlay
              doubleClickToFullscreen
              spaceKeyToPlayOrPause={false}
              acknowledgeRemotionLicense
              style={{width: '100%', height: '100%'}}
              errorFallback={({error}: {error: Error}) => (
                <div className="player-error">
                  <strong>This scene cannot render</strong>
                  <span>{error.message}</span>
                </div>
              )}
            />
          ) : null}
        </div>
      </div>

      <div className="preview-footer">
        <div className="timeline" onPointerDown={(event) => {
          const rect = event.currentTarget.getBoundingClientRect();
          seekToRatio((event.clientX - rect.left) / rect.width);
        }}>
          {spec.scenes.map((scene, index) => (
            <button
              key={scene.id}
              className="tl-seg"
              data-selected={scene.id === selectedSceneId}
              style={{flexGrow: Math.max(1, scene.durationInFrames)}}
              title={`${String(index + 1).padStart(2, '0')} · ${scene.kind} · ${(scene.durationInFrames / spec.meta.fps).toFixed(1)}s`}
              onPointerDown={(event) => {
                event.stopPropagation();
                onSelectScene(scene.id);
                const player = playerRef.current;
                if (player) {
                  const start = spec.scenes
                    .slice(0, index)
                    .reduce((sum, item) => sum + item.durationInFrames, 0);
                  player.seekTo(start);
                  setFrame(start);
                }
              }}
            >
              <span className="tl-index">{String(index + 1).padStart(2, '0')}</span>
              <span className="tl-name">{scene.headline || scene.kind}</span>
            </button>
          ))}
          <div className="playhead" style={{left: `${(frame / total) * 100}%`}} />
        </div>
        <div className="preview-meta">
          <span className="timecode">
            {formatTimecode(frame, spec.meta.fps)} <span className="timecode-dim">/ {formatTimecode(total, spec.meta.fps)}</span>
          </span>
          <span className="meta-text">{spec.scenes.length} scenes · {spec.meta.fps}fps</span>
        </div>
      </div>
    </section>
  );
}
