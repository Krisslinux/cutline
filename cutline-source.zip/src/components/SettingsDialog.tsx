import {Check, Eye, EyeOff, Loader2, X} from 'lucide-react';
import {useEffect, useState} from 'react';
import {resolveChatEndpoint} from '../../shared/chat';
import {chatCompletion, verifyToolCallingCompletion} from '../lib/api';
import {PROVIDER_PRESETS, type AiSettings} from '../lib/settings';

interface SettingsDialogProps {
  open: boolean;
  settings: AiSettings;
  onClose: () => void;
  onSave: (settings: AiSettings) => void;
}

type TestState = {state: 'idle' | 'testing' | 'ok' | 'error'; message?: string};

export function SettingsDialog({open, settings, onClose, onSave}: SettingsDialogProps) {
  const [draft, setDraft] = useState<AiSettings>(settings);
  const [showToken, setShowToken] = useState(false);
  const [test, setTest] = useState<TestState>({state: 'idle'});

  useEffect(() => {
    if (open) {
      setDraft(settings);
      setShowToken(false);
      setTest({state: 'idle'});
    }
  }, [open, settings]);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  if (!open) return null;

  let resolved = '';
  if (draft.baseUrl.trim()) {
    try {
      resolved = resolveChatEndpoint(draft.baseUrl);
    } catch {
      resolved = '';
    }
  }

  const ready = Boolean(draft.baseUrl.trim() && draft.model.trim());

  const runTest = async () => {
    if (!ready) return;
    setTest({state: 'testing', message: 'Checking connection and tool calling…'});
    try {
      const completion = await chatCompletion(draft, {
        messages: [{role: 'user', content: 'Call the cutline_compatibility_check tool now. Do not answer with plain text.'}],
        tools: [{
          type: 'function',
          function: {
            name: 'cutline_compatibility_check',
            description: 'Confirms this endpoint supports tool calling.',
            parameters: {type: 'object', properties: {}, additionalProperties: false},
          },
        }],
        toolChoice: {type: 'function', function: {name: 'cutline_compatibility_check'}},
      });
      verifyToolCallingCompletion(completion);
      setTest({state: 'ok', message: 'Connected — this model successfully called a tool and is ready for timeline edits.'});
    } catch (error) {
      setTest({state: 'error', message: error instanceof Error ? error.message : 'Connection failed.'});
    }
  };

  return (
    <div className="overlay" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <div className="modal" role="dialog" aria-modal="true" aria-label="Model settings">
        <div className="modal-head">
          <div>
            <h2>Your model</h2>
            <p className="modal-sub">Any OpenAI-compatible endpoint with tool calling.</p>
          </div>
          <button className="icon-btn" onClick={onClose} aria-label="Close">
            <X size={16} />
          </button>
        </div>

        <div className="modal-body">
          <div className="preset-row">
            {PROVIDER_PRESETS.map((preset) => (
              <button
                key={preset.label}
                className="preset"
                onClick={() => setDraft((current) => ({...current, baseUrl: preset.baseUrl, model: preset.model}))}
              >
                {preset.label}
              </button>
            ))}
          </div>

          <label className="field">
            <span>API base URL</span>
            <input
              className="input"
              value={draft.baseUrl}
              onChange={(event) => setDraft({...draft, baseUrl: event.target.value})}
              placeholder="https://api.openai.com/v1"
              spellCheck={false}
              autoComplete="off"
            />
            <small className="hint">
              {resolved ? <>Requests go to <code>{resolved}</code></> : 'Include the version path, usually /v1.'}
            </small>
          </label>

          <label className="field">
            <span>API token</span>
            <div className="input-row">
              <input
                className="input"
                type={showToken ? 'text' : 'password'}
                value={draft.apiKey}
                onChange={(event) => setDraft({...draft, apiKey: event.target.value})}
                placeholder="sk-…"
                spellCheck={false}
                autoComplete="off"
              />
              <button className="icon-btn" onClick={() => setShowToken((value) => !value)} aria-label="Toggle token">
                {showToken ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </div>
            <small className="hint">
              Optional — leave empty only for an endpoint that requires no token. The token stays in this browser and is sent only to the provider you selected when planning an edit. The provider receives your prompt and uploaded image/video previews; full media and audio bytes are sent only to the editor server when rendering. Provider usage may incur charges.
            </small>
          </label>

          <label className="field">
            <span>Model id</span>
            <input
              className="input"
              value={draft.model}
              onChange={(event) => setDraft({...draft, model: event.target.value})}
              placeholder="gpt-4.1-mini"
              spellCheck={false}
              autoComplete="off"
            />
            <small className="hint">Must support function calling. Smaller models edit faster but write weaker copy.</small>
          </label>

          {test.state !== 'idle' ? (
            <div className={`notice notice-${test.state}`}>
              {test.state === 'testing' ? <Loader2 size={14} className="spin" /> : null}
              {test.state === 'ok' ? <Check size={14} /> : null}
              <span>{test.message}</span>
            </div>
          ) : null}
          <p className="hint">Your token is entered by you and saved only in this browser, never in the server render job or final MP4. Images and sampled video frames are sent to your chosen vision-capable endpoint for planning; original media files are uploaded to this server only to create the MP4. Provider usage may incur charges.</p>
        </div>

        <div className="modal-foot">
          <button className="btn btn-ghost" onClick={runTest} disabled={!ready || test.state === 'testing'}>
            {test.state === 'testing' ? <Loader2 size={14} className="spin" /> : null}
            Test connection
          </button>
          <div className="modal-foot-right">
            <button className="btn btn-ghost" onClick={onClose}>
              Cancel
            </button>
            <button
              className="btn btn-primary"
              disabled={!ready}
              onClick={() => {
                onSave({baseUrl: draft.baseUrl.trim(), apiKey: draft.apiKey.trim(), model: draft.model.trim()});
                onClose();
              }}
            >
              Save
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
