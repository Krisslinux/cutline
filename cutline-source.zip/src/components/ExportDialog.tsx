import {Download, FileJson, X} from 'lucide-react';
import {useEffect, useState} from 'react';
import {buildProjectFiles, downloadProjectZip, downloadSpecJson} from '../lib/export-project';
import type {MediaAttachment, VideoSpec} from '../types';

interface ExportDialogProps {
  open: boolean;
  spec: VideoSpec;
  attachments?: MediaAttachment[];
  onClose: () => void;
  onNotify: (message: string) => void;
}

export function ExportDialog({open, spec, attachments = [], onClose, onNotify}: ExportDialogProps) {
  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  const [downloading, setDownloading] = useState(false);
  if (!open) return null;

  const files = buildProjectFiles(spec, {media: attachments});
  const duration = spec.scenes.reduce((sum, scene) => sum + scene.durationInFrames, 0) / spec.meta.fps;

  return (
    <div className="overlay" onMouseDown={(event) => event.target === event.currentTarget && onClose()}>
      <div className="modal" role="dialog" aria-modal="true" aria-label="Export project">
        <div className="modal-head">
          <div>
            <h2>Export</h2>
            <p className="modal-sub">
              {spec.meta.width}×{spec.meta.height} · {spec.meta.fps}fps · {duration.toFixed(1)}s
            </p>
          </div>
          <button className="icon-btn" onClick={onClose} aria-label="Close">
            <X size={16} />
          </button>
        </div>

        <div className="modal-body">
          <p className="export-lead">
            This cut is a real Remotion project. Download it, run two commands, and you have an MP4 — the same renderer
            you are previewing here.
          </p>
          <pre className="code-block">
            <code>{'npm install\nnpm run studio   # preview\nnpm run render   # out/video.mp4'}</code>
          </pre>
          <ul className="file-list">
            {Object.keys(files).map((path) => (
              <li key={path}>
                <span className="file-dot" />
                {path}
              </li>
            ))}
          </ul>
        </div>

        <div className="modal-foot">
          <button
            className="btn btn-ghost"
            onClick={() => {
              const name = downloadSpecJson(spec);
              onNotify(`Downloaded ${name}`);
            }}
          >
            <FileJson size={15} />
            Spec JSON
          </button>
          <div className="modal-foot-right">
            <button className="btn btn-ghost" onClick={onClose}>
              Close
            </button>
            <button
              className="btn btn-primary"
              disabled={downloading}
              onClick={async () => {
                setDownloading(true);
                try {
                  const name = await downloadProjectZip(spec, {media: attachments});
                  onNotify(`Downloaded ${name}`);
                  onClose();
                } catch (error) {
                  onNotify(error instanceof Error ? error.message : 'Could not export this project.');
                } finally {
                  setDownloading(false);
                }
              }}
            >
              <Download size={15} />
              {downloading ? 'Preparing project…' : 'Download project'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
