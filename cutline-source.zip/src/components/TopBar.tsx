import {Download, Film, LoaderCircle, Redo2, Settings2, Undo2} from 'lucide-react';

interface TopBarProps {
  title: string;
  onTitleChange: (title: string) => void;
  sceneCount: number;
  seconds: number;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
  model: string;
  endpointHost: string;
  configured: boolean;
  /** Disables manual edits while a background job is rewriting the cut. */
  locked?: boolean;
  onOpenSettings: () => void;
  onExport: () => void;
  onRender: () => void;
  rendering: boolean;
}

export function TopBar({
  title,
  onTitleChange,
  sceneCount,
  seconds,
  canUndo,
  canRedo,
  onUndo,
  onRedo,
  model,
  endpointHost,
  configured,
  locked = false,
  onOpenSettings,
  onExport,
  onRender,
  rendering,
}: TopBarProps) {
  return (
    <header className="topbar">
      <div className="topbar-left">
        <div className="brand">
          <span className="brand-mark">C</span>
          <span className="brand-name">Cutline</span>
        </div>
        <span className="topbar-divider" />
        <input
          className="project-title"
          value={title}
          readOnly={locked}
          onChange={(event) => onTitleChange(event.target.value)}
          aria-label="Project title"
          spellCheck={false}
        />
        <span className="meta-text">
          {sceneCount} {sceneCount === 1 ? 'scene' : 'scenes'} · {seconds.toFixed(1)}s
        </span>
      </div>

      <div className="topbar-actions">
        <button className="icon-btn" onClick={onUndo} disabled={!canUndo || locked} title="Undo (⌘Z)" aria-label="Undo">
          <Undo2 size={16} />
        </button>
        <button className="icon-btn" onClick={onRedo} disabled={!canRedo || locked} title="Redo (⇧⌘Z)" aria-label="Redo">
          <Redo2 size={16} />
        </button>
        <span className="topbar-divider" />
        <button
          className="chip"
          onClick={onOpenSettings}
          title={configured ? `${endpointHost} · ${model}` : 'Add your API URL, token and model'}
        >
          <span className="chip-dot" data-on={configured} />
          <span className="chip-text">{configured ? model : 'Connect model'}</span>
          <Settings2 size={14} />
        </button>
        <button className="btn btn-ghost render-button" onClick={onRender} disabled={rendering || locked} title="Render the video on the server">
          {rendering ? <LoaderCircle size={15} className="render-spinner" /> : <Film size={15} />}
          <span>{rendering ? 'Rendering…' : 'Render MP4'}</span>
        </button>
        <button className="btn btn-primary" onClick={onExport}>
          <Download size={15} />
          Export
        </button>
      </div>
    </header>
  );
}
