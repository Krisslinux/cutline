import {Composition} from 'remotion';
import {Video} from '../video/Video';
import {DEFAULT_SPEC, totalFrames} from '../lib/spec';
import type {MediaAttachment, VideoSpec} from '../types';

interface RenderProps {
  spec: VideoSpec;
  attachments: MediaAttachment[];
}

const defaultProps: RenderProps = {spec: DEFAULT_SPEC, attachments: []};

export const RemotionRoot = () => (
  <Composition
    id="CutlineVideo"
    component={Video}
    width={defaultProps.spec.meta.width}
    height={defaultProps.spec.meta.height}
    fps={defaultProps.spec.meta.fps}
    durationInFrames={totalFrames(defaultProps.spec)}
    defaultProps={defaultProps}
    calculateMetadata={({props}) => ({
      width: props.spec.meta.width,
      height: props.spec.meta.height,
      fps: props.spec.meta.fps,
      durationInFrames: totalFrames(props.spec),
    })}
  />
);
