import {Composition, registerRoot} from 'remotion';
import {NarrationVideo, type NarrationProps} from '../video/NarrationVideo';
import {draftTimeline} from '../../shared/narration';
const defaults: NarrationProps = {timeline: draftTimeline({title: 'Narration', audioAssetId: 'audio', imageAssets: ['image'], durationMs: 1000, words: []}), assets: {}};
const Root = () => <Composition id="Narration" component={NarrationVideo} defaultProps={defaults} width={720} height={1280} fps={30} durationInFrames={30}
  calculateMetadata={({props}) => ({durationInFrames: props.timeline.durationInFrames, width: 720, height: 1280, fps: 30})} />;
registerRoot(Root);
