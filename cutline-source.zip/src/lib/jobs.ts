import type {MediaAttachment, VideoSpec} from '../types';
import type {TokenUsage} from '../../shared/media';
import {explainStatus, extractDetail} from './api';
import type {AiSettings} from './settings';

export type JobStatus = 'queued' | 'running' | 'done' | 'error' | 'cancelled';

export interface JobStep {
  id: string;
  name: string;
  label: string;
  ok: boolean;
  at: number;
}

export interface JobAttachmentSummary {
  id: string;
  name: string;
  kind: 'image' | 'video' | 'audio';
  mimeType: string;
  durationSeconds?: number;
  frameTimes: number[];
}

export interface JobSnapshot {
  id: string;
  status: JobStatus;
  createdAt: number;
  updatedAt: number;
  rounds: number;
  steps: JobStep[];
  spec: VideoSpec;
  reply: string;
  error?: string;
  changed: boolean;
  queuedAhead: number;
  attachments: JobAttachmentSummary[];
  usage: TokenUsage;
}

export class JobError extends Error {
  status?: number;

  constructor(message: string, status?: number) {
    super(message);
    this.name = 'JobError';
    this.status = status;
  }
}

export const isTerminalStatus = (status: JobStatus): boolean =>
  status === 'done' || status === 'error' || status === 'cancelled';

export async function createJob(input: {
  settings: AiSettings;
  spec: VideoSpec;
  prompt: string;
  history: {role: 'user' | 'assistant'; text: string}[];
  attachments?: MediaAttachment[];
}): Promise<{id: string}> {
  let response: Response;
  try {
    response = await fetch('/api/jobs', {
      method: 'POST',
      headers: {'content-type': 'application/json'},
      body: JSON.stringify({
        baseUrl: input.settings.baseUrl,
        apiKey: input.settings.apiKey,
        model: input.settings.model,
        spec: input.spec,
        prompt: input.prompt,
        history: input.history,
        attachments: input.attachments?.map(({id, name, kind, mimeType, durationSeconds, frames, audioBytes}) => ({
          id,
          name,
          kind,
          mimeType,
          durationSeconds,
          frames,
          ...(audioBytes === undefined ? {} : {audioBytes}),
        })),
      }),
    });
  } catch {
    throw new JobError('Could not reach the editor server. Is it still running?');
  }

  const raw = await response.text();
  let data: unknown = null;
  try {
    data = raw ? JSON.parse(raw) : null;
  } catch {
    data = null;
  }

  if (!response.ok) {
    const detail = extractDetail(data, raw);
    if (response.status === 401 || response.status === 403) {
      throw new JobError(explainStatus(response.status, detail), response.status);
    }
    throw new JobError(detail || `Could not start the edit (${response.status}).`, response.status);
  }

  const id = (data as {id?: unknown} | null)?.id;
  if (typeof id !== 'string') throw new JobError('The server did not return a job id.');
  return {id};
}

export async function fetchJob(id: string): Promise<JobSnapshot | null> {
  try {
    const response = await fetch(`/api/jobs/${encodeURIComponent(id)}`, {headers: {accept: 'application/json'}});
    if (response.status === 404) return null;
    if (!response.ok) return null;
    return (await response.json()) as JobSnapshot;
  } catch {
    return null;
  }
}

export async function cancelJob(id: string): Promise<void> {
  try {
    await fetch(`/api/jobs/${encodeURIComponent(id)}/cancel`, {method: 'POST'});
  } catch {
    /* the watcher will settle the job state */
  }
}

/**
 * Follows a job over SSE, with a polling safety net for proxies that buffer or
 * drop event streams. Returns a stop function.
 */
export function watchJob(
  id: string,
  onSnapshot: (snapshot: JobSnapshot) => void,
  onLost?: (message: string) => void,
): () => void {
  let closed = false;
  const source = new EventSource(`/api/jobs/${encodeURIComponent(id)}/events`);
  let poll: ReturnType<typeof setInterval> | undefined;
  let misses = 0;

  const close = () => {
    if (closed) return;
    closed = true;
    source.close();
    if (poll) clearInterval(poll);
  };

  const receive = (snapshot: JobSnapshot) => {
    if (closed) return;
    onSnapshot(snapshot);
    if (isTerminalStatus(snapshot.status)) close();
  };

  source.onmessage = (event: MessageEvent<string>) => {
    try {
      receive(JSON.parse(event.data) as JobSnapshot);
    } catch {
      /* ignore malformed frames */
    }
  };

  // A finished job closes the stream; if the network dropped before the last
  // event, polling catches up and settles the UI.
  poll = setInterval(async () => {
    const snapshot = await fetchJob(id);
    if (snapshot) {
      misses = 0;
      receive(snapshot);
      return;
    }
    misses += 1;
    // The job was swept or the server restarted under us.
    if (misses >= 2) {
      close();
      onLost?.('This edit was lost when the server restarted. Your last saved cut is still here.');
    }
  }, 5000);

  return close;
}
