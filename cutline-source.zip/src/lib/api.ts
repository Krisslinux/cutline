import type {ChatCompletion, ChatMessage} from '../../shared/chat';
import type {MediaAttachment} from '../types';
import type {AiSettings} from './settings';

export type {ChatCompletion, ChatMessage, ToolCall} from '../../shared/chat';

export class AiError extends Error {
  status?: number;

  constructor(message: string, status?: number) {
    super(message);
    this.name = 'AiError';
    this.status = status;
  }
}

export const explainStatus = (status: number, detail: string): string => {
  if (status === 401 || status === 403) {
    return `The provider rejected this API token (${status}). Check or replace it in Settings, and confirm it belongs to this endpoint. ${detail}`.trim();
  }
  if (status === 402) {
    return `The provider account may need credits or billing attention (402). Check its usage/billing page, or choose another provider. ${detail}`.trim();
  }
  if (status === 404) {
    return `Endpoint or model not found (404). Check the base URL (usually ends in /v1) and model id in Settings. ${detail}`.trim();
  }
  if (status === 429) {
    return `Provider rate limit or account usage limit reached (429). Wait and try again, check provider quota, or choose another provider. ${detail}`.trim();
  }
  if (status === 400) {
    return `The provider rejected the request (400). Check that the model id is correct and that this endpoint supports chat completions. ${detail}`.trim();
  }
  if (status === 500 || status === 502 || status === 503 || status === 504) {
    const networkHint = detail.toLowerCase().includes('could not reach') ? 'Check that the base URL is reachable from the editor server.' : 'Wait a moment and try again; the provider may be temporarily unavailable.';
    return `${networkHint} Provider error (${status}). ${detail}`.trim();
  }
  return detail || `Request failed (${status}). Check your base URL, model id, and provider status.`;
};

export const extractDetail = (data: unknown, raw: string): string => {
  const record = data as {error?: {message?: string} | string; message?: string} | null;
  if (record?.error) {
    if (typeof record.error === 'string') return record.error;
    if (typeof record.error.message === 'string') return record.error.message;
  }
  if (typeof record?.message === 'string') return record.message;
  return raw.slice(0, 500);
};

export async function chatCompletion(
  settings: AiSettings,
  body: {messages: ChatMessage[]; tools?: unknown[]; toolChoice?: unknown; temperature?: number; attachments?: MediaAttachment[]},
  signal?: AbortSignal,
): Promise<ChatCompletion> {
  let response: Response;
  try {
    response = await fetch('/api/chat', {
      method: 'POST',
      headers: {'content-type': 'application/json'},
      body: JSON.stringify({
        baseUrl: settings.baseUrl,
        apiKey: settings.apiKey,
        model: settings.model,
        messages: body.messages,
        tools: body.tools,
        toolChoice: body.toolChoice,
        temperature: body.temperature,
        ...(body.attachments ? {attachments: body.attachments.map(({id, name, kind, mimeType, durationSeconds, frames}) => ({id, name, kind, mimeType, durationSeconds, frames}))} : {}),
      }),
      signal,
    });
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') throw error;
    throw new AiError('Could not reach the editor API route. Is the server still running?');
  }

  const raw = await response.text();
  let data: unknown = null;
  try {
    data = raw ? JSON.parse(raw) : null;
  } catch {
    data = null;
  }

  if (!response.ok) {
    throw new AiError(explainStatus(response.status, extractDetail(data, raw)), response.status);
  }

  const completion = data as ChatCompletion | null;
  if (!completion || typeof completion !== 'object') {
    throw new AiError('The endpoint returned an empty response.');
  }
  if (completion.error) {
    throw new AiError(completion.error.message ?? 'The endpoint returned an error.');
  }
  if (!Array.isArray(completion.choices) || completion.choices.length === 0) {
    throw new AiError('The endpoint returned no choices. Does the model id exist on this provider?');
  }
  return completion;
}

export const verifyToolCallingCompletion = (completion: ChatCompletion): void => {
  const calls = completion.choices?.[0]?.message?.tool_calls;
  if (!calls?.some((call) => call.function?.name === 'cutline_compatibility_check')) {
    throw new AiError('The endpoint replied, but this model did not call the required test tool. Choose a model and endpoint that support OpenAI-compatible function/tool calling.');
  }
};
