export interface AiSettings {
  baseUrl: string;
  apiKey: string;
  model: string;
}

const STORAGE_KEY = 'cutline.settings.v1';

export const DEFAULT_SETTINGS: AiSettings = {
  baseUrl: 'https://api.openai.com/v1',
  apiKey: '',
  model: 'gpt-4.1-mini',
};

export const PROVIDER_PRESETS: {label: string; baseUrl: string; model: string}[] = [
  {label: 'OpenAI', baseUrl: 'https://api.openai.com/v1', model: 'gpt-4.1-mini'},
  {label: 'OpenRouter', baseUrl: 'https://openrouter.ai/api/v1', model: 'anthropic/claude-sonnet-4'},
  {label: 'Groq', baseUrl: 'https://api.groq.com/openai/v1', model: 'llama-3.3-70b-versatile'},
  {label: 'Together AI', baseUrl: 'https://api.together.xyz/v1', model: 'meta-llama/Llama-3.3-70B-Instruct-Turbo'},
  {label: 'Ollama (local)', baseUrl: 'http://localhost:11434/v1', model: 'qwen2.5:14b'},
];

export const isConfigured = (settings: AiSettings): boolean =>
  Boolean(settings.baseUrl.trim() && settings.model.trim() && settings.apiKey.trim());

export function loadSettings(): AiSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {...DEFAULT_SETTINGS};
    const parsed = JSON.parse(raw) as Partial<AiSettings>;
    if (parsed.apiKey) localStorage.setItem(STORAGE_KEY, JSON.stringify({baseUrl: parsed.baseUrl, model: parsed.model}));
    return {
      baseUrl: typeof parsed.baseUrl === 'string' ? parsed.baseUrl : DEFAULT_SETTINGS.baseUrl,
      apiKey: '',
      model: typeof parsed.model === 'string' ? parsed.model : DEFAULT_SETTINGS.model,
    };
  } catch {
    return {...DEFAULT_SETTINGS};
  }
}

export function saveSettings(settings: AiSettings): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({baseUrl: settings.baseUrl, model: settings.model}));
  } catch {
    /* private mode / quota — the editor still works for this session */
  }
}

/** "api.openai.com · gpt-4.1-mini" for the top bar, without leaking the token. */
export function describeEndpoint(settings: AiSettings): string {
  if (!settings.baseUrl.trim()) return 'No endpoint';
  try {
    return new URL(settings.baseUrl).host;
  } catch {
    return settings.baseUrl.replace(/^https?:\/\//, '').split('/')[0] || 'Custom endpoint';
  }
}
