import type {TokenUsage} from '../../shared/media';

export interface UsageDisplay {
  total: string;
  detail: string;
  source: 'provider' | 'unreported';
}

export function formatTokenUsage(usage: TokenUsage): UsageDisplay {
  const total = Math.max(0, Math.floor(usage.totalTokens)).toLocaleString();
  if (!usage.reported) {
    return {total, detail: 'Your endpoint did not report token counts', source: 'unreported'};
  }
  return {
    total,
    detail: `${Math.max(0, Math.floor(usage.inputTokens)).toLocaleString()} input · ${Math.max(0, Math.floor(usage.outputTokens)).toLocaleString()} output`,
    source: 'provider',
  };
}
