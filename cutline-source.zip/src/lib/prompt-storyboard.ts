import {makeScene, setAspect, totalSeconds, DEFAULT_SPEC} from './spec';
import type {AspectRatio, MediaAttachment, Scene, VideoSpec} from '../types';
import {chatCompletion, type ChatMessage} from './api';
import {readTokenUsage} from '../../shared/chat';
import type {TokenUsage} from '../../shared/media';
import type {AiSettings} from './settings';

const MAX_FINAL_SECONDS = 120;
const storyboardSchema = {
  type: 'object',
  additionalProperties: false,
  properties: {
    title: {type: 'string'},
    aspect: {type: 'string', enum: ['16:9', '9:16', '1:1']},
    scenes: {
      type: 'array', minItems: 1, maxItems: 16,
      items: {
        type: 'object', additionalProperties: false,
        properties: {
          kind: {type: 'string', enum: ['title', 'bullets', 'image', 'quote', 'stats', 'outro']},
          sourceId: {type: 'string'}, frameIndex: {type: 'integer', minimum: 0, maximum: 3}, sourceStartSeconds: {type: 'number', minimum: 0}, sourceEndSeconds: {type: 'number', minimum: 0}, keepSourceAudio: {type: 'boolean'},
          headline: {type: 'string'}, kicker: {type: 'string'}, subhead: {type: 'string'},
          durationSeconds: {type: 'number', minimum: 1, maximum: 20},
          animation: {type: 'string', enum: ['fade-up', 'slide', 'scale', 'blur', 'typewriter', 'none']},
          align: {type: 'string', enum: ['left', 'center']},
          items: {type: 'array', items: {type: 'string'}, maxItems: 6},
          quote: {type: 'string'}, author: {type: 'string'}, cta: {type: 'string'},
        },
        required: ['kind', 'durationSeconds'],
      },
    },
  },
  required: ['title', 'aspect', 'scenes'],
};

const systemPrompt = `You are Cutline's video director. Create a coherent 1–2 minute maximum storyboard from the user's brief and uploaded media. Return ONLY a JSON object matching the supplied schema. Use 6–14 scenes when source duration allows. Every source scene must use an exact supplied sourceId and optional valid frameIndex. For video footage select image scenes with sourceId; do not invent source ids, media, dialogue, facts, or quotes. Include readable on-screen text, punchy editing, an opening hook, varied pacing, and a clear ending. User media duration is available; output may use/trim footage but never exceed 120 seconds. Preserve meaningful source audio unless the user requests mute or selects external narration/music, in which case prefer that external audio. Set keepSourceAudio false when the user explicitly requests muted footage. Keep copy concise and in the requested language.`;

function cleanText(value: unknown, max: number): string | undefined {
  if (typeof value !== 'string') return undefined;
  const text = value.replace(/[\u0000-\u001f]/g, '').trim().slice(0, max);
  return text || undefined;
}

export async function createPromptStoryboard(settings: AiSettings, prompt: string, attachments: MediaAttachment[], signal?: AbortSignal): Promise<{spec: VideoSpec; reply: string; usage: TokenUsage}> {
  if (!settings.apiKey.trim()) throw new Error('Add your model API token in Settings before generating a video.');
  if (!prompt.trim()) throw new Error('Describe the video you want first.');
  if (attachments.length < 1) throw new Error('Upload at least one image or video clip to create your video.');
  const visual = attachments.filter((attachment) => attachment.kind !== 'audio');
  if (!visual.length) throw new Error('Add at least one image or video as well as any audio.');
  const audio = attachments.filter((attachment) => attachment.kind === 'audio');
  if (audio.length > 1) throw new Error('Choose one soundtrack or narration file per video.');
  const sourceSeconds = visual.filter((attachment) => attachment.kind === 'video').reduce((sum, attachment) => sum + (attachment.durationSeconds ?? 0), 0);
  const audioSeconds = audio[0]?.durationSeconds ?? 0;
  const capSeconds = Math.min(MAX_FINAL_SECONDS, sourceSeconds || audioSeconds || MAX_FINAL_SECONDS);
  const attachmentNote = attachments.map((item) => ({id: item.id, name: item.name, kind: item.kind, durationSeconds: item.durationSeconds, frames: item.kind === 'audio' ? [] : item.frames.map((frame, index) => ({index, timeSeconds: frame.timeSeconds}))}));
  const messages: ChatMessage[] = [
    {role: 'system', content: systemPrompt},
    {role: 'user', content: `${prompt.trim()}\n\nUploaded media catalog (source IDs are exact): ${JSON.stringify(attachmentNote)}\nHard final duration ceiling: ${capSeconds} seconds. Decide clip order and pacing from this catalog.`},
  ];
  const completion = await chatCompletion(settings, {messages, temperature: 0.45, tools: [{type: 'function', function: {name: 'create_video_storyboard', description: 'Create the complete media edit plan', parameters: storyboardSchema}}], toolChoice: {type: 'function', function: {name: 'create_video_storyboard'}}, attachments: visual}, signal);
  const call = completion.choices?.[0]?.message?.tool_calls?.find((item) => item.function.name === 'create_video_storyboard');
  if (!call) throw new Error('This model did not return the required storyboard tool call. Check tool-calling support in Settings.');
  let raw: unknown;
  try { raw = JSON.parse(call.function.arguments); } catch { throw new Error('The model returned an invalid storyboard. Try a clearer prompt.'); }
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw new Error('The model returned an invalid storyboard.');
  const plan = raw as Record<string, unknown>;
  if (!Array.isArray(plan.scenes) || !plan.scenes.length || plan.scenes.length > 16) throw new Error('The storyboard needs 1–16 scenes.');
  const allowed = new Map(visual.map((item) => [item.id, item]));
  let spec: VideoSpec = {...DEFAULT_SPEC, meta: {...DEFAULT_SPEC.meta, title: cleanText(plan.title, 80) ?? 'AI video'}, scenes: []};
  const aspect = plan.aspect;
  if (aspect === '16:9' || aspect === '9:16' || aspect === '1:1') spec = setAspect(spec, aspect as AspectRatio);
  let remainingFrames = Math.floor(capSeconds * spec.meta.fps);
  const scenes: Scene[] = [];
  for (const item of plan.scenes) {
    if (!item || typeof item !== 'object' || Array.isArray(item)) continue;
    const record = item as Record<string, unknown>;
    const requested = typeof record.durationSeconds === 'number' && Number.isFinite(record.durationSeconds) ? record.durationSeconds : 5;
    let durationSeconds = Math.min(20, Math.max(1, requested));
    if (remainingFrames < spec.meta.fps) break;
    const sourceId = typeof record.sourceId === 'string' ? record.sourceId : '';
    const source = sourceId ? allowed.get(sourceId) : undefined;
    if (sourceId && !source) throw new Error('The storyboard referenced media that was not uploaded. Please try again.');
    const kind = record.kind === 'image' || record.kind === 'bullets' || record.kind === 'quote' || record.kind === 'stats' || record.kind === 'outro' ? record.kind : 'title';
    const startSeconds = typeof record.sourceStartSeconds === 'number' && Number.isFinite(record.sourceStartSeconds) ? Math.max(0, record.sourceStartSeconds) : 0;
    if (source?.kind === 'video') {
      const availableSeconds = (source.durationSeconds ?? 0) - startSeconds;
      if (availableSeconds < 1) throw new Error('The storyboard selected less than one second of video footage. Try again.');
      durationSeconds = Math.min(durationSeconds, availableSeconds);
    }
    const requestedEnd = typeof record.sourceEndSeconds === 'number' && Number.isFinite(record.sourceEndSeconds) ? record.sourceEndSeconds : startSeconds + durationSeconds;
    if (source?.kind === 'video' && (startSeconds >= (source.durationSeconds ?? 0) || requestedEnd <= startSeconds || requestedEnd > (source.durationSeconds ?? 0) + 0.05)) throw new Error('The storyboard requested a trim outside the uploaded clip. Please try again.');
    const endSeconds = Math.max(startSeconds + 0.1, requestedEnd);
    const scene = makeScene(spec, {
      kind: source ? 'image' : kind,
      durationSeconds,
      headline: cleanText(record.headline, 200), kicker: cleanText(record.kicker, 60), subhead: cleanText(record.subhead, 300),
      quote: cleanText(record.quote, 400), author: cleanText(record.author, 120), cta: cleanText(record.cta, 60),
      items: Array.isArray(record.items) ? record.items.map((value) => cleanText(value, 180)).filter(Boolean).slice(0, 6) : undefined,
      animation: record.animation, align: record.align,
      ...(source ? {mediaAttachmentId: source.id, mediaFrameIndex: typeof record.frameIndex === 'number' ? Math.max(0, Math.min(source.frames.length - 1, Math.round(record.frameIndex))) : 0, ...(source.kind === 'video' ? {sourceStartSeconds: startSeconds, sourceEndSeconds: endSeconds} : {})} : {}),
    });
    const durationInFrames = Math.min(scene.durationInFrames, remainingFrames);
    if (durationInFrames < spec.meta.fps) break;
    scenes.push({...scene, durationInFrames});
    spec = {...spec, scenes};
    remainingFrames -= durationInFrames;
  }
  if (!scenes.length) throw new Error('The model did not create any usable scenes. Try again with a more specific prompt.');
  if (audio[0] && audio[0].durationSeconds !== undefined) {
    const soundtrackFrames = Math.floor(Math.min(MAX_FINAL_SECONDS, audio[0].durationSeconds) * spec.meta.fps);
    if (soundtrackFrames < spec.meta.fps) throw new Error('The soundtrack must be at least one second long.');
    const storyboardFrames = scenes.reduce((sum, scene) => sum + scene.durationInFrames, 0);
    if (soundtrackFrames < storyboardFrames) {
      let audioFramesLeft = soundtrackFrames;
      for (let index = 0; index < scenes.length; index += 1) {
        const scene = scenes[index];
        if (audioFramesLeft < spec.meta.fps) {
          scenes.splice(index);
          break;
        }
        if (scene.durationInFrames > audioFramesLeft) {
          scenes[index] = {...scene, durationInFrames: audioFramesLeft};
          scenes.splice(index + 1);
          break;
        }
        audioFramesLeft -= scene.durationInFrames;
      }
    }
  }
  if (audio[0]) {
    scenes[0] = {...scenes[0], audioAttachmentId: audio[0].id};
    for (const scene of scenes) scene.keepSourceAudio = false;
  } else {
    for (const scene of scenes) {
      const source = scene.mediaAttachmentId ? allowed.get(scene.mediaAttachmentId) : undefined;
      if (source?.kind === 'video') {
        const sourcePlan = (plan.scenes as Record<string, unknown>[]).find((item) => item?.sourceId === source.id);
        scene.keepSourceAudio = typeof sourcePlan?.keepSourceAudio === 'boolean' ? sourcePlan.keepSourceAudio : true;
      }
    }
  }
  spec = {...spec, meta: {...spec.meta, title: cleanText(plan.title, 80) ?? 'AI video'}, scenes};
  if (totalSeconds(spec) > MAX_FINAL_SECONDS + 0.1) throw new Error('The storyboard exceeded the two-minute output limit. Try again.');
  const reply = typeof completion.choices?.[0]?.message?.content === 'string' ? completion.choices[0].message.content.trim() : 'I’ve assembled your footage into an AI-directed cut. Review the preview and render the MP4 when ready.';
  return {spec, reply, usage: readTokenUsage(completion)};
}
