import type {MediaAttachment, VideoSpec} from '../types';
import {normalizeSpec} from './spec';

export type RenderStatus = 'uploading' | 'queued' | 'rendering' | 'done' | 'error' | 'cancelled';

export interface RenderSnapshot {
  id: string;
  status: RenderStatus;
  createdAt: number;
  updatedAt: number;
  progress: number;
  stage: string;
  uploadedBytes: number;
  totalBytes: number;
  error?: string;
}

interface RenderMediaDescriptor {
  id: string;
  name: string;
  kind: 'image' | 'video' | 'audio';
  mimeType: string;
  durationSeconds?: number;
  frameTimes: number[];
  size: number;
  audioBytes?: number;
}

const terminal = (status: RenderStatus): boolean => status === 'done' || status === 'error' || status === 'cancelled';

async function parseError(response: Response): Promise<Error> {
  const raw = await response.text();
  try {
    const parsed = JSON.parse(raw) as {error?: {message?: string}};
    return new Error(parsed.error?.message || `Render request failed (${response.status}).`);
  } catch {
    return new Error(raw || `Render request failed (${response.status}).`);
  }
}

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, init);
  if (!response.ok) throw await parseError(response);
  return response.json() as Promise<T>;
}

export async function createRender(
  spec: VideoSpec,
  attachments: MediaAttachment[],
  onSnapshot?: (snapshot: RenderSnapshot) => void,
): Promise<RenderSnapshot> {
  const referenced = new Set(spec.scenes.flatMap((scene) => [scene.mediaAttachmentId, scene.audioAttachmentId]).filter((id): id is string => Boolean(id)));
  const normalized = normalizeSpec(spec);
  if (normalized.scenes.some((scene) => scene.imageUrl && !scene.mediaAttachmentId)) {
    throw new Error('Upload any external image URL as an image attachment before rendering.');
  }
  const media: RenderMediaDescriptor[] = attachments
    .filter((attachment) => referenced.has(attachment.id))
    .map((attachment) => ({
      id: attachment.id,
      name: attachment.name,
      kind: attachment.kind,
      mimeType: attachment.mimeType,
      ...(attachment.durationSeconds === undefined ? {} : {durationSeconds: attachment.durationSeconds}),
      frameTimes: attachment.frames.map(({timeSeconds}) => timeSeconds),
      size: attachment.kind === 'video' ? attachment.videoBlob?.size ?? 0 : attachment.kind === 'audio' ? attachment.audioBlob?.size ?? 0 : attachment.imageBlob?.size ?? 0,
      ...(attachment.kind === 'audio' ? {audioBytes: attachment.audioBytes} : {}),
    }));

  const snapshot = await request<RenderSnapshot>('/api/renders', {
    method: 'POST',
    headers: {'content-type': 'application/json'},      body: JSON.stringify({spec: normalized, media: media.map(({audioBytes: _audioBytes, ...item}) => item)}),
  });
  onSnapshot?.(snapshot);

  let uploadedBytes = 0;
  try {
    for (const item of media) {
      const attachment = attachments.find(({id}) => id === item.id);
      const blob = attachment?.kind === 'video' ? attachment.videoBlob : attachment?.kind === 'audio' ? attachment.audioBlob : attachment?.imageBlob;
      if (!blob) throw new Error(`The original file for ${item.name} is no longer available. Attach it again before rendering.`);
      const upload = new XMLHttpRequest();
      await new Promise<void>((resolve, reject) => {
        upload.open('PUT', `/api/renders/${encodeURIComponent(snapshot.id)}/media/${encodeURIComponent(item.id)}`);
        upload.setRequestHeader('content-type', 'application/octet-stream');
        upload.upload.onprogress = (event) => {
          const current = {...snapshot, uploadedBytes: uploadedBytes + event.loaded, stage: `Uploading ${item.name}…`};
          onSnapshot?.(current);
        };
        upload.onload = () => {
          if (upload.status < 200 || upload.status >= 300) {
            try {
              const body = JSON.parse(upload.responseText) as {error?: {message?: string}};
              reject(new Error(body.error?.message || `Media upload failed (${upload.status}).`));
            } catch {
              reject(new Error(`Media upload failed (${upload.status}).`));
            }
            return;
          }
          try {
            const body = JSON.parse(upload.responseText) as {render?: RenderSnapshot};
            if (body.render) onSnapshot?.(body.render);
          } catch {
            /* the upload is complete; the status poll will reconcile */
          }
          uploadedBytes += blob.size;
          resolve();
        };
        upload.onerror = () => reject(new Error(`Could not upload ${item.name}. Check the connection and try again.`));
        upload.onabort = () => reject(new Error('Media upload was cancelled.'));
        upload.send(blob);
      });
    }

    const queued = await request<RenderSnapshot>(`/api/renders/${encodeURIComponent(snapshot.id)}/start`, {method: 'POST'});
    onSnapshot?.(queued);
    return queued;
  } catch (error) {
    await cancelRender(snapshot.id);
    throw error;
  }
}

export async function fetchRender(id: string): Promise<RenderSnapshot | null> {
  try {
    return await request<RenderSnapshot>(`/api/renders/${encodeURIComponent(id)}`);
  } catch {
    return null;
  }
}

export async function cancelRender(id: string): Promise<void> {
  await fetch(`/api/renders/${encodeURIComponent(id)}/cancel`, {method: 'POST'}).catch(() => undefined);
}

export async function queueRender(id: string): Promise<RenderSnapshot> {
  return request<RenderSnapshot>(`/api/renders/${encodeURIComponent(id)}/start`, {method: 'POST'});
}

export function downloadRender(id: string, filename: string): void {
  const link = document.createElement('a');
  link.href = `/api/renders/${encodeURIComponent(id)}/download`;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
}

export function watchRender(
  id: string,
  onSnapshot: (snapshot: RenderSnapshot) => void,
  onLost: (message: string) => void,
): () => void {
  let closed = false;
  let misses = 0;
  let poll: ReturnType<typeof setInterval>;
  const source = new EventSource(`/api/renders/${encodeURIComponent(id)}/events`);
  const close = () => {
    if (closed) return;
    closed = true;
    source.close();
    if (poll) clearInterval(poll);
  };
  const receive = (snapshot: RenderSnapshot) => {
    if (closed) return;
    onSnapshot(snapshot);
    if (terminal(snapshot.status)) close();
  };
  source.onmessage = (event: MessageEvent<string>) => {
    try {
      receive(JSON.parse(event.data) as RenderSnapshot);
    } catch {
      /* ignore malformed events */
    }
  };
  poll = setInterval(async () => {
    const snapshot = await fetchRender(id);
    if (snapshot) {
      misses = 0;
      receive(snapshot);
    } else if (++misses >= 2) {
      close();
      onLost('This render expired or the server restarted before it finished.');
    }
  }, 5000);
  return close;
}
