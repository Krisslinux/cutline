import {
  MAX_FRAMES_PER_ATTACHMENT,
  MAX_MEDIA_ATTACHMENTS,
  type AttachmentFrame,
  type MediaAttachment,
} from '../../shared/media';

const IMAGE_MAX_BYTES = 30 * 1024 * 1024;
const VIDEO_MAX_BYTES = 500 * 1024 * 1024;
const AUDIO_MAX_BYTES = 200 * 1024 * 1024;
const MAX_SOURCE_DURATION_SECONDS = 120;
const MAX_SIDE = 768;
const JPEG_QUALITY = 0.68;
const METADATA_TIMEOUT_MS = 30_000;
const SEEK_TIMEOUT_MS = 15_000;

const extension = (name: string): string => name.split('.').pop()?.toLowerCase() ?? '';

const loadImage = (url: string): Promise<HTMLImageElement> =>
  new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('Could not read that image. Try a JPG, PNG, or WebP file.'));
    image.src = url;
  });

const drawJpeg = (source: CanvasImageSource, width: number, height: number): string => {
  const ratio = Math.min(1, MAX_SIDE / Math.max(width, height));
  const outputWidth = Math.max(1, Math.round(width * ratio));
  const outputHeight = Math.max(1, Math.round(height * ratio));
  const canvas = document.createElement('canvas');
  canvas.width = outputWidth;
  canvas.height = outputHeight;
  const context = canvas.getContext('2d', {alpha: false});
  if (!context) throw new Error('This browser cannot prepare image attachments.');
  context.fillStyle = '#111111';
  context.fillRect(0, 0, outputWidth, outputHeight);
  context.drawImage(source, 0, 0, outputWidth, outputHeight);
  return canvas.toDataURL('image/jpeg', JPEG_QUALITY);
};

const imageAttachment = async (file: File, id: string): Promise<MediaAttachment> => {
  if (file.size > IMAGE_MAX_BYTES) throw new Error(`${file.name} is over 30 MB. Choose a smaller image.`);
  const url = URL.createObjectURL(file);
  try {
    const image = await loadImage(url);
    const dataUrl = drawJpeg(image, image.naturalWidth, image.naturalHeight);
    const frame: AttachmentFrame = {timeSeconds: 0, dataUrl};
    return {id, name: file.name, kind: 'image', mimeType: file.type || `image/${extension(file.name)}`, frames: [frame], imageBlob: file};
  } finally {
    URL.revokeObjectURL(url);
  }
};

const waitForVideoEvent = (
  video: HTMLVideoElement,
  eventName: 'loadedmetadata' | 'seeked',
  timeoutMs: number,
): Promise<void> =>
  new Promise((resolve, reject) => {
    const timeout = window.setTimeout(() => {
      cleanup();
      reject(new Error(eventName === 'loadedmetadata' ? 'Timed out reading the video.' : 'Timed out extracting a video frame.'));
    }, timeoutMs);
    const onReady = () => {
      cleanup();
      resolve();
    };
    const onError = () => {
      cleanup();
      reject(new Error('Could not read that video. Try an MP4 or WebM file.'));
    };
    const cleanup = () => {
      window.clearTimeout(timeout);
      video.removeEventListener(eventName, onReady);
      video.removeEventListener('error', onError);
    };
    video.addEventListener(eventName, onReady, {once: true});
    video.addEventListener('error', onError, {once: true});
  });

const captureVideoFrame = async (video: HTMLVideoElement, timeSeconds: number): Promise<AttachmentFrame> => {
  const seeked = waitForVideoEvent(video, 'seeked', SEEK_TIMEOUT_MS);
  video.currentTime = timeSeconds;
  await seeked;
  const dataUrl = drawJpeg(video, video.videoWidth, video.videoHeight);
  return {timeSeconds, dataUrl};
};

const audioAttachment = async (file: File, id: string): Promise<MediaAttachment> => {
  if (file.size > AUDIO_MAX_BYTES) throw new Error(`${file.name} is over 200 MB. Choose a smaller audio file.`);
  const url = URL.createObjectURL(file);
  const audio = document.createElement('audio');
  audio.preload = 'metadata';
  audio.src = url;
  try {
    await waitForVideoEvent(audio as unknown as HTMLVideoElement, 'loadedmetadata', METADATA_TIMEOUT_MS);
    const duration = audio.duration;
    if (!Number.isFinite(duration) || duration <= 0) throw new Error(`${file.name} has no readable audio duration.`);
    if (duration > MAX_SOURCE_DURATION_SECONDS) throw new Error(`${file.name} is over 2 minutes. Choose a shorter soundtrack.`);
    const placeholder = document.createElement('canvas');
    placeholder.width = 2;
    placeholder.height = 2;
    const context = placeholder.getContext('2d');
    if (!context) throw new Error('This browser cannot prepare audio attachments.');
    context.fillStyle = '#111111';
    context.fillRect(0, 0, 2, 2);
    const frame: AttachmentFrame = {timeSeconds: 0, dataUrl: placeholder.toDataURL('image/jpeg', 0.4)};
    return {id, name: file.name, kind: 'audio', mimeType: file.type || `audio/${extension(file.name)}`, durationSeconds: duration, frames: [frame], audioSrc: url, audioBlob: file, audioBytes: file.size};
  } finally {
    audio.pause();
    audio.removeAttribute('src');
    audio.load();
  }
};

const videoAttachment = async (file: File, id: string): Promise<MediaAttachment> => {
  if (file.size > VIDEO_MAX_BYTES) throw new Error(`${file.name} is over 500 MB. Choose a shorter or smaller video.`);
  const url = URL.createObjectURL(file);
  const video = document.createElement('video');
  video.preload = 'metadata';
  video.muted = true;
  video.playsInline = true;
  video.src = url;

  try {
    await waitForVideoEvent(video, 'loadedmetadata', METADATA_TIMEOUT_MS);
    const duration = video.duration;
    if (!Number.isFinite(duration) || duration <= 0) throw new Error(`${file.name} has no readable video duration.`);
    if (duration > MAX_SOURCE_DURATION_SECONDS) throw new Error(`${file.name} is over 2 minutes. Shorten it before uploading.`);
    const count = Math.min(MAX_FRAMES_PER_ATTACHMENT, Math.max(1, Math.ceil(duration / 12)));
    const times = count === 1 ? [Math.min(0.1, duration / 2)] : Array.from({length: count}, (_, i) => duration * ((i + 0.5) / count));
    const frames: AttachmentFrame[] = [];
    for (const time of times) {
      frames.push(await captureVideoFrame(video, Math.min(Math.max(0, duration - 0.05), time)));
    }
    return {
      id,
      name: file.name,
      kind: 'video',
      mimeType: file.type || `video/${extension(file.name)}`,
      durationSeconds: duration,
      frames,
      videoSrc: url,
      videoBlob: file,
    };
  } finally {
    video.pause();
    video.removeAttribute('src');
    video.load();
  }
};

export async function prepareMediaFiles(files: File[], existingCount = 0): Promise<MediaAttachment[]> {
  const available = Math.max(0, MAX_MEDIA_ATTACHMENTS - existingCount);
  if (!available) throw new Error(`Attach up to ${MAX_MEDIA_ATTACHMENTS} files per edit.`);
  if (files.length > available) throw new Error(`You can attach ${available} more file${available === 1 ? '' : 's'}.`);

  const attachments: MediaAttachment[] = [];
  for (const file of files) {
    const id = crypto.randomUUID().replaceAll('-', '');
    if (file.type.startsWith('image/') || /\.(jpe?g|png|webp|gif|avif)$/i.test(file.name)) {
      attachments.push(await imageAttachment(file, id));
    } else if (file.type.startsWith('video/') || /\.(mp4|m4v|mov|webm|ogv)$/i.test(file.name)) {
      attachments.push(await videoAttachment(file, id));
    } else if (file.type.startsWith('audio/') || /\.(mp3|wav|m4a|aac|ogg|opus|flac)$/i.test(file.name)) {
      attachments.push(await audioAttachment(file, id));
    } else {
      throw new Error(`${file.name} is not a supported image, video, or audio file.`);
    }
  }
  return attachments;
}
