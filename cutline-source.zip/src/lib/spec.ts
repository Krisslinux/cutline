import {
  ASPECT_PRESETS,
  FONT_STYLES,
  SCENE_ALIGNS,
  SCENE_ANIMATIONS,
  SCENE_KINDS,
  type AspectRatio,
  type FontStyle,
  type Scene,
  type SceneAlign,
  type SceneAnimation,
  type SceneKind,
  type Stat,
  type VideoSpec,
} from '../types.ts';

export const MIN_SCENE_SECONDS = 1;
export const MAX_SCENE_SECONDS = 20;
export const MAX_SCENES = 16;
export const DEFAULT_FPS = 30;

export const DEFAULT_SPEC: VideoSpec = {
  version: 1,
  meta: {title: 'Untitled cut', aspect: '16:9', fps: DEFAULT_FPS, width: 1920, height: 1080},
  theme: {
    background: '#0b0b0c',
    text: '#f5f1e8',
    accent: '#ff5c39',
    muted: '#948e82',
    font: 'sans',
  },
  scenes: [
    {
      id: 'sc_1',
      kind: 'title',
      durationInFrames: 120,
      kicker: 'Cutline / AI editor',
      headline: 'Edit video like you edit code',
      subhead: 'A Remotion timeline your AI agent can actually operate.',
      animation: 'fade-up',
      align: 'left',
    },
    {
      id: 'sc_2',
      kind: 'bullets',
      durationInFrames: 150,
      kicker: 'Under the hood',
      headline: 'Built on Remotion',
      items: [
        'React components, rendered frame-perfect',
        'Live preview while the model edits',
        'Export a project you actually own',
      ],
      animation: 'slide',
      align: 'left',
    },
    {
      id: 'sc_3',
      kind: 'stats',
      durationInFrames: 120,
      kicker: 'One spec, three payoffs',
      stats: [
        {value: '01', label: 'JSON spec'},
        {value: '02', label: 'Live player'},
        {value: '03', label: 'MP4 render'},
      ],
      animation: 'fade-up',
      align: 'left',
    },
    {
      id: 'sc_4',
      kind: 'quote',
      durationInFrames: 120,
      quote: 'The edit is the idea.',
      author: 'Cutline manifesto',
      animation: 'blur',
      align: 'center',
    },
    {
      id: 'sc_5',
      kind: 'outro',
      durationInFrames: 120,
      kicker: 'Bring your own model',
      headline: 'Point it at any endpoint',
      subhead: 'Base URL, token, model id. Nothing leaves your browser.',
      cta: 'Start editing',
      animation: 'scale',
      align: 'center',
    },
  ],
};

export const clamp = (value: number, min: number, max: number): number =>
  Number.isFinite(value) ? Math.min(max, Math.max(min, value)) : min;

export const totalFrames = (spec: VideoSpec): number =>
  Math.max(1, spec.scenes.reduce((sum, scene) => sum + scene.durationInFrames, 0));

export const totalSeconds = (spec: VideoSpec): number => totalFrames(spec) / spec.meta.fps;

export const sceneOffsets = (spec: VideoSpec): number[] => {
  let cursor = 0;
  return spec.scenes.map((scene) => {
    const start = cursor;
    cursor += scene.durationInFrames;
    return start;
  });
};

export const sceneStartFrame = (spec: VideoSpec, sceneId: string): number => {
  const index = spec.scenes.findIndex((scene) => scene.id === sceneId);
  if (index < 0) return 0;
  return sceneOffsets(spec)[index];
};

export const formatTimecode = (frames: number, fps: number): string => {
  const safeFps = fps || DEFAULT_FPS;
  const seconds = Math.max(0, frames) / safeFps;
  const whole = Math.floor(seconds);
  const tenths = Math.floor((seconds - whole) * 10);
  return `${String(Math.floor(whole / 60)).padStart(2, '0')}:${String(whole % 60).padStart(2, '0')}.${tenths}`;
};

export const slugify = (value: string): string =>
  value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 48) || 'cutline-project';

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

const asString = (value: unknown): string | undefined => {
  if (typeof value === 'string') {
    const trimmed = value.trim();
    return trimmed.length ? trimmed.slice(0, 600) : undefined;
  }
  if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  return undefined;
};

const asColor = (value: unknown): string | undefined => {
  const raw = asString(value);
  if (!raw || raw.length > 120) return undefined;
  if (/url\(|<|>|;|expression/i.test(raw)) return undefined;
  return raw;
};

const asAspect = (value: unknown): AspectRatio =>
  value === '9:16' || value === '1:1' || value === '16:9' ? value : '16:9';

const asKind = (value: unknown): SceneKind =>
  SCENE_KINDS.includes(value as SceneKind) ? (value as SceneKind) : 'title';

const asFont = (value: unknown): FontStyle =>
  FONT_STYLES.includes(value as FontStyle) ? (value as FontStyle) : 'sans';

const asAnimation = (value: unknown): SceneAnimation =>
  SCENE_ANIMATIONS.includes(value as SceneAnimation) ? (value as SceneAnimation) : 'fade-up';

const asAlign = (value: unknown): SceneAlign =>
  SCENE_ALIGNS.includes(value as SceneAlign) ? (value as SceneAlign) : 'left';

const asStats = (value: unknown): Stat[] | undefined => {
  if (!Array.isArray(value)) return undefined;
  const stats = value
    .map((entry) => {
      if (!isRecord(entry)) return null;
      const statValue = asString(entry.value);
      const label = asString(entry.label);
      if (!statValue && !label) return null;
      return {value: statValue ?? '', label: label ?? ''};
    })
    .filter((entry): entry is Stat => entry !== null)
    .slice(0, 4);
  return stats.length ? stats : undefined;
};

const asItems = (value: unknown): string[] | undefined => {
  if (!Array.isArray(value)) return undefined;
  const items = value.map(asString).filter((item): item is string => Boolean(item)).slice(0, 6);
  return items.length ? items : undefined;
};

export const normalizeScene = (raw: unknown, index = 0, fps = DEFAULT_FPS): Scene => {
  const record = isRecord(raw) ? raw : {};
  const kind = asKind(record.kind);
  const secondsRaw = typeof record.durationSeconds === 'number' ? record.durationSeconds : undefined;
  const framesRaw = typeof record.durationInFrames === 'number' ? record.durationInFrames : undefined;
  const frames =
    framesRaw ??
    (secondsRaw !== undefined ? Math.round(clamp(secondsRaw, MIN_SCENE_SECONDS, MAX_SCENE_SECONDS) * fps) : undefined);

  const scene: Scene = {
    id: asString(record.id)?.replace(/[^a-zA-Z0-9_]/g, '').slice(0, 24) || `sc_${index + 1}`,
    kind,
    durationInFrames: Math.round(clamp(frames ?? 120, MIN_SCENE_SECONDS * fps, MAX_SCENE_SECONDS * fps)),
    animation: asAnimation(record.animation),
    align: asAlign(record.align),
  };

  const kicker = asString(record.kicker);
  const headline = asString(record.headline);
  const subhead = asString(record.subhead);
  const imageUrl = asString(record.imageUrl);
  const mediaAttachmentId = asString(record.mediaAttachmentId)?.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  const mediaFrameIndex = typeof record.mediaFrameIndex === 'number' ? Math.round(clamp(record.mediaFrameIndex, 0, 3)) : undefined;
  const audioAttachmentId = asString(record.audioAttachmentId)?.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  const sourceStartSeconds = typeof record.sourceStartSeconds === 'number' && Number.isFinite(record.sourceStartSeconds) ? Math.max(0, record.sourceStartSeconds) : undefined;
  const sourceEndSeconds = typeof record.sourceEndSeconds === 'number' && Number.isFinite(record.sourceEndSeconds) ? Math.max(0, record.sourceEndSeconds) : undefined;
  const quote = asString(record.quote);
  const author = asString(record.author);
  const cta = asString(record.cta);
  const background = asColor(record.background);
  const textColor = asColor(record.textColor);
  const accent = asColor(record.accent);
  const items = asItems(record.items);
  const stats = asStats(record.stats);

  if (kicker) scene.kicker = kicker;
  if (headline) scene.headline = headline;
  if (subhead) scene.subhead = subhead;
  if (imageUrl) scene.imageUrl = imageUrl;
  if (mediaAttachmentId) scene.mediaAttachmentId = mediaAttachmentId;
  if (mediaFrameIndex !== undefined) scene.mediaFrameIndex = mediaFrameIndex;
  if (audioAttachmentId) scene.audioAttachmentId = audioAttachmentId;
  if (sourceStartSeconds !== undefined) scene.sourceStartSeconds = sourceStartSeconds;
  if (sourceEndSeconds !== undefined) scene.sourceEndSeconds = sourceEndSeconds;
  if (typeof record.keepSourceAudio === 'boolean') scene.keepSourceAudio = record.keepSourceAudio;
  if (quote) scene.quote = quote;
  if (author) scene.author = author;
  if (cta) scene.cta = cta;
  if (background) scene.background = background;
  if (textColor) scene.textColor = textColor;
  if (accent) scene.accent = accent;
  if (items) scene.items = items;
  if (stats) scene.stats = stats;

  return scene;
};

const uniqueSceneId = (spec: VideoSpec, seed?: string): string => {
  const base =
    (seed ?? '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '_')
      .replace(/^_+|_+$/g, '')
      .slice(0, 16) || 'sc';
  let candidate = base.startsWith('sc_') ? base : `sc_${base}`;
  let counter = 2;
  const taken = new Set(spec.scenes.map((scene) => scene.id));
  while (taken.has(candidate)) {
    candidate = `sc_${base.replace(/^sc_?/, '')}_${counter++}`;
  }
  return candidate;
};

export const makeScene = (spec: VideoSpec, raw: unknown): Scene => {
  const scene = normalizeScene({...((isRecord(raw) ? raw : {}) as Record<string, unknown>), id: undefined}, 0, spec.meta.fps);
  const record = isRecord(raw) ? raw : {};
  const providedId = asString(record.id);
  const seed = providedId ?? asString(record.headline) ?? scene.kind;
  scene.id = uniqueSceneId(spec, seed);
  return scene;
};

export const normalizeSpec = (raw: unknown): VideoSpec => {
  const record = isRecord(raw) ? raw : {};
  const meta = isRecord(record.meta) ? record.meta : {};
  const theme = isRecord(record.theme) ? record.theme : {};

  const aspect = asAspect(meta.aspect);
  const preset = ASPECT_PRESETS[aspect];
  const width = Math.round(clamp(Number(meta.width) || preset.width, 320, 4096));
  const height = Math.round(clamp(Number(meta.height) || preset.height, 320, 4096));
  const fps = Math.round(clamp(Number(meta.fps) || DEFAULT_FPS, 12, 60));

  const scenesRaw = Array.isArray(record.scenes) ? record.scenes : [];
  const scenes = scenesRaw.slice(0, MAX_SCENES).map((scene, index) => normalizeScene(scene, index, fps));

  const spec: VideoSpec = {
    version: 1,
    meta: {
      title: asString(meta.title)?.slice(0, 80) ?? 'Untitled cut',
      aspect,
      fps,
      width,
      height,
    },
    theme: {
      background: asColor(theme.background) ?? DEFAULT_SPEC.theme.background,
      text: asColor(theme.text) ?? DEFAULT_SPEC.theme.text,
      accent: asColor(theme.accent) ?? DEFAULT_SPEC.theme.accent,
      muted: asColor(theme.muted) ?? DEFAULT_SPEC.theme.muted,
      font: asFont(theme.font),
    },
    scenes: scenes.length ? scenes : DEFAULT_SPEC.scenes.map((scene) => ({...scene})),
  };

  return spec;
};

export const setAspect = (spec: VideoSpec, aspect: AspectRatio): VideoSpec => {
  const preset = ASPECT_PRESETS[aspect];
  return {...spec, meta: {...spec.meta, aspect, width: preset.width, height: preset.height}};
};
