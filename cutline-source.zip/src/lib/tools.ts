import {
  FONT_STYLES,
  SCENE_ALIGNS,
  SCENE_ANIMATIONS,
  SCENE_KINDS,
  type FontStyle,
  type Scene,
  type SceneAlign,
  type SceneAnimation,
  type SceneKind,
  type VideoSpec,
} from '../types.ts';
import {
  MAX_SCENES,
  MAX_SCENE_SECONDS,
  MIN_SCENE_SECONDS,
  clamp,
  makeScene,
  normalizeScene,
  normalizeSpec,
  setAspect,
  totalSeconds,
} from './spec.ts';

export interface ToolDefinition {
  type: 'function';
  function: {
    name: string;
    description: string;
    parameters: {
      type: 'object';
      properties: Record<string, unknown>;
      required?: string[];
    };
  };
}

export interface ToolOutcome {
  spec: VideoSpec;
  ok: boolean;
  message: string;
}

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null && !Array.isArray(value);

const text = (value: unknown, max = 600): string | undefined => {
  if (typeof value === 'string') {
    const trimmed = value.trim();
    return trimmed ? trimmed.slice(0, max) : undefined;
  }
  if (typeof value === 'number' && Number.isFinite(value)) return String(value);
  return undefined;
};

const color = (value: unknown): string | undefined => {
  const raw = text(value, 120);
  if (!raw) return undefined;
  if (/url\(|expression|<|>|;/i.test(raw)) return undefined;
  return raw;
};

const listOfText = (value: unknown, max: number): string[] | undefined => {
  if (!Array.isArray(value)) return undefined;
  const items = value.map((entry) => text(entry, 220)).filter((entry): entry is string => Boolean(entry));
  return items.slice(0, max);
};

const sceneFieldProperties = {
  kind: {
    type: 'string',
    enum: SCENE_KINDS,
    description:
      'title = big statement, bullets = list of points, image = full-bleed image with caption, quote = pull quote, stats = 2-4 big numbers, outro = closing call to action.',
  },
  kicker: {type: 'string', description: 'Small uppercase label above the headline. 1-3 words.'},
  headline: {type: 'string', description: 'The main line. Short and concrete, ideally under 8 words.'},
  subhead: {type: 'string', description: 'One supporting sentence. Optional.'},
  items: {type: 'array', items: {type: 'string'}, description: 'Bullet points (bullets scenes only). Max 6.'},
  stats: {
    type: 'array',
    description: 'Big numbers (stats scenes only). Max 4.',
    items: {
      type: 'object',
      properties: {
        value: {type: 'string', description: 'Short value, e.g. "3x" or "60fps".'},
        label: {type: 'string', description: 'Lowercase label under the value.'},
      },
      required: ['value', 'label'],
    },
  },
  imageUrl: {type: 'string', description: 'Public https image URL (image scenes only).'},
  mediaAttachmentId: {type: 'string', description: 'Exact id of one of the user attachments listed in the prompt; use this to place their image or video in an image scene.'},
  mediaFrameIndex: {type: 'integer', minimum: 0, maximum: 3, description: 'For an attached video, select which supplied still frame to show (0-based).'},
  quote: {type: 'string', description: 'Quote text (quote scenes only).'},
  author: {type: 'string', description: 'Quote attribution.'},
  cta: {type: 'string', description: 'Button label (outro scenes only).'},
  durationSeconds: {
    type: 'number',
    description: `How long the scene is on screen, in seconds (${MIN_SCENE_SECONDS}-${MAX_SCENE_SECONDS}).`,
  },
  animation: {type: 'string', enum: SCENE_ANIMATIONS, description: 'Entrance animation.'},
  align: {type: 'string', enum: SCENE_ALIGNS, description: 'Text alignment.'},
  background: {type: 'string', description: 'CSS background for this scene only (colour or gradient).'},
  textColor: {type: 'string', description: 'Override the text colour for this scene.'},
  accent: {type: 'string', description: 'Override the accent colour for this scene.'},
};

const themeProperties = {
  background: {type: 'string', description: 'Canvas background (hex or CSS gradient).'},
  text: {type: 'string', description: 'Primary text colour (hex).'},
  accent: {type: 'string', description: 'Accent colour used for rules, dots and buttons (hex).'},
  muted: {type: 'string', description: 'Secondary text colour (hex).'},
  font: {type: 'string', enum: FONT_STYLES, description: 'Supporting typeface. Headlines are always serif.'},
};

export const TOOL_DEFINITIONS: ToolDefinition[] = [
  {
    type: 'function',
    function: {
      name: 'get_spec',
      description: 'Read the current video spec, including scene ids and positions. Use it when you need exact ids.',
      parameters: {type: 'object', properties: {}},
    },
  },
  {
    type: 'function',
    function: {
      name: 'set_format',
      description: 'Set the canvas aspect ratio and optional project title. Use 9:16 for vertical social, 16:9 for web.',
      parameters: {
        type: 'object',
        properties: {
          aspect: {type: 'string', enum: ['16:9', '9:16', '1:1']},
          title: {type: 'string', description: 'Project title shown in the editor.'},
        },
        required: ['aspect'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'set_theme',
      description: 'Change the global palette and supporting typeface. Set once, then keep it consistent.',
      parameters: {type: 'object', properties: themeProperties},
    },
  },
  {
    type: 'function',
    function: {
      name: 'add_scene',
      description: 'Add a new scene to the timeline. Every video should start with a title and end with an outro.',
      parameters: {
        type: 'object',
        properties: {
          index: {type: 'number', description: 'Zero-based insert position. Omit to append at the end.'},
          ...sceneFieldProperties,
        },
        required: ['kind'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'update_scene',
      description: 'Change the content, timing or styling of one scene. Send only the fields that change.',
      parameters: {
        type: 'object',
        properties: {
          id: {type: 'string', description: 'Scene id, e.g. "sc_2".'},
          ...sceneFieldProperties,
        },
        required: ['id'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'remove_scene',
      description: 'Delete one scene from the timeline.',
      parameters: {
        type: 'object',
        properties: {id: {type: 'string', description: 'Scene id to delete.'}},
        required: ['id'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'move_scene',
      description: 'Reorder a scene.',
      parameters: {
        type: 'object',
        properties: {
          id: {type: 'string', description: 'Scene id to move.'},
          position: {type: 'number', description: 'One-based destination position, e.g. 1 moves it to the front.'},
        },
        required: ['id', 'position'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'replace_spec',
      description:
        'Rewrite the whole video in one call. Use for a total restyle or a fresh storyboard; otherwise prefer the smaller tools.',
      parameters: {
        type: 'object',
        properties: {
          scenes: {
            type: 'array',
            description: 'The complete, ordered list of scenes (2-8 scenes).',
            items: {
              type: 'object',
              properties: sceneFieldProperties,
              required: ['kind'],
            },
          },
          theme: {type: 'object', properties: themeProperties, description: 'Optional new palette.'},
          title: {type: 'string', description: 'Optional new project title.'},
        },
        required: ['scenes'],
      },
    },
  },
];

const clampSceneFrames = (spec: VideoSpec, frames: number): number =>
  Math.round(clamp(frames, MIN_SCENE_SECONDS * spec.meta.fps, MAX_SCENE_SECONDS * spec.meta.fps));

const findScene = (spec: VideoSpec, id: string | undefined): {scene: Scene; index: number} | null => {
  if (!id) return null;
  const index = spec.scenes.findIndex((scene) => scene.id === id);
  if (index < 0) return null;
  return {scene: spec.scenes[index], index};
};

const sceneList = (spec: VideoSpec): string =>
  spec.scenes.map((scene, index) => `${index + 1}. ${scene.id} (${scene.kind})`).join(', ') || 'none';

const applyPatch = (spec: VideoSpec, scene: Scene, args: Record<string, unknown>): Scene => {
  const next: Scene = {...scene};
  const setOrClear = <K extends keyof Scene>(key: K, value: unknown, clean: (raw: unknown) => Scene[K] | undefined) => {
    if (value === undefined) return;
    if (value === null || value === '') {
      delete next[key];
      return;
    }
    const cleaned = clean(value);
    if (cleaned !== undefined) next[key] = cleaned;
  };

  setOrClear('kicker', args.kicker, (raw) => text(raw, 60));
  setOrClear('headline', args.headline, (raw) => text(raw, 200));
  setOrClear('subhead', args.subhead, (raw) => text(raw, 300));
  setOrClear('imageUrl', args.imageUrl, (raw) => text(raw, 800));
  setOrClear('mediaAttachmentId', args.mediaAttachmentId, (raw) => text(raw, 80));
  if (typeof args.mediaFrameIndex === 'number' && Number.isFinite(args.mediaFrameIndex)) {
    next.mediaFrameIndex = Math.round(clamp(args.mediaFrameIndex, 0, 3));
  }
  setOrClear('quote', args.quote, (raw) => text(raw, 400));
  setOrClear('author', args.author, (raw) => text(raw, 120));
  setOrClear('cta', args.cta, (raw) => text(raw, 60));
  setOrClear('background', args.background, color);
  setOrClear('textColor', args.textColor, color);
  setOrClear('accent', args.accent, color);
  setOrClear('items', args.items, (raw) => listOfText(raw, 6));
  setOrClear('stats', args.stats, (raw) => {
    if (!Array.isArray(raw)) return undefined;
    const stats = raw
      .map((entry) => {
        if (!isRecord(entry)) return null;
        const value = text(entry.value, 20);
        const label = text(entry.label, 40);
        if (!value && !label) return null;
        return {value: value ?? '', label: label ?? ''};
      })
      .filter((entry): entry is {value: string; label: string} => entry !== null)
      .slice(0, 4);
    return stats.length ? stats : undefined;
  });

  if (typeof args.kind === 'string' && SCENE_KINDS.includes(args.kind as SceneKind)) {
    next.kind = args.kind as SceneKind;
  }
  if (typeof args.animation === 'string' && SCENE_ANIMATIONS.includes(args.animation as SceneAnimation)) {
    next.animation = args.animation as SceneAnimation;
  }
  if (typeof args.align === 'string' && SCENE_ALIGNS.includes(args.align as SceneAlign)) {
    next.align = args.align as SceneAlign;
  }
  if (typeof args.durationSeconds === 'number') {
    next.durationInFrames = clampSceneFrames(spec, args.durationSeconds * spec.meta.fps);
  }
  if (typeof args.durationInFrames === 'number') {
    next.durationInFrames = clampSceneFrames(spec, args.durationInFrames);
  }

  return next;
};

const ok = (spec: VideoSpec, message: string): ToolOutcome => ({spec, ok: true, message});
const fail = (spec: VideoSpec, message: string): ToolOutcome => ({spec, ok: false, message});

export function applyTool(spec: VideoSpec, name: string, args: Record<string, unknown>): ToolOutcome {
  switch (name) {
    case 'get_spec':
      return ok(spec, 'Current spec returned.');

    case 'set_format': {
      const aspect = args.aspect;
      if (aspect !== '16:9' && aspect !== '9:16' && aspect !== '1:1') {
        return fail(spec, 'aspect must be one of 16:9, 9:16, 1:1.');
      }
      let next = setAspect(spec, aspect);
      const title = text(args.title, 80);
      if (title) next = {...next, meta: {...next.meta, title}};
      return ok(next, `Canvas set to ${aspect} (${next.meta.width}x${next.meta.height}).`);
    }

    case 'set_theme': {
      const theme = {...spec.theme};
      let touched = false;
      for (const key of ['background', 'text', 'accent', 'muted'] as const) {
        if (args[key] === undefined) continue;
        const value = color(args[key]);
        if (!value) return fail(spec, `${key} must be a CSS colour such as #111111.`);
        theme[key] = value;
        touched = true;
      }
      if (typeof args.font === 'string') {
        if (!FONT_STYLES.includes(args.font as FontStyle)) {
          return fail(spec, 'font must be one of sans, serif, mono.');
        }
        theme.font = args.font as FontStyle;
        touched = true;
      }
      if (!touched) return fail(spec, 'No theme values were provided.');
      return ok(
        {...spec, theme},
        `Theme updated (background ${theme.background}, text ${theme.text}, accent ${theme.accent}, font ${theme.font}).`,
      );
    }

    case 'add_scene': {
      if (spec.scenes.length >= MAX_SCENES) {
        return fail(spec, `The timeline already has the maximum of ${MAX_SCENES} scenes.`);
      }
      const scene = makeScene(spec, args);
      scene.durationInFrames = clampSceneFrames(spec, scene.durationInFrames);
      const requested = typeof args.index === 'number' ? args.index : spec.scenes.length;
      const index = Math.round(clamp(requested, 0, spec.scenes.length));
      const scenes = [...spec.scenes];
      scenes.splice(index, 0, scene);
      return ok({...spec, scenes}, `Added ${scene.kind} scene ${scene.id} at position ${index + 1} of ${scenes.length}.`);
    }

    case 'update_scene': {
      const found = findScene(spec, text(args.id, 40));
      if (!found) return fail(spec, `No scene with that id. Current scenes: ${sceneList(spec)}.`);
      const nextScene = applyPatch(spec, found.scene, args);
      const scenes = spec.scenes.map((scene, index) => (index === found.index ? nextScene : scene));
      return ok({...spec, scenes}, `Updated scene ${nextScene.id} (${nextScene.kind}).`);
    }

    case 'remove_scene': {
      const found = findScene(spec, text(args.id, 40));
      if (!found) return fail(spec, `No scene with that id. Current scenes: ${sceneList(spec)}.`);
      if (spec.scenes.length <= 1) return fail(spec, 'A video needs at least one scene.');
      const scenes = spec.scenes.filter((_, index) => index !== found.index);
      return ok({...spec, scenes}, `Removed scene ${found.scene.id}. ${scenes.length} scenes remain.`);
    }

    case 'move_scene': {
      const found = findScene(spec, text(args.id, 40));
      if (!found) return fail(spec, `No scene with that id. Current scenes: ${sceneList(spec)}.`);
      const rawPosition = Number(args.position);
      if (!Number.isFinite(rawPosition)) return fail(spec, 'position must be a one-based number.');
      const target = Math.round(clamp(rawPosition, 1, spec.scenes.length)) - 1;
      const scenes = [...spec.scenes];
      const [moved] = scenes.splice(found.index, 1);
      scenes.splice(target, 0, moved);
      return ok({...spec, scenes}, `Moved scene ${moved.id} to position ${target + 1}.`);
    }

    case 'replace_spec': {
      if (!Array.isArray(args.scenes) || args.scenes.length === 0) {
        return fail(spec, 'scenes must be a non-empty array of scene objects.');
      }
      const theme = isRecord(args.theme) ? args.theme : {};
      const candidate = normalizeSpec({
        version: 1,
        meta: {...spec.meta, title: text(args.title, 80) ?? spec.meta.title},
        theme: {...spec.theme, ...theme},
        scenes: args.scenes,
      });
      candidate.scenes = candidate.scenes.map((scene) => ({
        ...scene,
        durationInFrames: clampSceneFrames(candidate, scene.durationInFrames),
      }));
      return ok(
        candidate,
        `Replaced the video with ${candidate.scenes.length} scenes (${Math.round(totalSeconds(candidate))}s total).`,
      );
    }

    default:
      return fail(spec, `Unknown tool "${name}". Available tools: ${TOOL_DEFINITIONS.map((tool) => tool.function.name).join(', ')}.`);
  }
}

const quote = (value: string, max = 42): string =>
  value.length > max ? `${value.slice(0, max - 1).trimEnd()}…` : value;

/** Short, human readable label for the editor's activity feed. */
export function summarizeToolCall(name: string, args: Record<string, unknown>, outcome: ToolOutcome): string {
  if (!outcome.ok) return outcome.message;
  const headline = typeof args.headline === 'string' ? args.headline : undefined;
  switch (name) {
    case 'get_spec':
      return 'Read the timeline';
    case 'set_format':
      return `Canvas → ${String(args.aspect ?? '')}`;
    case 'set_theme':
      return 'Restyled the palette';
    case 'add_scene':
      return `Added ${String(args.kind ?? 'scene')}${headline ? ` · ${quote(headline)}` : ''}`;
    case 'update_scene':
      return `Edited ${String(args.id ?? 'scene')}${headline ? ` · ${quote(headline)}` : ''}`;
    case 'remove_scene':
      return `Removed ${String(args.id ?? 'scene')}`;
    case 'move_scene':
      return `Moved ${String(args.id ?? 'scene')} to ${String(args.position ?? '?')}`;
    case 'replace_spec':
      return `Rewrote the storyboard`;
    default:
      return name;
  }
}
