import {strToU8, zipSync} from 'fflate';
import videoSource from '../video/Video.tsx?raw';
import typesSource from '../types.ts?raw';
import {slugify} from './spec';
import type {MediaAttachment, VideoSpec} from '../types';

const REMOTION_VERSION = '4.0.538';

const packageJson = (spec: VideoSpec): string =>
  JSON.stringify(
    {
      name: slugify(spec.meta.title),
      version: '1.0.0',
      private: true,
      description: 'A Remotion video exported from Cutline.',
      scripts: {
        studio: 'remotion studio src/index.ts',
        render: 'remotion render src/index.ts Main out/video.mp4',
        still: 'remotion still src/index.ts Main out/poster.png --frame=0',
      },
      dependencies: {
        '@remotion/cli': `^${REMOTION_VERSION}`,
        react: '^19.3.1',
        'react-dom': '^19.3.1',
        remotion: `^${REMOTION_VERSION}`,
      },
      devDependencies: {
        '@types/react': '^19.3.0',
        typescript: '^5.9.0',
      },
    },
    null,
    2,
  );

const tsconfig = (): string =>
  JSON.stringify(
    {
      compilerOptions: {
        target: 'ES2022',
        lib: ['ES2022', 'DOM'],
        module: 'ESNext',
        moduleResolution: 'bundler',
        jsx: 'react-jsx',
        strict: true,
        noEmit: true,
        esModuleInterop: true,
        skipLibCheck: true,
        resolveJsonModule: true,
        forceConsistentCasingInFileNames: true,
      },
      include: ['src'],
    },
    null,
    2,
  );

const rootFile = (spec: VideoSpec): string => `import {Composition} from 'remotion';
import {Video} from './video/Video';
import specJson from './spec.json';
import attachmentsJson from './attachments.json';
import type {MediaAttachment, VideoSpec} from './types';

const spec = specJson as unknown as VideoSpec;
const attachments = attachmentsJson as unknown as MediaAttachment[];
const durationInFrames = Math.max(
  1,
  spec.scenes.reduce((sum, scene) => sum + scene.durationInFrames, 0),
);

export const RemotionRoot = () => (
  <Composition
    id="Main"
    component={Video}
    durationInFrames={durationInFrames}
    fps={spec.meta.fps}
    width={spec.meta.width}
    height={spec.meta.height}
    defaultProps={{spec, attachments}}
  />
);
`;

const indexFile = (): string => `import {registerRoot} from 'remotion';
import {RemotionRoot} from './Root';

registerRoot(RemotionRoot);
`;

const readme = (spec: VideoSpec, attachmentNames: string[]): string => `# ${spec.meta.title}

Exported from **Cutline** — an AI video editor built on [Remotion](https://remotion.dev).

- ${spec.scenes.length} scenes · ${spec.meta.width}×${spec.meta.height} · ${spec.meta.fps}fps
- Total length: ${(spec.scenes.reduce((sum, scene) => sum + scene.durationInFrames, 0) / spec.meta.fps).toFixed(1)}s
${attachmentNames.length ? `- ${attachmentNames.length} local media file${attachmentNames.length === 1 ? '' : 's'} copied into public/media` : ''}

## Run it

\`\`\`bash
npm install
npm run studio   # edit and preview in Remotion Studio
npm run render   # write out/video.mp4
\`\`\`

\`src/spec.json\` is the whole video: change the copy there, or open
\`src/video/Video.tsx\` to change how the scenes look. Every scene component is
plain React with Remotion's \`useCurrentFrame\`, \`spring\` and \`interpolate\`, so it
is easy to extend.

## Fonts

The renderer loads Inter, Instrument Serif and JetBrains Mono from Google Fonts
via a \`<style>\` tag. If you render offline, swap them for local files or
\`@remotion/google-fonts\` so the render does not wait on the network.

## Licensing

Remotion is free for individuals and small teams; larger companies need a
company licence to render. See https://remotion.dev/license.
`;

const safeFilename = (name: string, fallback: string): string => {
  const filename = name.replace(/[^a-zA-Z0-9._-]+/g, '-').replace(/^-+|-+$/g, '').slice(-100);
  return filename || fallback;
};

export interface ExportProjectOptions {
  media: MediaAttachment[];
}

const binaryDataUrl = (dataUrl: string): Uint8Array => {
  const encoded = dataUrl.split(',', 2)[1] ?? '';
  const binary = atob(encoded);
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
};

const blobBytes = async (blob: Blob): Promise<Uint8Array> => new Uint8Array(await blob.arrayBuffer());

/**
 * Embeds compressed preview stills and the exact video blobs referenced by
 * image scenes. No API settings or original unreferenced videos are included.
 */
export function buildProjectFiles(spec: VideoSpec, options: ExportProjectOptions = {media: []}): Record<string, string | Uint8Array> {
  const usedIds = new Set(spec.scenes.map((scene) => scene.mediaAttachmentId).filter((id): id is string => Boolean(id)));
  const used = options.media.filter((attachment) => usedIds.has(attachment.id));
  const assetPaths = new Map<string, string>();
  const portable = used.map((attachment) => {
    const base = safeFilename(attachment.name, `${attachment.id}.${attachment.kind === 'image' ? 'jpg' : 'mp4'}`);
    const videoPath = `media/${attachment.id}-${base}`;
    const frames = attachment.frames.map((frame, index) => {
      const path = `media/${attachment.id}-${index}.jpg`;
      assetPaths.set(`${attachment.id}:${index}`, path);
      return {timeSeconds: frame.timeSeconds, dataUrl: `/${path}`};
    });
    assetPaths.set(`${attachment.id}:video`, videoPath);
    return {
      id: attachment.id,
      name: attachment.name,
      kind: attachment.kind,
      mimeType: attachment.mimeType,
      ...(attachment.durationSeconds === undefined ? {} : {durationSeconds: attachment.durationSeconds}),
      frames,
      ...(attachment.kind === 'video' ? {videoSrc: `/${videoPath}`} : {}),
    };
  });

  const portableSpec: VideoSpec = {
    ...spec,
    scenes: spec.scenes.map((scene) => {
      if (!scene.mediaAttachmentId) return scene;
      const attachment = used.find((item) => item.id === scene.mediaAttachmentId);
      if (!attachment) return scene;
      if (attachment.kind === 'video') return scene;
      const frame = Math.max(0, Math.min(scene.mediaFrameIndex ?? 0, attachment.frames.length - 1));
      return {
        ...scene,
        imageUrl: `/${assetPaths.get(`${attachment.id}:${frame}`)}`,
        mediaAttachmentId: undefined,
        mediaFrameIndex: undefined,
      };
    }),
  };

  const files: Record<string, string | Uint8Array> = {
    'package.json': packageJson(spec),
    'tsconfig.json': tsconfig(),
    'README.md': readme(spec, used.map((attachment) => attachment.name)),
    '.gitignore': 'node_modules\nout\n.DS_Store\n',
    'src/index.ts': indexFile(),
    'src/Root.tsx': rootFile(spec),
    'src/spec.json': JSON.stringify(portableSpec, null, 2),
    'src/attachments.json': JSON.stringify(portable, null, 2),
    'src/types.ts': typesSource,
    'src/video/Video.tsx': videoSource,
  };

  for (const attachment of used) {
    attachment.frames.forEach((frame, index) => {
      files[`public/media/${attachment.id}-${index}.jpg`] = binaryDataUrl(frame.dataUrl);
    });
  }
  return files;
}

const download = (data: Uint8Array | string, filename: string, type: string): void => {
  const blob = new Blob([data as BlobPart], {type});
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
};

export async function downloadProjectZip(spec: VideoSpec, options: ExportProjectOptions = {media: []}): Promise<string> {
  const files = buildProjectFiles(spec, options);
  const usedIds = new Set(spec.scenes.map((scene) => scene.mediaAttachmentId).filter((id): id is string => Boolean(id)));
  for (const attachment of options.media) {
    if (!usedIds.has(attachment.id) || attachment.kind !== 'video' || !attachment.videoBlob) continue;
    const base = safeFilename(attachment.name, `${attachment.id}.mp4`);
    files[`public/media/${attachment.id}-${base}`] = await blobBytes(attachment.videoBlob);
  }
  const zipped = zipSync(
    Object.fromEntries(Object.entries(files).map(([path, contents]) => [path, typeof contents === 'string' ? strToU8(contents) : contents])),
    {level: 6},
  );
  const filename = `${slugify(spec.meta.title)}-remotion.zip`;
  download(zipped, filename, 'application/zip');
  return filename;
}

export function downloadSpecJson(spec: VideoSpec): string {
  const filename = `${slugify(spec.meta.title)}.json`;
  download(JSON.stringify(spec, null, 2), filename, 'application/json');
  return filename;
}
