# Cutline production deployment

## Requirements and topology

Use a Linux amd64 machine with Docker Engine and the Compose plugin, a domain, and persistent disk. The worker needs Chromium, Python 3.12, FFmpeg/FFprobe and CPU int8 inference. The image installs these rather than assuming a generic Node image has them. Start with one job/render at a time; measure a representative clip's elapsed time, peak memory, CPU and disk before promising capacity. The pictured 6-GB VPS is a reasonable starting point for serial workload, but startup builds and model downloads may use significant disk and memory; measure it before relying on capacity. Review [Remotion licensing](https://www.remotion.dev/license).

The standalone `compose.production.yml` defines `proxy` (Caddy HTTPS), `app` (React + Node API), `worker` (separate leased processing loop), and `postgres` (durable records). Only 80/443 are published. The database network is internal. Narration-studio browser media requires a signed-in session; the renderer gets a job-scoped random loopback-only asset endpoint, closed after rendering. No uploaded assets are placed in public build output. The classic editor at `?editor=classic` supports prompt-directed short video edits with BYOK: provider tokens and selected image/video preview frames are sent to the selected AI provider; original uploads are sent only to this VPS for rendering. Production enables the editor's chat, job, and render APIs with private-network SSRF checks, IP rate limiting, and capped render concurrency. Configure `API_RATE_LIMIT_PER_MINUTE`, `RENDER_JOBS_PER_IP`, `RENDER_QUEUE_LIMIT`, and `RENDER_RETENTION_SECONDS` in `.env.production` to tune limits. Short render jobs use app-container temporary storage and do not survive app recreation or the retention window; persistent narration projects/exports use Postgres and media volumes.

Freebuff Sites cannot run this Node/Python/Chromium stack. A managed Node/game container is insufficient unless its operator provides the required system dependencies and durable database/media paths. GitHub is not required: upload/extract source via SFTP or use a private Git checkout.

Install Docker through the [official Linux instructions](https://docs.docker.com/engine/install/) and [Compose plugin instructions](https://docs.docker.com/compose/install/linux/). Point an A record at the server IPv4. Add AAAA only with working IPv6. Open TCP 80/443, restrict administrative SSH, and never publish Postgres or worker ports. For Cloudflare, start DNS-only while Caddy issues its certificate; then, if enabling proxying, use Full (strict), not Flexible. DNS alone cannot map port 443 to an arbitrary managed-container allocation.

## Configure securely

From the source directory (clone with `git clone https://github.com/Krisslinux/cutline.git` or use a release source archive):

```bash
cp .env.production.example .env.production
chmod 600 .env.production
```

Edit this private file using your server's secret manager/editor. Set APP_DOMAIN, PUBLIC_APP_URL (exact HTTPS origin), database values, SESSION_SECRET and CREDENTIALS_KEY. Generate independent random secrets in your own secret store, never in chat or command arguments. SESSION_SECRET needs at least 32 random characters; CREDENTIALS_KEY is 32 random bytes encoded as 64 hex characters. DATABASE_URL must use the same Postgres password, URL-encoded as necessary. Back up the encryption key separately: without it saved BYOK settings cannot be recovered. Rotating SESSION_SECRET invalidates existing signed cookies. Credential-key rotation requires decrypting and re-encrypting provider rows; do not blindly replace it.

Compose passes all runtime values explicitly via `environment`. Its `--env-file` only supplies interpolation; it is not relied on as automatic container injection. No secrets have PUBLIC/NEXT_PUBLIC/VITE prefixes. Provider settings are entered after login, stored encrypted in Postgres, returned masked, and removable. Never put keys in project JSON or browser storage.

## Build, migrate, create owner, start

```bash
docker compose --env-file .env.production -f compose.production.yml config --quiet
docker compose --env-file .env.production -f compose.production.yml build
docker compose --env-file .env.production -f compose.production.yml up -d --wait postgres
docker compose --env-file .env.production -f compose.production.yml run --rm app npm run db:migrate
docker compose --env-file .env.production -f compose.production.yml run --rm app npm run setup:owner
docker compose --env-file .env.production -f compose.production.yml up -d --wait
docker compose --env-file .env.production -f compose.production.yml ps
```

Owner setup prompts for username and password with no password echo or arguments. Use an interactive terminal (omit `-T`). Multiple owners may be created, each isolated. There is no public registration. Login is required before narration-studio uploads or expensive processing. Do not expose the old development narration API; the running app routes it to a 410 response. The classic editor remains accessible at `?editor=classic` and accepts BYOK planning and rate-limited anonymous short renders; it stores neither prompt-job state nor render outputs durably. Original media uploads are capped at 200 MB each by the API/Caddy path and 500 MB per render; keep larger source clips within these practical limits.

The worker image prebundles the composition once and installs/launch-checks its matching Remotion browser under the `node` runtime user. Postgres and media use persistent volumes. ASR weights download on first transcription into persistent `/data/models`; allow outbound access to Hugging Face, and allow optional planning providers. English defaults to faster-whisper small.en/int8/beam 5/VAD/word timestamps. Non-English selection automatically uses the corresponding multilingual model. Set ASR_MODEL and ASR_THREADS in the private env to choose a model and CPU budget. First model loading is a named stage, not fake progress. ORT_DISABLE_TELEMETRY and HF_HUB_DISABLE_TELEMETRY are set before Python imports.

## Verify on the real origin

```bash
curl --fail https://YOUR_DOMAIN/api/health
curl --fail https://YOUR_DOMAIN/api/ready
# Should return 401:
curl -i https://YOUR_DOMAIN/api/studio/projects
docker compose --env-file .env.production -f compose.production.yml logs --tail=100 app worker proxy
```

Readiness requires the database and a worker heartbeat less than 45 seconds old. Detailed worker status is private at `/api/studio/worker`. Health alone does not prove video rendering.

In a browser: sign in, create a project, upload a narration clip and several illustrations, transcribe, correct word text/timing and framing, save, render, play and download the MP4/SRT/JSON. Check the last spoken word, captions and transitions. Sign out and verify private URLs fail. Create a second owner and verify the first owner's project/assets/jobs/downloads return 404. Foreign-Origin mutations must return 403. Restart app and worker, sign in again, reopen the project and download its completed MP4. A timeline edit intentionally makes old renders unavailable as final downloads until the saved revision is rendered again.

Narration-studio exports are H.264/yuv420p 720x1280 at 30 fps, CRF20/fast, AAC160k/48k. Classic-editor render exports support up to 120 seconds, include uploaded external audio or retained video source audio, and are separate short-lived MP4 jobs. At 1080p, high frame rates, or on noisy/long sources, expect more CPU time and disk usage; monitor `docker stats` and `df -h` while tuning limits. The worker probes streams/duration and decodes the full output before marking completed. Caption/transition evidence frames are retained privately. The source narration is retained; normalization does not change pace or restart audio at cuts. Low-confidence words are flagged. Invalid zero-length alignment fails with an actionable error instead of inventing timestamps.

## Persistence, recovery and cleanup

Volumes: `postgres_data` (projects, owners, sessions, encrypted settings and jobs), `media_data` (original audio/images, normalized/ASR audio, transcript intermediates, validated exports), `model_cache`, `caddy_data` and `caddy_config`. Failed/cancelled partial MP4s are removed. Retry reuses successful normalized audio and transcript files. Leases are renewed every five seconds; expired processing jobs become failed with retry available, and queued jobs remain queued. Rendering always uses a saved immutable timeline revision. Jobs stop at JOB_TIMEOUT_SECONDS. Source media cannot be replaced once a timeline revision exists; create a new project instead.

Monitor disk with `df -h`, Docker disk use with `docker system df`, and usage with `docker stats --no-stream`. The worker refuses new processing below 512 MB free. Uploads are capped at MAX_UPLOAD_MB per file, 500 MB per project, one narration/40 illustrations, ten minutes. Caddy caps individual requests at 200 MB. Classic editor media storage and final MP4s are short-lived temporary files in the app container; they are cleaned after the job retention window and disappear on container recreation, unlike the persistent narration-studio media volume. There is no automatic deletion of originals or completed projects: retain them until backups/retention policy permit removal. Restrict deployment access; do not run `docker system prune --volumes` or `compose down -v` as routine maintenance. Configure Docker log rotation on the host (e.g. max-size 10m/max-file 3) to bound persistent container logs. Logs never include provider keys or request bodies.

## Backup and tested restore procedure to perform on your server

Drain active jobs (wait until no running jobs in the UI) and stop app/worker to make database and media backups consistent. Keep proxy and Postgres up. Commands below operate only on this stack and save backups locally; protect the backup directory and use encrypted offsite storage of your choice.

```bash
mkdir -p backups
chmod 700 backups
docker compose --env-file .env.production -f compose.production.yml stop app worker
docker compose --env-file .env.production -f compose.production.yml exec -T postgres sh -c 'pg_dump -U "$POSTGRES_USER" -d "$POSTGRES_DB" -Fc' > backups/database.dump
docker compose --env-file .env.production -f compose.production.yml run --rm --no-deps -T --entrypoint tar app -cz -C /data media > backups/media.tar.gz
docker compose --env-file .env.production -f compose.production.yml up -d --wait
```

Back up `.env.production`/CREDENTIALS_KEY separately with restricted permissions; certificate/model caches may be rebuilt, but certificate backups avoid issuance limits. Restore only to an intentionally empty isolated stack: configure the same secrets, create its volumes/start Postgres, run migrations if appropriate, then `pg_restore --clean --if-exists` from the dump via Postgres stdin and extract the media archive into `/data` via the app container. Restore media as the node UID (1000) or correct ownership before start. Restore the encryption key, then start app/worker/proxy and verify private source assets and a completed MP4. Practice this on a separate server before relying on backups. This environment did not execute that production restore.

## Updating and rolling back

Keep a source archive and immutable image tags for each release (APP_VERSION). Drain jobs, take database/media backups, stop app/worker, upload the new source without overwriting the private env, build, run migrations, then `up -d --wait`. Never remove persistent volumes. For rollback use the prior source/image tag only if its schema is compatible; otherwise restore the matching database and media backup while services are stopped. Migrations are not assumed reversible. Current migration v1 creates tables/indexes idempotently; later schema changes require new migration versions and compatibility review.

## Troubleshooting and verification limits

- Build failure: inspect build logs; native Remotion dependencies stay external to esbuild and are installed in the runtime image by its locked npm install.
- Login 500: check the two independent secrets, origin, migration and owner setup. Do not weaken Origin checks or cookie security.
- Jobs stay queued: inspect worker heartbeat, DB URL/network, worker startup logs.
- Browser launch fails: check the image's build-time launch test and architecture; do not use an unprepared generic Node Alpine image.
- Transcription fails: confirm model download access/cache permissions, real speech, model/language selection and available RAM.
- Provider failure: settings can be removed to use deterministic local planning; invalid output is never executed.
- HTTPS unavailable: confirm domain DNS, inbound 80/443, Caddy logs, and absence of conflicting listeners.

On your VPS, point your standard domain's A record at the server IPv4, set `APP_DOMAIN` and `PUBLIC_APP_URL` to the domain in the private `.env.production`, allow inbound TCP 80/443, and follow the deployment sequence above. The screenshot's 4-vCPU/6-GB/100-GB server is a plausible starting point for one job at a time, not a measured throughput guarantee; model downloads, Docker builds and MP4 rendering can temporarily consume substantial RAM, CPU and disk. The screenshot alone does not provide the VPS IP, domain, or SSH access, so it cannot be configured or deployed automatically from this workspace. Production images/Compose execution and public DNS/TLS must be verified on the target VPS. Local tests and builds do not claim those checks passed. Use [Remotion Docker](https://www.remotion.dev/docs/docker), [faster-whisper](https://github.com/SYSTRAN/faster-whisper), and [FFmpeg docs](https://ffmpeg.org/documentation.html) for runtime references.
