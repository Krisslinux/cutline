import os
os.environ['ORT_DISABLE_TELEMETRY'] = '1'
os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'
import argparse
import json
from faster_whisper import WhisperModel

parser = argparse.ArgumentParser()
parser.add_argument('audio')
parser.add_argument('--language', default='en')
parser.add_argument('--hints', default='')
args = parser.parse_args()
model_name = os.environ.get('ASR_MODEL', 'small.en')
if args.language != 'en' and model_name.endswith('.en'):
    model_name = model_name.removesuffix('.en')
print(json.dumps({'stage': 'Loading transcription model (first run may download weights)'}), flush=True)
model = WhisperModel(model_name, device='cpu', compute_type='int8', cpu_threads=int(os.environ.get('ASR_THREADS', '2')), download_root=os.environ.get('MODEL_CACHE_DIR', '.cutline/models'))
segments, info = model.transcribe(args.audio, language=args.language, beam_size=5, word_timestamps=True, vad_filter=True, initial_prompt=args.hints or None)
words = []
for segment in segments:
    for word in segment.words or []:
        if word.word.strip():
            words.append({'id': 'word_' + str(len(words)), 'text': word.word.strip(), 'startMs': word.start * 1000, 'endMs': word.end * 1000, 'confidence': float(word.probability), 'uncertain': bool(word.probability < 0.65 or word.end <= word.start)})
    print(json.dumps({'stage': 'Transcribing narration', 'progress': min(0.99, segment.end / max(info.duration, 0.01))}), flush=True)
print(json.dumps({'words': words, 'language': info.language, 'durationMs': info.duration * 1000}), flush=True)
