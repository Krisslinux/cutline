import {z} from 'zod';
import {captionPages, timelineSchema, shotSchema, type NarrationTimeline} from '../shared/narration.ts';
import {providerJson, type ProviderSettings} from '../server/studio-security.ts';
const planSchema=z.object({shots:z.array(shotSchema).min(1).max(300),captionGroups:z.array(z.array(z.string()).min(1).max(12)).optional()}).strict();
export async function planTimeline(draft:NarrationTimeline,provider:ProviderSettings|null,signal:AbortSignal):Promise<NarrationTimeline>{
  if(!provider?.apiKey)return draft;
  const prompt=`Create an illustrated mythology video edit plan. Return only JSON {"shots":[...],"captionGroups":[["word_0",...],...]}. Shots must follow this exact schema and timing constraints: ${JSON.stringify(draft.shots)}. Retain all word IDs in order exactly once in captionGroups (3-6 words preferred); never change text or timestamps. Image IDs can repeat. First shot starts at 0; last ends at ${draft.durationInFrames}; next.startFrame = previous.endFrame - previous.transitionFrames. Overlap normally 18, less than half adjacent shot durations. Allowed transitions fade, diagonal, radial, none. End with none/0. Use only supplied image IDs. No code. Narration and images: ${JSON.stringify({words:draft.captionWords,images:draft.imageAssets})}`;
  const base=provider.baseUrl.replace(/\/+$/,'');let text:string;
  if(provider.provider==='anthropic'){
    const url=base.endsWith('/messages')?base:`${base}/messages`;
    const result=await providerJson(url,{'x-api-key':provider.apiKey,'anthropic-version':'2023-06-01'},{model:provider.model,max_tokens:8000,messages:[{role:'user',content:prompt}]},signal) as {content?:{type:string;text?:string}[]};
    text=result.content?.filter(x=>x.type==='text').map(x=>x.text??'').join('')??'';
  }else{
    const url=base.endsWith('/chat/completions')?base:`${base}/chat/completions`;
    const result=await providerJson(url,{authorization:`Bearer ${provider.apiKey}`},{model:provider.model,messages:[{role:'user',content:prompt}],temperature:0.2,response_format:{type:'json_object'}},signal) as {choices?:{message?:{content?:string}}[]};
    text=result.choices?.[0]?.message?.content??'';
  }
  let parsed:unknown;try{parsed=JSON.parse(text);}catch{throw new Error('Planning provider returned invalid JSON. Remove provider settings to use the local draft.');}
  const plan=planSchema.parse(parsed);
  let pages=draft.captionPages;
  if(plan.captionGroups){
    const flat=plan.captionGroups.flat();if(JSON.stringify(flat)!==JSON.stringify(draft.captionWords.map(w=>w.id)))throw new Error('Planner changed the transcript word order.');
    const map=new Map(draft.captionWords.map(w=>[w.id,w]));
    pages=plan.captionGroups.flatMap(ids=>captionPages(ids.map(id=>map.get(id)!))).map((p,i)=>({...p,id:`caption_${i}`}));
  }
  return timelineSchema.parse({...draft,shots:plan.shots,captionPages:pages});
}
