import {spawn} from 'node:child_process';
import {randomUUID} from 'node:crypto';
import {createServer} from 'node:http';
import {createReadStream} from 'node:fs';
import {mkdir, readFile, writeFile, rename, rm, statfs, stat} from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {openDb,migrate} from '../server/studio-db.ts';
import {StudioStore,type Job,type Asset} from '../server/studio-store.ts';
import {mediaPath} from '../server/studio-api.ts';
import {draftTimeline,timelineSchema,type CaptionWord,type NarrationTimeline} from '../shared/narration.ts';
import {planTimeline} from './planner.ts';

const ffmpeg=()=>process.env.FFMPEG_PATH??'ffmpeg';
const ffprobe=()=>process.env.FFPROBE_PATH??'ffprobe';
export async function command(binary:string,args:string[],signal:AbortSignal,onLine?:(line:string)=>void):Promise<string>{
  return new Promise((resolve,reject)=>{
    const process=spawn(binary,args,{signal,stdio:['ignore','pipe','pipe']});let output='',pending='',error='';
    process.stdout.on('data',(chunk:Buffer)=>{output+=chunk.toString();if(output.length>8*1024*1024){process.kill();reject(new Error('Process output limit exceeded.'));return;}pending+=chunk.toString();const lines=pending.split('\n');pending=lines.pop()??'';for(const line of lines)onLine?.(line);});
    process.stderr.on('data',(chunk:Buffer)=>{error=(error+chunk.toString()).slice(-1000);});
    process.on('error',()=>reject(new Error(signal.aborted?'Job cancelled.':`${path.basename(binary)} could not start. Check worker dependencies.`)));
    process.on('close',code=>{if(pending)onLine?.(pending);if(code===0)resolve(output);else reject(new Error(signal.aborted?'Job cancelled.':`${path.basename(binary)} failed (${code}). ${error.replace(/https?:\/\/\S+/g,'[remote]').slice(-500)}`));});
  });
}
async function metadata(file:string,signal:AbortSignal):Promise<{streams:{codec_type:string;codec_name:string;width:number;height:number;avg_frame_rate:string;sample_rate:string;duration?:string}[];format:{duration:string}}>{return JSON.parse(await command(ffprobe(),['-v','error','-show_streams','-show_format','-of','json',file],signal));}
async function exists(file:string):Promise<boolean>{return Boolean(await stat(file).catch(()=>null));}
export async function validateMp4(file:string,timeline:NarrationTimeline,signal:AbortSignal):Promise<void>{
  const probe=await metadata(file,signal);const video=probe.streams.find(s=>s.codec_type==='video'),audio=probe.streams.find(s=>s.codec_type==='audio');
  const seconds=Number(probe.format.duration);
  if(!video||video.codec_name!=='h264'||video.width!==720||video.height!==1280||video.avg_frame_rate!=='30/1'||!audio||audio.codec_name!=='aac'||audio.sample_rate!=='48000'||seconds+0.04<timeline.durationMs/1000||seconds>timeline.durationMs/1000+0.25)throw new Error('Encoded MP4 failed stream, duration, or format validation.');
  await command(ffmpeg(),['-v','error','-xerror','-i',file,'-map','0:v:0','-map','0:a:0','-c:v','rawvideo','-c:a','pcm_s16le','-f','null','-'],signal);
}
async function render(timeline:NarrationTimeline,assets:Asset[],output:string,signal:AbortSignal,onProgress:(p:number)=>void):Promise<void>{
  const assetMap=new Map(assets.map(a=>[a.id,a]));const prefix=randomUUID();
  const server=createServer(async(req,res)=>{
    const id=req.url?.split('/');const a=id?.[1]===prefix?assetMap.get(id[2]):undefined;
    if(!a){res.writeHead(404);res.end();return;}
    const file=mediaPath(a.file_key);const info=await stat(file).catch(()=>null);if(!info){res.writeHead(404);res.end();return;}
    const match=/^bytes=(\d+)-(\d*)$/.exec(req.headers.range??'');const start=match?Number(match[1]):0;const end=match&&match[2]?Math.min(Number(match[2]),info.size-1):info.size-1;
    if(start>end||start>=info.size){res.writeHead(416);res.end();return;}
    res.writeHead(match?206:200,{'content-type':a.mime,'content-length':end-start+1,'accept-ranges':'bytes',...(match?{'content-range':`bytes ${start}-${end}/${info.size}`}:{})});createReadStream(file,{start,end}).on('error',()=>res.destroy()).pipe(res);
  });
  await new Promise<void>((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve);});
  try{
    const port=(server.address() as {port:number}).port;
    const urls=Object.fromEntries(assets.map(a=>[a.id,`http://127.0.0.1:${port}/${prefix}/${a.id}`]));
    const {selectComposition,renderMedia,makeCancelSignal}=await import('@remotion/renderer');
    const serveUrl=path.resolve(process.env.REMOTION_BUNDLE??'dist-render');
    const inputProps={timeline,assets:urls};const browserExecutable=process.env.REMOTION_BROWSER_EXECUTABLE;
    const composition=await selectComposition({serveUrl,id:'Narration',inputProps,browserExecutable});
    const {cancel,cancelSignal}=makeCancelSignal();const abort=()=>cancel();signal.addEventListener('abort',abort,{once:true});if(signal.aborted)cancel();
    try{await renderMedia({serveUrl,composition,inputProps,outputLocation:output,codec:'h264',pixelFormat:'yuv420p',crf:20,x264Preset:'fast',audioCodec:'aac',audioBitrate:'160k',sampleRate:48000,
      concurrency:1,browserExecutable,cancelSignal,chromiumOptions:{enableMultiProcessOnLinux:true},onProgress:p=>onProgress(p.progress),logLevel:'error'});}finally{signal.removeEventListener('abort',abort);}
  }finally{server.closeAllConnections();await new Promise<void>(resolve=>server.close(()=>resolve()));}
}
export async function processJob(store:StudioStore,job:Job,worker:string,signal:AbortSignal):Promise<void>{
  const payload=JSON.parse(job.payload) as {timeline:NarrationTimeline|null;hints:string;language:string;title:string};
  const assets=await store.assets(job.owner_id,job.project_id);const audio=assets.find(a=>a.kind==='audio');const images=assets.filter(a=>a.kind==='image');
  if(!audio||!images.length)throw new Error('Missing narration or illustrations.');
  const directory=path.dirname(mediaPath(audio.file_key));await mkdir(directory,{recursive:true,mode:0o700});
  const disk=await statfs(directory);if(Number(disk.bavail)*Number(disk.bsize)<512*1024*1024)throw new Error('Worker disk space is below 512 MB. Free space before retrying.');
  const progress=(state:string,stage:string,p:number|null)=>store.progress(job.id,worker,state,stage,p);
  let timeline=payload.timeline;
  if(job.kind==='draft'){
    await progress('transcribing','Checking source media',null);
    const source=mediaPath(audio.file_key),probe=await metadata(source,signal);const durationMs=Number(probe.format.duration)*1000;
    if(!probe.streams.some(s=>s.codec_type==='audio')||!Number.isFinite(durationMs)||durationMs<=0||durationMs>600000)throw new Error('Narration must contain valid audio lasting no more than ten minutes.');
    for(const image of images){const p=await metadata(mediaPath(image.file_key),signal);const s=p.streams.find(s=>s.codec_type==='video');if(!s||s.width>12000||s.height>12000)throw new Error('Invalid or oversized illustration.');}
    await store.db.query('UPDATE assets SET duration_ms=$1 WHERE id=$2',[durationMs,audio.id]);
    const normalized=path.join(directory,'normalized.m4a'),asr=path.join(directory,'asr.wav');
    if(!await exists(normalized)){
      await progress('transcribing','Normalizing narration without changing its pace',null);
      const temp=path.join(directory,`${job.id}-normalized.m4a`);
      try{await command(ffmpeg(),['-v','error','-y','-i',source,'-map','0:a:0','-vn','-af','loudnorm=I=-16:TP=-1.5:LRA=11','-ar','48000','-c:a','aac','-b:a','192k','-f','mp4',temp],signal);await rename(temp,normalized);}finally{await rm(temp,{force:true});}
    }
    if(!await exists(asr)){
      const temp=path.join(directory,`${job.id}-asr.wav`);
      try{await command(ffmpeg(),['-v','error','-y','-i',source,'-map','0:a:0','-vn','-ac','1','-ar','16000','-c:a','pcm_s16le',temp],signal);await rename(temp,asr);}finally{await rm(temp,{force:true});}
    }
    const transcript=path.join(directory,'transcript.json');let words:CaptionWord[];
    if(await exists(transcript)){words=JSON.parse(await readFile(transcript,'utf8')).words;}
    else{
      let result:{words?:CaptionWord[]}|undefined;let lastUpdate=0;const pending:Promise<void>[]=[];
      await command(process.env.PYTHON_PATH??'python3',['worker/transcribe.py',asr,'--language',payload.language,'--hints',payload.hints],signal,line=>{
        try{const event=JSON.parse(line);if(event.words)result=event;else if(Date.now()-lastUpdate>1500){lastUpdate=Date.now();pending.push(progress('transcribing',event.stage??'Transcribing',typeof event.progress==='number'?event.progress:null));}}catch{ /* Non-JSON model diagnostic, never interpreted as success. */ }
      });await Promise.all(pending);
      if(!result?.words?.length)throw new Error('No speech detected. Check the audio and retry with a suitable language/model.');
      words=result.words;
      const temp=transcript+'.'+job.id;await writeFile(temp,JSON.stringify({words}),{mode:0o600});await rename(temp,transcript);
    }
    const validated:CaptionWord[]=[];let lastEnd=0;
    for(const word of words){
      const start=Math.max(lastEnd,word.startMs);const end=Math.min(durationMs,word.endMs);
      if(!Number.isFinite(start)||!Number.isFinite(end)||end<=start)throw new Error('Transcription contains zero-length or invalid word timings. Correct the audio or change the transcription model before retrying.');
      validated.push({...word,startMs:start,endMs:end,uncertain:word.uncertain||start!==word.startMs});lastEnd=end;
    }
    const draft=draftTimeline({title:payload.title,audioAssetId:audio.id,imageAssets:images.map(a=>a.id),durationMs,words:validated});
    await progress('planning','Creating editable narration-driven shots and caption phrases',null);
    timeline=await planTimeline(draft,await store.provider(job.owner_id),signal);
    signal.throwIfAborted();await store.save(job.owner_id,job.project_id,job.revision,timeline);
    await progress('ready','Draft ready for review',1);return;
  }
  timeline=timelineSchema.parse(timeline);
  const revision=job.revision;
  const temp=path.join(directory,`${job.id}.partial.mp4`),outputKey=`${job.owner_id}/${job.project_id}/${job.id}.mp4`,output=mediaPath(outputKey);
  let update:Promise<void>=Promise.resolve();let last=0;
  try{
    await progress('rendering','Rendering saved project revision',0);
    const normalized=path.join(directory,'normalized.m4a');
    if(!await exists(normalized))throw new Error('Normalized narration is missing. Retry the draft job before rendering.');
    const renderAssets=assets.map(a=>a.id===audio.id?{...a,file_key:path.join(path.dirname(a.file_key),'normalized.m4a'),mime:'audio/mp4'}:a);
    await render(timeline,renderAssets,temp,signal,p=>{if(Date.now()-last>1500){last=Date.now();update=update.then(()=>progress('rendering','Rendering frames and encoding MP4',p));update.catch(()=>undefined);}});
    await update;signal.throwIfAborted();await progress('validating','Checking streams and decoding the complete MP4',null);
    await validateMp4(temp,timeline,signal);
    const previewFrame=Math.min(timeline.durationInFrames-1,Math.max(8,timeline.captionPages[0]?.startFrame??0));
    await command(ffmpeg(),['-v','error','-y','-ss',String(previewFrame/30),'-i',temp,'-frames:v','1',path.join(directory,`${job.id}-caption.jpg`)],signal);
    if(timeline.shots.length>1)await command(ffmpeg(),['-v','error','-y','-ss',String(timeline.shots[1].startFrame/30),'-i',temp,'-frames:v','1',path.join(directory,`${job.id}-transition.jpg`)],signal);
    signal.throwIfAborted();const current=await store.project(job.owner_id,job.project_id);if(current.revision!==revision)throw new Error('Project changed during rendering. Render the latest saved revision.');
    await rename(temp,output);
    const rows=await store.db.query("UPDATE jobs SET state='completed',stage='Validated MP4 ready',progress=1,output_key=$1,updated_at=$2 WHERE id=$3 AND lease_owner=$4 AND cancel_requested=0 RETURNING id",[outputKey,Date.now(),job.id,worker]);
    if(!rows.length){await rm(output,{force:true});throw new Error('Render cancelled.');}
  }finally{await rm(temp,{force:true});}
}

export async function runWorker(options:{signal?:AbortSignal;pollIntervalMs?:number}={}):Promise<void>{
  const db=await openDb();await migrate(db);const store=new StudioStore(db);const id=randomUUID();let stopping=false;let controller:AbortController|null=null;
  const stop=()=>{stopping=true;controller?.abort();};process.on('SIGTERM',stop);process.on('SIGINT',stop);
  const abort=()=>stop();options.signal?.addEventListener('abort',abort,{once:true});if(options.signal?.aborted)stop();
  const heartbeat=async()=>{await db.query('INSERT INTO workers(id,heartbeat) VALUES($1,$2) ON CONFLICT(id) DO UPDATE SET heartbeat=excluded.heartbeat',[id,Date.now()]);};await heartbeat();
  console.log('[cutline-worker] ready');
  while(!stopping){
    await heartbeat();const job=await store.claim(id);if(!job){await new Promise(r=>setTimeout(r,options.pollIntervalMs??1500));continue;}
    controller=new AbortController();const active=controller;let ticking=false;
    const timer=setInterval(()=>{if(ticking)return;ticking=true;(async()=>{
      await heartbeat();const current=await store.job(job.owner_id,job.id);if(current.cancel_requested||current.lease_owner!==id)active.abort();
      await db.query('UPDATE jobs SET lease_until=$1 WHERE id=$2 AND lease_owner=$3',[Date.now()+60000,job.id,id]);
    })().catch(()=>active.abort()).finally(()=>{ticking=false;});},5000);
    const timeout=setTimeout(()=>active.abort(new Error('Job timeout')),Number(process.env.JOB_TIMEOUT_SECONDS??1800)*1000);
    try{await processJob(store,job,id,active.signal);}catch(error){
      const current=await store.job(job.owner_id,job.id);const cancelled=Boolean(current.cancel_requested);
      await db.query('UPDATE jobs SET state=$1,stage=$2,error=$3,output_key=NULL,updated_at=$4 WHERE id=$5 AND lease_owner=$6',[cancelled?'cancelled':'failed',cancelled?'Cancelled':'Processing failed',cancelled?null:stopping?'Worker stopped. Retry to reuse intermediate artifacts.':active.signal.aborted?'Job exceeded its timeout. Retry or increase JOB_TIMEOUT_SECONDS.':error instanceof Error?error.message.slice(0,600):'Processing failed.',Date.now(),job.id,id]);
      console.error('[cutline-worker]',job.id,cancelled?'cancelled':'failed');
    }finally{clearInterval(timer);clearTimeout(timeout);controller=null;await db.query('UPDATE jobs SET lease_owner=NULL,lease_until=0 WHERE id=$1 AND lease_owner=$2',[job.id,id]);}
  }
  options.signal?.removeEventListener('abort',abort);process.removeListener('SIGTERM',stop);process.removeListener('SIGINT',stop);
  await db.query('DELETE FROM workers WHERE id=$1',[id]);await db.close();
}
if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url)runWorker().catch(()=>{console.error('[cutline-worker] startup failed; check database and configuration.');process.exitCode=1;});
