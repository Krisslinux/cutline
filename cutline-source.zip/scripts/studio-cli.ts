import {randomUUID} from 'node:crypto';
import {createInterface} from 'node:readline/promises';
import {stdin,stdout} from 'node:process';
import {openDb,migrate} from '../server/studio-db.ts';
import {hashPassword,secrets,publicOrigin} from '../server/studio-security.ts';
async function password(prompt:string):Promise<string>{
  if(!stdin.isTTY||!stdin.setRawMode)throw new Error('Owner setup needs an interactive terminal. Use docker compose run --rm app npm run setup:owner.');
  stdout.write(prompt);stdin.setRawMode(true);stdin.resume();
  return new Promise((resolve,reject)=>{
    let value='';const done=()=>{stdin.setRawMode(false);stdin.pause();stdin.removeListener('data',data);stdout.write('\n');};
    const data=(chunk:Buffer)=>{for(const c of chunk.toString()){if(c==='\u0003'){done();reject(new Error('Cancelled.'));return;}if(c==='\r'||c==='\n'){done();resolve(value);return;}if(c==='\u007f'){value=value.slice(0,-1);}else if(c>=' '&&value.length<256)value+=c;}};stdin.on('data',data);
  });
}
async function main(){
  const mode=process.argv[2];const db=await openDb();
  try{
    if(mode==='migrate'){await migrate(db);console.log('Database migrations applied.');return;}
    if(mode==='ready'){
      const [row]=await db.query<{heartbeat:number}>('SELECT heartbeat FROM workers ORDER BY heartbeat DESC LIMIT 1');
      if(!row||Date.now()-Number(row.heartbeat)>45000)throw new Error('Worker heartbeat is missing or stale.');console.log('Worker heartbeat healthy.');return;
    }
    if(mode!=='owner')throw new Error('Choose migrate, owner, or ready.');
    secrets();publicOrigin();await migrate(db);
    const readline=createInterface({input:stdin,output:stdout});const username=(await readline.question('Owner username: ')).trim();readline.close();
    if(!/^[a-zA-Z0-9_.-]{3,100}$/.test(username))throw new Error('Use 3–100 letters, numbers, dots, underscores, or hyphens.');
    const value=await password('Password (not echoed, 12+ characters): ');const confirm=await password('Repeat password: ');if(value!==confirm)throw new Error('Passwords do not match.');
    const hash=await hashPassword(value);await db.query('INSERT INTO owners(id,username,password_hash) VALUES($1,$2,$3)',[randomUUID(),username,hash]);console.log('Owner created. Sign in through the studio.');
  }finally{await db.close();}
}
main().catch(error=>{console.error(error instanceof Error?error.message:'Setup failed.');process.exitCode=1;});
