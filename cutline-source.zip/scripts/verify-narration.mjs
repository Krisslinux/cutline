import {spawn} from 'node:child_process';
import {randomBytes} from 'node:crypto';
import {mkdir,readFile,writeFile,rm} from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
const files=process.argv.slice(2);if(files.length<3)throw new Error('Usage: node scripts/verify-narration.mjs narration.wav image1.png image2.png');
const root=process.cwd(),base=path.resolve('.cutline/verification'),out=path.resolve('artifacts/narration-sample');
await rm(base,{recursive:true,force:true});await mkdir(base,{recursive:true});await mkdir(out,{recursive:true});
const origin='http://127.0.0.1:3101';const password=randomBytes(24).toString('hex');
const env={...process.env,NODE_ENV:'development',DATABASE_URL:path.join(base,'studio.sqlite'),MEDIA_DIR:path.join(base,'media'),PUBLIC_APP_URL:origin,SESSION_SECRET:randomBytes(32).toString('hex'),CREDENTIALS_KEY:randomBytes(32).toString('hex'),PORT:'3101',HOST:'127.0.0.1'};
const children=[];const logs=[];
function start(entry){const child=spawn(process.execPath,[entry],{cwd:root,env,stdio:['ignore','pipe','pipe']});children.push(child);child.stdout.on('data',b=>logs.push(b.toString()));child.stderr.on('data',b=>logs.push(b.toString()));return child;}
async function stop(child){if(child.exitCode!==null)return;child.kill('SIGTERM');await Promise.race([new Promise(r=>child.once('exit',r)),new Promise(r=>setTimeout(()=>{child.kill('SIGKILL');r();},5000))]);}
async function waitServer(){for(let i=0;i<80;i++){try{if((await fetch(origin+'/api/health')).ok)return;}catch{}await new Promise(r=>setTimeout(r,250));}throw new Error('App did not become ready');}
let cookie='';
async function request(route,method='GET',body,headers={}){return fetch(origin+'/api/studio'+route,{method,headers:{origin,cookie,...(body&&typeof body==='object'&&!Buffer.isBuffer(body)?{'content-type':'application/json'}:{}),...headers},body:body===undefined?undefined:Buffer.isBuffer(body)?body:JSON.stringify(body)});}
async function json(route,method='GET',body){const response=await request(route,method,body);const value=await response.json();assert(response.ok,JSON.stringify(value));return value;}
async function waitJob(id){for(let i=0;i<600;i++){const j=await json('/jobs/'+id);if(['failed','cancelled'].includes(j.state))throw new Error(`${j.state}: ${j.error}`);if(['ready','completed'].includes(j.state))return j;if(i%10===0)console.log(j.state,j.stage,j.progress??'');await new Promise(r=>setTimeout(r,1000));}throw new Error('Verification job timed out');}
try{
  const {DatabaseSync}=await import('node:sqlite');const {scryptSync}=await import('node:crypto');
  const migration=spawn(process.execPath,['dist-server/scripts/studio-cli.mjs','migrate'],{cwd:root,env,stdio:'inherit'});await new Promise((resolve,reject)=>migration.on('exit',c=>c===0?resolve():reject(new Error('Migration failed'))));
  const db=new DatabaseSync(env.DATABASE_URL);const salt=randomBytes(16).toString('hex');db.prepare('INSERT INTO owners VALUES(?,?,?)').run('verification-owner','verification',`${salt}:${scryptSync(password,salt,64).toString('hex')}`);db.close();
  let app=start('dist-server/server/index.mjs');let worker=start('dist-server/worker/index.mjs');await waitServer();
  const login=await request('/login','POST',{username:'verification',password});assert.equal(login.status,200);cookie=login.headers.get('set-cookie').split(';')[0];
  const project=await json('/projects','POST',{title:'A story of the Nile',hints:'Neith, Egypt, Nile',language:'en'});
  for(const f of files){const ext=path.extname(f).toLowerCase();const mime={'.wav':'audio/wav','.mp3':'audio/mpeg','.m4a':'audio/mp4','.png':'image/png','.jpg':'image/jpeg','.webp':'image/webp'}[ext];const response=await request(`/projects/${project.id}/assets`,'POST',await readFile(f),{'content-type':mime,'x-file-name':encodeURIComponent(path.basename(f))});assert.equal(response.status,201,await response.text());}
  const began=Date.now();const draft=await json(`/projects/${project.id}/draft`,'POST');await waitJob(draft.id);let saved=await json('/projects/'+project.id);
  assert(saved.timeline.captionWords.length>0);assert(saved.timeline.shots.length>1);
  // Exercise an actual corrected revision and repeated-image assignment.
  const original=saved.timeline.shots[0];const imageIds=saved.timeline.imageAssets;
  saved.timeline.shots=[0,80,160,240].map((startFrame,i)=>({...original,id:`shot_${i}`,startFrame,endFrame:i===3?saved.timeline.durationInFrames:[80,160,240][i]+18,imageAssetId:imageIds[i===2?1:0],transitionOut:['fade','diagonal','radial','none'][i],transitionFrames:i===3?0:18}));
  saved.timeline.captionWords[0].text='In';
  const corrected=await json('/projects/'+project.id,'PUT',{revision:saved.revision,timeline:saved.timeline});
  const rendering=await json(`/projects/${project.id}/render`,'POST');const finished=await waitJob(rendering.id);
  const response=await request(`/jobs/${finished.id}/download`);assert.equal(response.status,200);const bytes=Buffer.from(await response.arrayBuffer());assert(bytes.length>1000);await writeFile(path.join(out,'sample.mp4'),bytes);
  const srt=await request(`/projects/${project.id}/srt`);assert.equal(srt.status,200);await writeFile(path.join(out,'sample.srt'),await srt.text());await writeFile(path.join(out,'timeline.json'),JSON.stringify(corrected.timeline,null,2));
  assert.equal((await request(`/jobs/${finished.id}/download`,'GET',undefined,{range:'bytes=0-99'})).status,206);
  await stop(app);await stop(worker);app=start('dist-server/server/index.mjs');worker=start('dist-server/worker/index.mjs');await waitServer();
  assert.equal((await request(`/jobs/${finished.id}/download`)).status,200);assert.equal((await json('/projects/'+project.id)).revision,corrected.revision);
  assert.equal((await request('/projects','POST',{title:'forbidden'},{origin:'https://foreign.example'})).status,403);
  await json('/logout','POST');assert.equal((await request(`/jobs/${finished.id}/download`)).status,401);
  const report={verifiedAt:new Date().toISOString(),files:files.map(f=>path.basename(f)),transcriptWords:corrected.timeline.captionWords.length,shots:corrected.timeline.shots.length,narrationMs:corrected.timeline.durationMs,frames:corrected.timeline.durationInFrames,renderBytes:bytes.length,elapsedSeconds:(Date.now()-began)/1000,checks:['authenticated upload','real faster-whisper transcription','deterministic no-key planning','corrected revision save','repeated and distinct image assignment','fade/feathered diagonal/radial transitions','Chromium MP4 render','FFprobe validation','full FFmpeg decode','SRT and JSON download','range download','app and worker restart persistence','foreign-origin rejection','logout/private download rejection']};await writeFile(path.join(out,'verification.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
}catch(error){console.error(logs.join('').slice(-12000));throw error;}finally{for(const child of children)await stop(child);await writeFile(path.join(out,'runtime.log'),logs.join(''));}
