import {build} from 'esbuild';
import {bundle} from '@remotion/bundler';
import path from 'node:path';
await build({entryPoints:['server/index.ts','worker/index.ts','scripts/studio-cli.ts'],outdir:'dist-server',outbase:'.',bundle:true,platform:'node',format:'esm',target:'node22',packages:'external',outExtension:{'.js':'.mjs'}});
await bundle({entryPoint:path.resolve('src/render/narration-entry.tsx'),outDir:path.resolve('dist-render'),onProgress:p=>{if(p===100)console.log('Narration composition bundled.');},webpackOverride:config=>config});
