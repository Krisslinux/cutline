# Cutline

[![CI](https://github.com/Krisslinux/cutline/actions/workflows/ci.yml/badge.svg)](https://github.com/Krisslinux/cutline/actions/workflows/ci.yml)

React/TypeScript + Remotion narration studio. Upload prepared illustrations and a WAV/MP3/M4A narration, transcribe with local faster-whisper, correct word timings and shots, and export a validated 720×1280 H.264 MP4, SRT and editable timeline JSON. Image generation and text-to-speech are not part of the product.

## Local development

Requires Node **22.18+**, Python **3.12**, FFmpeg/FFprobe and Chromium's Linux libraries. Install dependencies from the committed locks:

```bash
npm ci
python3 -m venv .venv
.venv/bin/pip install --require-hashes -r worker/requirements.lock
```

Create a private `.env` (not committed). Set independent SESSION_SECRET (32+ random characters) and CREDENTIALS_KEY (64 hexadecimal characters), PUBLIC_APP_URL=http://localhost:3000, and PYTHON_PATH to your venv's Python. Optional DATABASE_URL=sqlite:.cutline/development.sqlite; SQLite is development-only, while production requires Postgres. If using an authenticated cloud development preview, set DEV_PREVIEW_ORIGIN to its exact HTTPS origin, not a wildcard. FFmpeg and FFprobe can be selected using FFMPEG_PATH/FFPROBE_PATH. MEDIA_DIR defaults to `.cutline/media`, MODEL_CACHE_DIR to `.cutline/models`; REMOTION_BROWSER_EXECUTABLE can select an installed browser.

Generate secrets in your own secret store; do not paste them into chat, commands or source code. Keep `.env` private. Start with:

```bash
npm run db:migrate
npm run setup:owner           # interactive password, no echo
npm run build                # React, externalized Node bundles, one prebuilt Remotion composition
npm run worker               # separate terminal, one leased job at a time
npm run dev                  # http://localhost:3000
```

`npm start` serves the production build and API; `npm run worker:dev` runs worker source after the composition has been built. Both read `.env`. Vite reads it for local preview. The Node runtime includes experimental SQLite support; no SQLite native addon is installed. First transcription downloads the selected ASR model into the model cache (small.en by default); non-English projects use the corresponding multilingual model. Telemetry is disabled before ASR imports. Python's PyAV dependency is pinned to a version compatible with faster-whisper 1.2.1 rather than an unbounded latest version.

Open Cutline in a browser, create a private project, upload one narration and up to 40 illustrations, draft, correct captions/timing/framing/transitions, save, and render. The legacy editor remains at `?editor=classic`: add your own OpenAI-compatible model endpoint, model id and provider token in Settings, attach up to six images/video clips and optional narration/music, describe the finished video, review the AI storyboard, then render an MP4 up to two minutes. Image previews and sampled video frames go to your selected vision-capable provider for planning; full media uploads only to your editor server for rendering. AI provider usage is paid by your provider account. Tokens in the classic editor stay in that browser and are sent only to your selected endpoint; they are not sent to the render service or saved to localStorage. Video source audio is retained when no external audio is selected, and external narration/music replaces source audio. The classic editor's render queue is in-memory and intended for short-session cuts; the durable narration studio stores projects, assets, jobs and exports across restarts. Without a narration planning API key the worker uses punctuation and pauses and cycles through images. Optional OpenAI-compatible Chat Completions and Anthropic Messages adapters return validated JSON only; invalid model output fails safely. Narration-studio provider settings are encrypted on the backend, masked in responses and removable. Source assets, intermediate audio/transcripts, jobs and validated narration exports survive application restarts. Failed renders never become final downloads, old revisions are invalidated, and retries reuse intermediate artifacts.

## VPS production deployment

See **[DEPLOY.md](DEPLOY.md)** for the standalone `compose.production.yml`: Caddy HTTPS + production Node app + separate Chromium/FFmpeg/Python worker + Postgres, durable media and model caches. It includes migrations, interactive owner setup, backup/restore, updates/rollback and exact commands. GitHub Actions validates changes; production deployment remains a deliberate, manual VPS operation. Keep `.env.production` private and never commit real credentials.

A generic Node container or Freebuff Sites cannot run the entire processing stack unchanged. The Docker image explicitly installs and launch-checks the Remotion browser under its runtime user. Docker daemon access and public DNS/TLS must be verified on your actual host.

## Architecture and limits

- `shared/narration.ts`: strict project validation, word timestamps, frame math, caption grouping and SRT.
- `src/video/NarrationVideo.tsx`: one shared player/export composition, continuous narration, regular white captions, subtle camera movement and custom feathered transitions.
- `server/studio-*`: owner-scoped durable projects/assets/jobs, HttpOnly signed sessions, CSRF checks, encrypted BYOK and public-only pinned provider requests.
- `worker/`: database leases, transcription, optional JSON planning, real progress, rendering, FFprobe validation and full decode before completion.
- `scripts/`: production builds, migration and owner setup.

One job is processed at a time. Limits: ten-minute narration, one audio asset/40 images, 100 MB per file by default (configurable to 200 MB), 500 MB total project media. Worker timeout defaults to 1800 seconds. Completed processing leases are released; interrupted leases become retryable failed jobs. Project saves use revision checks. Downloads are private and range-enabled. Assets are resolved by server-generated IDs, never arbitrary user file paths. There is no public registration; operators create accounts.

The earlier scene-based editor remains at `?editor=classic` with local editing, prompt-directed media planning and short server-side MP4 exports. Its anonymous planning/render APIs are rate-limited and protected from private-network SSRF; production enables this short-session editor, and render records/outputs are ephemeral and disappear after restart or the configured retention window. The primary narration studio uses owner-scoped accounts and durable storage.

## Verification

```bash
npm run typecheck
npm test
npm run build
```

Tests cover narration frame math, caption grouping, SRT, invalid plans, sign-in/sign-out, ownership, CSRF, encrypted settings, revisions, leased jobs, retry/cancel, provider vision requests, render upload and media/audio selection. A build is not proof of export: run a real narration through transcription, saved correction, rendering, complete decode, download and restart recovery. See DEPLOY.md for VPS and actual-origin checks. Any environment limitation must be reported, not treated as a pass.

MIT. Remotion's own [licensing terms](https://www.remotion.dev/license) apply to rendering usage.
